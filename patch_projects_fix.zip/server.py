"""
Institutional Equity Research Matrix (IERM) - FastAPI Server
"""

import io
import os
import re
import csv
import httpx
import time
from datetime import datetime, date
import json
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import hashlib
import asyncio
import unicodedata
import urllib.parse
import sys
import typing
try:
    from typing import Protocol
except ImportError:
    try:
        import typing_extensions
        typing.Protocol = typing_extensions.Protocol
    except Exception:
        pass

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
from typing import List, Dict, Any, Optional, Union
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request, Header
from fastapi.responses import HTMLResponse, JSONResponse, Response, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

def to_ascii_slug(text: str) -> str:
    """Chuyển đổi chuỗi có dấu tiếng Việt thành chuỗi không dấu ASCII an toàn cho HTTP headers và tên file."""
    if not text:
        return ""
    text = str(text).replace("đ", "d").replace("Đ", "D")
    nfkd = unicodedata.normalize('NFKD', text)
    ascii_text = "".join(c for c in nfkd if not unicodedata.combining(c))
    slug = "".join(c if (c.isalnum() or c in ("-", "_")) else "_" for c in ascii_text)
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug.strip("_")

def make_content_disposition(disposition_type: str, raw_filename: str) -> str:
    """Tạo header Content-Disposition chuẩn RFC 6266 / RFC 5987, an toàn latin-1 và hỗ trợ UTF-8."""
    base_name = raw_filename.rsplit(".", 1)[0] if "." in raw_filename else raw_filename
    ext = f".{raw_filename.rsplit('.', 1)[1]}" if "." in raw_filename else ""
    ascii_name = f"{to_ascii_slug(base_name)}{ext}"
    if not ascii_name or ascii_name == ext:
        ascii_name = f"document{ext}"
    utf8_encoded = urllib.parse.quote(raw_filename)
    return f'{disposition_type}; filename="{ascii_name}"; filename*=UTF-8\'\'{utf8_encoded}'

from engine import (
    ReportItem,
    FullMatrixReport,
    PRESET_DATASETS,
    calculate_consensus,
    extract_financial_data_from_text,
    is_report_expired,
    parse_report_date
)
from crawler import (
    crawl_url_content,
    parse_pdf_bytes,
    search_institutional_reports,
    fetch_reconciled_live_price,
    fetch_live_market_tape,
    fetch_stock_company_profile,
    fetch_stock_corporate_capital,
    fetch_edocs_reports,
    parse_edocs_item_to_report,
    generate_sector_institutional_reports,
    fetch_industry_reports,
    fetch_company_reports,
    get_ssi_fastconnect_status,
    get_synchronized_matrix_reports,
    _LIVE_PRICE_CACHE
)
from financial_data import (
    get_financial_data_bundle,
    calculate_dcf_model,
    calculate_multi_model_valuation,
    VIETNAM_STOCK_DIRECTORY,
    get_company_news_and_events,
    get_mini_chart_series,
    get_company_catalysts_and_projects
)
from company_database import (
    COMPANY_DATABASE,
    SECTOR_DATABASE,
    get_company,
    search_companies,
    get_all_sectors_summary,
    sync_from_google_sheets
)
from pdf_generator import generate_ctck_report_pdf, generate_matrix_table_pdf, generate_peer_comparison_pdf, generate_summary_note_pdf
from ssi_fastconnect import (
    SSI_API_CATALOG,
    SSI_CONFIG,
    SSIFastConnectClient,
    fetch_hybrid_ohlcv_data,
    calculate_technical_indicators,
    get_stock_depth_metrics,
    get_market_overview
)
from ai_learning_engine import (
    ai_scheduler,
    template_store,
    extract_advanced_knowledge,
    analyze_template_image_ai,
    apply_learned_catalysts_to_report,
    save_learned_ticker_catalysts,
    get_learned_ticker_catalysts,
    AI_LEARNED_CATALYSTS_FILE
)

from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Institutional Equity Research Matrix (IERM)",
    description="Fintech Research Co-Pilot & WebApp Engine for Vietnam Financial Market",
    version="1.0.0"
)

# Kích hoạt CORS toàn diện để hỗ trợ localhost, 127.0.0.1 và truy cập qua LAN
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Kích hoạt nén GZip toàn cục cho toàn bộ phản hồi API và Static Files (> 1KB)
# Giúp giảm 70% - 90% dung lượng payload truyền tải qua mạng
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Thư mục static UI
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(ROOT_DIR, "static")
os.makedirs(STATIC_DIR, exist_ok=True)

# Tự động đồng bộ nếu người dùng kéo thả file ra ngoài thư mục gốc trên GitHub
for _fn in ["index.html", "app.js", "styles.css"]:
    _root_f = os.path.join(ROOT_DIR, _fn)
    _stat_f = os.path.join(STATIC_DIR, _fn)
    if os.path.exists(_root_f) and not os.path.exists(_stat_f):
        try:
            import shutil
            shutil.copy2(_root_f, _stat_f)
        except Exception:
            pass

@app.middleware("http")
async def add_no_cache_headers(request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    elif path.startswith("/static/"):
        # Cho phép trình duyệt lưu đệm tài nguyên tĩnh (JS 740KB, CSS, fonts) để tăng tốc tải trang tức thì
        response.headers["Cache-Control"] = "public, max-age=3600, stale-while-revalidate=86400"
    return response

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
DATA_STORAGE_DIR = os.path.join(ROOT_DIR, "data")
os.makedirs(DATA_STORAGE_DIR, exist_ok=True)
app.mount("/data", StaticFiles(directory=DATA_STORAGE_DIR), name="data")


@app.on_event("startup")
async def startup_event():
    """Tự động làm nóng bộ nhớ đệm bảng giá SSI toàn thị trường và khởi động AI Learning Scheduler ngầm."""
    try:
        from knowledge_backup_manager import auto_protect_on_startup
        auto_protect_on_startup()
    except Exception as e:
        print(f"AI Knowledge auto-protect exception: {e}")

    try:
        from crawler import fetch_ssi_live_stock_quote
        asyncio.create_task(fetch_ssi_live_stock_quote("HPG"))
    except Exception as e:
        print(f"SSI startup pre-warm exception: {e}")

    try:
        asyncio.create_task(ai_scheduler.start_background_loop())
    except Exception as e:
        print(f"AI Learning Scheduler startup exception: {e}")

    # Tiến trình quét ngầm và nạp sẵn toàn bộ các mã có báo cáo phân tích về kho lưu trữ (Background Harvester)
    # Tuyệt đối tuân thủ FACT & DATA FIRST: Chỉ lưu trữ và hiển thị dữ liệu thật từ CTCK, không bao giờ suy diễn lấp chỗ trống.
    async def _prewarm_top_tickers():
        top_tickers = [
            "HPG", "VNM", "VCB", "SSI", "MWG", "FPT", "TCB", "MBB", "VIC", "VHM",
            "STB", "CTG", "ACB", "MSN", "VHC", "PVD", "PVS", "ANV", "DGC", "KBC",
            "IDC", "DXG", "DIG", "VCI", "HCM", "VND", "GEX", "VRE", "POW", "BSR",
            "PLX", "GAS", "REE", "PC1", "DCM", "DPM", "HAH", "GMD", "NKG", "HSG"
        ]
        await asyncio.sleep(3)  # Đợi server sẵn sàng hoàn toàn
        for tkr in top_tickers:
            try:
                # Pre-warm BCTC & Financial Analysis Bundle
                await asyncio.wait_for(get_financial_overview(tkr), timeout=10.0)
            except Exception:
                pass
            try:
                # Pre-warm Báo cáo đồng thuận định giá CTCK để phản hồi tức thì
                await asyncio.wait_for(get_preset_by_ticker(tkr, refresh=False), timeout=8.0)
            except Exception:
                pass
            await asyncio.sleep(0.5)

        # Sau khi làm nóng danh mục cốt lõi, quét ngầm nguồn Vietstock để phát hiện và nạp tự động toàn bộ mã có báo cáo mới
        while True:
            try:
                await asyncio.sleep(3600)  # Quét chu kỳ 1 giờ/lần
                from crawler import fetch_edocs_reports
                recent_items = await fetch_edocs_reports("", limit=50)
                harvested_tickers = set()
                import re
                for it in recent_items:
                    t_str = it.get("Title") or ""
                    m = re.match(r"^([A-Z]{3})\b", t_str.strip())
                    if m:
                        harvested_tickers.add(m.group(1))
                for h_tkr in harvested_tickers:
                    try:
                        await asyncio.wait_for(get_preset_by_ticker(h_tkr, refresh=True), timeout=15.0)
                    except Exception:
                        pass
                    await asyncio.sleep(1.0)
            except Exception as e_harv:
                print(f"[Background Report Harvester Error]: {e_harv}")
                await asyncio.sleep(600)

    try:
        asyncio.create_task(_prewarm_top_tickers())
    except Exception as e:
        print(f"Pre-warm startup exception: {e}")

    # Làm nóng bộ lọc thị trường ngầm để người dùng chuyển đổi bộ lọc nhận kết quả tức thì (0ms)
    async def _prewarm_market_screener():
        await asyncio.sleep(2)
        try:
            await _scan_and_compute_all_technical_signals(force_refresh=False)
            print("[SCREENER-PREWARM] Đã làm nóng bộ lọc kỹ thuật thị trường thành công!")
        except Exception as e:
            print(f"[SCREENER-PREWARM] Ngoại lệ làm nóng bộ lọc: {e}")

    try:
        asyncio.create_task(_prewarm_market_screener())
    except Exception as e:
        print(f"Screener pre-warm startup exception: {e}")



ADMIN_AUTH_FILE = os.path.join(ROOT_DIR, "data", "admin_auth.json")
DEFAULT_ADMIN_USER = "admin"
DEFAULT_ADMIN_PASSWORD = "325396"
ADMIN_RECOVERY_EMAIL = "hoabhk31@gmail.com"

def get_admin_auth_data() -> dict:
    os.makedirs(os.path.join(ROOT_DIR, "data"), exist_ok=True)
    if os.path.exists(ADMIN_AUTH_FILE):
        try:
            with open(ADMIN_AUTH_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "username" in data and "password" in data:
                    data.setdefault("recovery_email", ADMIN_RECOVERY_EMAIL)
                    data.setdefault("active_otp", None)
                    data.setdefault("otp_expires_at", 0)
                    return data
        except Exception as e:
            print(f"Error loading admin_auth.json: {e}")
    initial_data = {
        "username": DEFAULT_ADMIN_USER,
        "password": DEFAULT_ADMIN_PASSWORD,
        "recovery_email": ADMIN_RECOVERY_EMAIL,
        "active_otp": None,
        "otp_expires_at": 0
    }
    save_admin_auth_data(initial_data)
    return initial_data

def save_admin_auth_data(data: dict):
    os.makedirs(os.path.join(ROOT_DIR, "data"), exist_ok=True)
    with open(ADMIN_AUTH_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def send_recovery_otp_email(to_email: str, otp: str) -> dict:
    """
    Gửi email mã OTP phục hồi mật khẩu tới hoabhk31@gmail.com qua SMTP.
    Đồng thời ghi log an toàn vào data/admin_reset_email_log.txt để hỗ trợ khôi phục dự phòng.
    """
    os.makedirs(os.path.join(ROOT_DIR, "data"), exist_ok=True)
    log_path = os.path.join(ROOT_DIR, "data", "admin_reset_email_log.txt")
    timestamp_str = time.strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{timestamp_str}] Gửi mã OTP: {otp} tới email: {to_email} (Thời hạn 15 phút)\n"
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(log_line)

    smtp_host = os.environ.get("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.environ.get("SMTP_PORT", 587))
    smtp_user = os.environ.get("SMTP_USER", "")
    smtp_pass = os.environ.get("SMTP_PASS", "")
    smtp_from = os.environ.get("SMTP_FROM", smtp_user or "admin@ierm.finance")

    subject = f"[IERM Matrix] Mã xác nhận đổi mật khẩu Quản trị viên (Admin): {otp}"
    body_html = f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0f172a; color: #f8fafc; border: 1px solid #1e293b; border-radius: 12px; padding: 24px;">
        <h2 style="color: #38bdf8; margin-top: 0; border-bottom: 1px solid #334155; padding-bottom: 12px;">
            🛡️ IERM Institutional Matrix - Đặt Lại Mật Khẩu
        </h2>
        <p style="font-size: 14px; line-height: 1.6; color: #cbd5e1;">
            Xin chào Quản trị viên, bạn vừa yêu cầu đổi mật khẩu cho tài khoản <b>admin</b> trên hệ thống <b>IERM Financial Intelligence Matrix</b>.
        </p>
        <div style="background: #020617; border: 1px dashed #38bdf8; border-radius: 8px; padding: 18px; text-align: center; margin: 20px 0;">
            <span style="font-size: 12px; color: #94a3b8; display: block; margin-bottom: 6px;">MÃ XÁC THỰC OTP (Hiệu lực trong 15 phút):</span>
            <span style="font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #38bdf8; font-family: monospace;">{otp}</span>
        </div>
        <p style="font-size: 12px; color: #94a3b8; line-height: 1.5;">
            Nếu bạn không thực hiện yêu cầu này, vui lòng bỏ qua email. Mật khẩu hiện tại của bạn vẫn được bảo mật an toàn.
        </p>
        <hr style="border: 0; border-top: 1px solid #1e293b; margin: 20px 0;">
        <p style="font-size: 11px; color: #64748b; text-align: center;">
            IERM Intelligence Platform © 2026. Email tự động, vui lòng không phản hồi.
        </p>
    </div>
    """

    email_sent = False
    error_msg = ""
    if smtp_user and smtp_pass:
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = smtp_from
            msg["To"] = to_email
            msg.attach(MIMEText(f"Mã xác nhận OTP đặt lại mật khẩu admin: {otp} (Hiệu lực 15 phút).", "plain", "utf-8"))
            msg.attach(MIMEText(body_html, "html", "utf-8"))

            with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
                server.starttls()
                server.login(smtp_user, smtp_pass)
                server.sendmail(smtp_from, [to_email], msg.as_string())
            email_sent = True
        except Exception as e:
            error_msg = str(e)
            print(f"SMTP dispatch notice: {e}")

    return {
        "sent_via_smtp": email_sent,
        "smtp_error": error_msg,
        "recipient": to_email,
        "logged_locally": True
    }


class AdminAuthRequest(BaseModel):
    username: str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: str

class VerifyResetPasswordRequest(BaseModel):
    email: str
    otp: str
    new_password: str

def is_admin_authorized(
    user: Optional[str] = None,
    password: Optional[str] = None,
    auth_header: Optional[str] = None
) -> bool:
    auth_data = get_admin_auth_data()
    expected_user = auth_data.get("username", DEFAULT_ADMIN_USER)
    expected_password = auth_data.get("password", DEFAULT_ADMIN_PASSWORD)

    if (user or "").strip() == expected_user and (password or "").strip() == expected_password:
        return True
    if auth_header and auth_header.startswith("Basic "):
        try:
            import base64
            decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
            u, p = decoded.split(":", 1)
            if u.strip() == expected_user and p.strip() == expected_password:
                return True
        except Exception:
            pass
    return False

def enforce_admin_permission(
    x_admin_user: Optional[str] = None,
    x_admin_password: Optional[str] = None,
    authorization: Optional[str] = None,
    fallback_user: Optional[str] = None,
    fallback_password: Optional[str] = None
):
    """
    Bảo vệ nghiêm ngặt các thao tác ghi/xóa dữ liệu.
    Bắt buộc phải có tài khoản và mật khẩu Admin chính xác để chống phá hoại từ bên ngoài.
    """
    u = x_admin_user or fallback_user
    p = x_admin_password or fallback_password

    if not is_admin_authorized(u, p, authorization):
        raise HTTPException(
            status_code=403,
            detail="Yêu cầu quyền Quản trị viên (Admin) để thực hiện thao tác này. Chức năng đã được khóa an toàn để bảo vệ toàn vẹn dữ liệu."
        )


class CrawlRequest(BaseModel):
    url: str
    ticker: Optional[str] = "HPG"
    institution: Optional[str] = "CTCK"
    admin_user: Optional[str] = None
    admin_password: Optional[str] = None


class RawTextAnalysisRequest(BaseModel):
    raw_text: str
    ticker: Optional[str] = "HPG"
    institution: Optional[str] = "CTCK"
    admin_user: Optional[str] = None
    admin_password: Optional[str] = None


class ReconcileRequest(BaseModel):
    ticker: str
    company_name: Optional[str] = ""
    sector: Optional[str] = ""
    current_market_price: Optional[float] = None
    price_source_info: Optional[dict] = None
    reports: List[ReportItem]


class ExportRequest(BaseModel):
    report_data: Union[FullMatrixReport, Dict[str, Any]]


def normalize_full_matrix_dict(raw: Any) -> Dict[str, Any]:
    """Chuyển đổi an toàn dữ liệu ma trận sang dict chuẩn, tương thích cả Pydantic lẫn JSON raw."""
    if hasattr(raw, "model_dump"):
        d = raw.model_dump()
    elif hasattr(raw, "dict") and callable(raw.dict):
        d = raw.dict()
    elif isinstance(raw, dict):
        d = dict(raw)
    else:
        try:
            d = dict(raw)
        except Exception:
            d = {}

    cs = d.get("consensus_summary")
    if hasattr(cs, "model_dump"):
        d["consensus_summary"] = cs.model_dump()
    elif hasattr(cs, "dict") and callable(cs.dict):
        d["consensus_summary"] = cs.dict()
    elif not isinstance(cs, dict):
        d["consensus_summary"] = {}

    clean_matrix = []
    for it in d.get("matrix_table", []):
        r_dict = None
        if hasattr(it, "model_dump"):
            r_dict = it.model_dump()
        elif hasattr(it, "dict") and callable(it.dict):
            r_dict = it.dict()
        elif isinstance(it, dict):
            r_dict = dict(it)
        else:
            try:
                r_dict = dict(it)
            except Exception:
                pass
        if r_dict:
            r_date = r_dict.get("report_date")
            # Ẩn hoàn toàn các báo cáo đã quá 1.5 năm (> 548 ngày)
            if is_report_expired(r_date, max_days=548):
                continue
            clean_matrix.append(r_dict)
    d["matrix_table"] = clean_matrix
    return d


def safe_float(v, default=None):
    """Chuyển đổi an toàn giá trị bất kỳ sang float."""
    if v is None:
        return default
    if isinstance(v, (int, float)):
        return float(v)
    try:
        clean_v = str(v).replace("%", "").replace("+", "").replace(",", "").strip()
        return float(clean_v)
    except Exception:
        return default


class TemplateCreateUpdateRequest(BaseModel):
    id: Optional[str] = None
    name: str
    sector: str
    keywords: List[str] = []
    catalyst_rules: List[str] = []
    thesis_rules: List[str] = []
    risk_rules: List[str] = []
    sample_text: Optional[str] = ""


class LearningConfigRequest(BaseModel):
    enabled: Optional[bool] = None
    interval_hours: Optional[int] = None
    watchlist: Optional[List[str]] = None
    auto_ingest_matrix: Optional[bool] = None


class TriggerLearnRequest(BaseModel):
    tickers: Optional[List[str]] = None


class RestoreBackupRequest(BaseModel):
    filename: Optional[str] = None
    merge: bool = True


class GeminiKeyRequest(BaseModel):
    api_key: str



@app.get("/", response_class=HTMLResponse)
async def serve_dashboard():
    for candidate in [
        os.path.join(STATIC_DIR, "index.html"),
        os.path.join(ROOT_DIR, "index.html"),
    ]:
        if os.path.exists(candidate):
            with open(candidate, "r", encoding="utf-8") as f:
                return HTMLResponse(content=f.read())
    return HTMLResponse(
        "<div style='font-family:sans-serif;padding:30px;max-width:650px;margin:50px auto;border:1px solid #cbd5e1;border-radius:12px;background:#f8fafc;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);'>"
        "<h2 style='color:#e11d48;margin-top:0;'>⚠️ Chưa có file giao diện (index.html)</h2>"
        "<p style='color:#334155;line-height:1.6;'>Máy chủ Render đã kích hoạt thành công, nhưng repository trên GitHub của bạn <b>chưa có thư mục <code>static</code></b> (chứa <code>index.html</code>, <code>app.js</code>, <code>styles.css</code>).</p>"
        "<div style='background:#f1f5f9;padding:15px;border-radius:8px;border-left:4px solid #0284c7;margin:15px 0;'>"
        "<strong style='color:#0369a1;'>👉 Cách xử lý nhanh:</strong><br>"
        "Vào GitHub repository của bạn &rarr; bấm <b>Add file</b> &rarr; <b>Upload files</b> &rarr; tải thư mục <b><code>static</code></b> (hoặc cả 3 file <code>index.html</code>, <code>app.js</code>, <code>styles.css</code>) lên &rarr; Render sẽ tự tải lại web trong 1 phút."
        "</div>"
        "</div>"
    )


CLIENT_ERROR_LOGS = []

@app.post("/api/client-log")
async def log_client_error(data: dict):
    CLIENT_ERROR_LOGS.append(data)
    print(f"[CLIENT LOG/ERROR] {data}")
    return {"status": "ok", "total": len(CLIENT_ERROR_LOGS)}

@app.get("/api/client-log")
async def get_client_errors():
    return {"errors": CLIENT_ERROR_LOGS}



@app.get("/api/health")
async def health_check():
    return {
        "status": "online",
        "engine": "IERM Quantitative Engine v1.0",
        "available_presets": list(PRESET_DATASETS.keys())
    }


@app.get("/api/presets")
async def get_presets():
    return [
        {
            "ticker": k,
            "company_name": v.company_name,
            "sector": v.sector,
            "reports_count": len(v.matrix_table),
            "consensus_rating": v.consensus_summary.consensus_rating,
            "mean_target_price": v.consensus_summary.mean_target_price,
            "upside": v.consensus_summary.average_upside,
            "market_price": v.consensus_summary.current_market_price,
            "market_to_fair_value_ratio": v.consensus_summary.market_to_fair_value_ratio
        }
        for k, v in PRESET_DATASETS.items()
    ]


@app.get("/api/live-price/{ticker}")
async def get_live_price(ticker: str):
    """
    Lấy giá đóng cửa mới nhất trên chart Vietstock (https://finance.vietstock.vn/phan-tich-ky-thuat.htm)
    và đối chiếu với bảng giá của các CTCK (VNDirect, DNSE), lấy nguồn nào mới hơn.
    """
    clean_ticker = ticker.upper().strip()
    price_info = await fetch_reconciled_live_price(clean_ticker)
    return price_info


_SYNCHRONIZED_PRESETS_CACHE: Dict[str, FullMatrixReport] = {}
_SYNCHRONIZED_PRESETS_CACHE_TS: Dict[str, float] = {}
_PRESET_LOCKS: Dict[str, asyncio.Lock] = {}

_FIN_OVERVIEW_CACHE: Dict[str, Dict[str, Any]] = {}
_FIN_OVERVIEW_CACHE_TS: Dict[str, float] = {}

_PROFILE_CACHE: Dict[str, Dict[str, Any]] = {}
_PROFILE_CACHE_TS: Dict[str, float] = {}

_STMT_CACHE: Dict[str, Dict[str, Any]] = {}
_STMT_CACHE_TS: Dict[str, float] = {}

_HEALTH_CACHE: Dict[str, Dict[str, Any]] = {}
_HEALTH_CACHE_TS: Dict[str, float] = {}

_VALUATION_CACHE: Dict[str, Dict[str, Any]] = {}
_VALUATION_CACHE_TS: Dict[str, float] = {}

_PEERS_CACHE: Dict[str, Dict[str, Any]] = {}
_PEERS_CACHE_TS: Dict[str, float] = {}

_TECH_SIGNALS_CACHE: Dict[str, Dict[str, Any]] = {}
_TECH_SIGNALS_CACHE_TS: Dict[str, float] = {}

# Cache giá khớp thời gian thực đã đối soát (reconciled) — dùng chung tức thì giữa các module
_RECONCILED_LIVE_PRICE_CACHE: Dict[str, Dict[str, Any]] = {}
_RECONCILED_LIVE_PRICE_CACHE_TS: Dict[str, float] = {}

# Cache riêng cho /api/ai-learning/knowledge/{ticker} — tránh đọc file disk mỗi request
_KNOWLEDGE_CACHE: Dict[str, Dict[str, Any]] = {}
_KNOWLEDGE_CACHE_TS: Dict[str, float] = {}

# -----------------------------------------------------------------------
# TTL CONSTANTS — điều chỉnh tại một nơi, áp dụng toàn bộ server
# -----------------------------------------------------------------------
_TTL_PRESET       = 300.0   # Báo cáo đồng thuận CTCK — 5 phút
_TTL_FIN_OVERVIEW = 600.0   # BCTC bundle (Dupont, Piotroski, DCF) — 10 phút (ít thay đổi)
_TTL_PROFILE      = 600.0   # Company profile — 10 phút
_TTL_STMT         = 600.0   # Financial statements — 10 phút
_TTL_HEALTH       = 600.0   # Health scores — 10 phút
_TTL_VALUATION    = 600.0   # Valuation bundle — 10 phút
_TTL_PEERS        = 600.0   # Peer comparison — 10 phút
_TTL_KNOWLEDGE    = 120.0   # AI knowledge per ticker — 2 phút (cập nhật thường xuyên hơn)



@app.get("/api/preset/{ticker}")
async def get_preset_by_ticker(ticker: str, sync_live_price: bool = True, refresh: bool = False):
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()

    # Tự động nạp và kiểm tra sự kiện quyền mới nhất từ cache/API
    from corporate_actions import sync_ticker_corporate_actions_online, load_corporate_actions_cache, get_ticker_corporate_actions
    load_corporate_actions_cache()

    cached_rep = _SYNCHRONIZED_PRESETS_CACHE.get(clean_ticker)
    cached_time = _SYNCHRONIZED_PRESETS_CACHE_TS.get(clean_ticker, 0)
    if not refresh and cached_rep and (now_ts - cached_time) < 1800.0 and cached_rep.ticker == clean_ticker:
        # Kiểm tra xem danh sách corporate actions hiện tại có sự kiện mới hơn số lượng đã áp dụng trong cache không
        current_cas = get_ticker_corporate_actions(clean_ticker, auto_sync=False)
        cached_ca_count = len(getattr(cached_rep, "corporate_actions", []) or [])
        if len(current_cas) <= cached_ca_count:
            return cached_rep

    # 2. Khóa concurrency để tránh gọi đúp song song nhiều crawler cùng 1 mã
    if clean_ticker not in _PRESET_LOCKS:
        _PRESET_LOCKS[clean_ticker] = asyncio.Lock()

    async with _PRESET_LOCKS[clean_ticker]:
        now_ts = time.time()
        if not refresh:
            cached_rep = _SYNCHRONIZED_PRESETS_CACHE.get(clean_ticker)
            cached_time = _SYNCHRONIZED_PRESETS_CACHE_TS.get(clean_ticker, 0)
            if cached_rep and (now_ts - cached_time) < 1800.0 and cached_rep.ticker == clean_ticker:
                current_cas = get_ticker_corporate_actions(clean_ticker, auto_sync=False)
                cached_ca_count = len(getattr(cached_rep, "corporate_actions", []) or [])
                if len(current_cas) <= cached_ca_count:
                    return cached_rep

        stock_meta = VIETNAM_STOCK_DIRECTORY.get(clean_ticker, {})
        cached_name = stock_meta.get("name", f"Công ty Cổ phần {clean_ticker}")
        cached_sector = stock_meta.get("sector", "Doanh nghiệp niêm yết")

        # Xác định fallback price ban đầu chính xác cho clean_ticker trước khi gọi crawl:
        known_prices = {"MWG": 73200.0, "HPG": 21700.0, "FPT": 72800.0, "TCB": 23900.0, "VHM": 42100.0, "VNM": 65000.0, "MSN": 72000.0, "MBB": 24000.0, "ACB": 25000.0, "VIC": 42000.0}
        initial_price = 0.0
        if clean_ticker in _LIVE_PRICE_CACHE and _LIVE_PRICE_CACHE[clean_ticker].get("latest_close", 0) > 0:
            initial_price = float(_LIVE_PRICE_CACHE[clean_ticker]["latest_close"])
        elif clean_ticker in _PROFILE_CACHE and _PROFILE_CACHE[clean_ticker].get("current_market_price", 0) > 0:
            initial_price = float(_PROFILE_CACHE[clean_ticker]["current_market_price"])
        elif clean_ticker in PRESET_DATASETS:
            rep = PRESET_DATASETS[clean_ticker]
            if getattr(rep, "current_price", 0) > 0:
                initial_price = float(rep.current_price)
            elif rep.consensus_summary and rep.consensus_summary.current_market_price > 0:
                initial_price = float(rep.consensus_summary.current_market_price)
        if initial_price <= 0:
            from company_database import get_company
            db_c = get_company(clean_ticker)
            if db_c:
                initial_price = float(db_c.get("price") or db_c.get("close_price") or 0.0)
        if initial_price <= 0 and clean_ticker in _TECH_CANDLES_CACHE:
            candles = _TECH_CANDLES_CACHE[clean_ticker]
            if candles and isinstance(candles, list) and len(candles) > 0:
                initial_price = float(candles[-1].get("c", candles[-1].get("close", 0.0)))
        if initial_price <= 0:
            initial_price = known_prices.get(clean_ticker, 25000.0)

        # Tối ưu hóa siêu tốc: Chạy song song Profile, Giá Live và Lịch Sự Kiện Quyền
        async def _safe_profile():
            try:
                return await asyncio.wait_for(fetch_stock_company_profile(clean_ticker), timeout=1.5)
            except Exception:
                return {}

        async def _safe_price():
            try:
                return await asyncio.wait_for(fetch_reconciled_live_price(clean_ticker), timeout=2.5)
            except Exception:
                return None

        async def _safe_ca():
            try:
                from corporate_actions import sync_ticker_corporate_actions_online, load_corporate_actions_cache
                load_corporate_actions_cache()
                await asyncio.wait_for(sync_ticker_corporate_actions_online(clean_ticker), timeout=1.5)
            except Exception:
                pass

        base_reports = []
        base_causality = []
        base_disensus = []
        final_comp_name = cached_name
        final_sect_name = cached_sector
        if clean_ticker in PRESET_DATASETS:
            report = PRESET_DATASETS[clean_ticker]
            base_reports = [r for r in report.matrix_table if not is_report_expired(r.report_date, max_days=548)] if report.matrix_table else []
            base_causality = report.causality_analysis or []
            base_disensus = report.disensus_table or []
            final_comp_name = report.company_name
            final_sect_name = report.sector

        # Khi refresh=True (người dùng bấm Làm mới hoặc đồng bộ), cấp đủ 25.0s để crawler tải & bóc tách PDF đầy đủ
        # Nếu không refresh, cho phép 12.0s để hoàn tất các tác vụ trích xuất PDF chất lượng cao
        reports_timeout = 25.0 if refresh else 12.0

        async def _safe_reports():
            try:
                return await asyncio.wait_for(
                    get_synchronized_matrix_reports(
                        ticker=clean_ticker,
                        base_reports=base_reports,
                        comp_name=final_comp_name,
                        sector_name=final_sect_name,
                        market_p=initial_price,
                        max_reports=20
                    ),
                    timeout=reports_timeout
                )
            except Exception as e_sr:
                print(f"[_safe_reports timeout or error for {clean_ticker}]: {e_sr}")
                return base_reports

        prof_res, live_res, _, rep_res = await asyncio.gather(
            _safe_profile(), _safe_price(), _safe_ca(), _safe_reports(),
            return_exceptions=True
        )
        profile = prof_res if isinstance(prof_res, dict) else {}
        live_info = live_res if isinstance(live_res, dict) else None
        market_p = 0.0
        if live_info and live_info.get("latest_close", 0) > 0:
            market_p = float(live_info["latest_close"])
        elif initial_price > 0:
            market_p = initial_price
        else:
            market_p = 25000.0

        raw_synced = rep_res if isinstance(rep_res, list) else base_reports
        synced_reports = [r for r in raw_synced if not is_report_expired(r.report_date, max_days=548)]

        comp_name = profile.get("name") or final_comp_name
        sect_name = profile.get("sector") or final_sect_name
        final_comp_name = comp_name
        final_sect_name = sect_name

        # NGUYÊN TẮC FACT & DATA FIRST: Tuyệt đối KHÔNG tự động suy diễn sinh báo cáo giả lập chuẩn ngành lấp chỗ trống.
        # Nếu mã không có báo cáo phân tích thực tế từ CTCK, giữ nguyên danh sách rỗng để người dùng nắm rõ sự thật.
        # Giao diện frontend sẽ hiển thị thông báo trung thực "Chưa có báo cáo phân tích từ các CTCK".

        # Đồng bộ hóa ngành nghề theo ma trận 23 ngành chuẩn toàn diện
        from adaptive_growth_engine import classify_business_model
        from sector_peers_matrix import get_universal_sector_peer_config

        model_info = classify_business_model(clean_ticker, final_comp_name, final_sect_name)
        model_key = model_info.get("model_key", "HOLDING_CONGLOMERATE")
        model_badge = model_info.get("badge_text", final_sect_name)
        sector_cfg = get_universal_sector_peer_config(model_key, clean_ticker)
        standard_sector = sector_cfg.get("sector_name") or model_badge or final_sect_name
        final_sect_name = standard_sector

        # Nếu market_p hợp lệ, đồng bộ nhanh upside cho synced_reports
        if market_p > 0:
            for r in synced_reports:
                if r.target_price > 0 and not getattr(r, "is_technical", False) and not is_report_expired(r.report_date):
                    r.current_price_at_report = market_p
                    eff_tp = r.adjusted_target_price if (getattr(r, "is_price_adjusted", False) and r.adjusted_target_price) else r.target_price
                    r.upside_percent = round(((eff_tp - market_p) / market_p) * 100.0, 1)

        reconciled = calculate_consensus(
            reports=synced_reports,
            ticker=clean_ticker,
            company_name=final_comp_name,
            sector=final_sect_name,
            current_market_price=market_p,
            price_source_info=live_info
        )

        # Đảm bảo mã ticker luôn là clean_ticker
        reconciled.ticker = clean_ticker
        if final_comp_name:
            reconciled.company_name = final_comp_name
        reconciled.sector = final_sect_name
        reconciled.growth_model_key = model_key
        reconciled.model_badge_text = model_badge
        reconciled.recommended_valuation = sector_cfg.get("recommended_valuation")

        if base_causality and len(base_causality) > len(reconciled.causality_analysis):
            reconciled.causality_analysis = base_causality
        if base_disensus and len(reconciled.disensus_table) == 0:
            reconciled.disensus_table = base_disensus

        # Tự động đồng bộ các luận điểm tăng trưởng (Catalysts) và rủi ro mà AI đã học vào Báo cáo đa tổ chức
        try:
            reconciled = apply_learned_catalysts_to_report(reconciled)
        except Exception as e:
            print(f"Error applying AI learned catalysts for {clean_ticker}: {e}")

        # Chỉ lưu cache dài hạn khi đã lấy được danh sách báo cáo
        if synced_reports or clean_ticker in PRESET_DATASETS:
            _SYNCHRONIZED_PRESETS_CACHE[clean_ticker] = reconciled
            _SYNCHRONIZED_PRESETS_CACHE_TS[clean_ticker] = time.time()
        return reconciled


@app.get("/api/corporate-actions/{ticker}")
async def get_corporate_actions_endpoint(ticker: str):
    """
    Truy xuất danh sách các sự kiện quyền (GDKHQ: cổ tức tiền mặt, cổ tức cổ phiếu, phát hành thêm)
    và hệ số điều chỉnh giá tương ứng để Nhà đầu tư tra cứu và đối chiếu.
    Tham chiếu: Vietstock, Simplize Open API & Sở GDCK (HOSE/HNX).
    """
    clean_ticker = ticker.upper().strip()
    from corporate_actions import get_ticker_corporate_actions, sync_ticker_corporate_actions_online
    try:
        await asyncio.wait_for(sync_ticker_corporate_actions_online(clean_ticker), timeout=2.0)
    except Exception:
        pass
    actions = get_ticker_corporate_actions(clean_ticker)
    return {
        "ticker": clean_ticker,
        "count": len(actions),
        "source": "Vietstock, Simplize Open API & Sở GDCK (HOSE/HNX)",
        "corporate_actions": actions
    }


class CustomCorporateActionModel(BaseModel):
    ticker: str
    ex_date: str
    record_date: Optional[str] = ""
    execution_date: Optional[str] = ""
    event_type: str = "dividend_cash"
    title: str
    cash_amount: float = 0.0
    stock_ratio: float = 0.0
    rights_ratio: float = 0.0
    rights_price: float = 0.0
    description: Optional[str] = ""
    source: Optional[str] = "Công bố thông tin trực tiếp / Nghị quyết HĐQT"


@app.post("/api/corporate-actions/add")
async def add_corporate_action_endpoint(req: CustomCorporateActionModel):
    """
    Cho phép Nhà đầu tư hoặc Chuyên viên phân tích chủ động bổ sung sự kiện quyền
    (như cổ tức tiền, cổ phiếu thưởng, phát hành thêm) ngay khi doanh nghiệp vừa ra Nghị quyết HĐQT.
    """
    from corporate_actions import add_custom_corporate_action
    added = add_custom_corporate_action(req.ticker, req.model_dump())
    # Xóa cache reconciled cũ để tính lại ma trận định giá ngay lập tức
    clean_t = req.ticker.upper().strip()
    if clean_t in _SYNCHRONIZED_PRESETS_CACHE:
        del _SYNCHRONIZED_PRESETS_CACHE[clean_t]
    return {
        "success": True,
        "message": f"Đã cập nhật sự kiện quyền cho mã {clean_t} thành công",
        "action": added
    }


@app.get("/api/ssi/status")
async def get_ssi_status():
    """
    Trả về trạng thái kết nối & chẩn đoán của dịch vụ SSI FastConnect Data API.
    """
    return get_ssi_fastconnect_status()


@app.get("/api/market-tape")
async def get_market_tape(ticker: Optional[str] = None):
    """
    Lấy dữ liệu chỉ số thị trường (VN-INDEX, VN30) và các mã cổ phiếu tiêu biểu
    trực tiếp từ API bảng giá các CTCK (DNSE Entrade, Vietstock).
    """
    tape = await fetch_live_market_tape(ticker)
    return tape


@app.get("/api/industry-reports")
async def get_industry_reports(
    ticker: Optional[str] = "HPG",
    keyword: Optional[str] = None,
    report_type: Optional[int] = None,
    source: Optional[str] = None,
    all_industries: Optional[bool] = False,
    limit: int = 50
):
    """
    Truy xuất danh sách báo cáo phân tích ngành, báo cáo hàng hóa và vĩ mô liên quan trực tiếp
    tới mã cổ phiếu đang xem (từ Vietstock eDocs, các CTCK và FireAnt).
    Khi all_industries=True: hiển thị toàn bộ báo cáo mới nhất của tất cả các ngành.
    """
    res = await fetch_industry_reports(
        ticker=ticker,
        keyword=keyword,
        report_type_id=report_type,
        source_name=source,
        all_industries=bool(all_industries),
        page_size=limit
    )
    return res


@app.get("/api/company-reports")
async def get_company_reports(
    ticker: Optional[str] = "HPG",
    keyword: Optional[str] = None,
    report_type: Optional[int] = None,
    source: Optional[str] = None,
    limit: int = 50
):
    """
    Truy xuất danh sách báo cáo phân tích doanh nghiệp (báo cáo định giá, khuyến nghị, cập nhật KQKD)
    dành riêng cho mã cổ phiếu chỉ định (từ Vietstock eDocs, các CTCK uy tín và ma trận IERM).
    """
    res = await fetch_company_reports(
        ticker=ticker,
        keyword=keyword,
        report_type_id=report_type,
        source_name=source,
        page_size=limit
    )
    return res


@app.get("/api/benchmark-recommendations")
async def get_benchmark_recommendations():
    """
    Trả về danh sách các mã cổ phiếu tiêu biểu kèm khuyến nghị và upside đồng thuận mới nhất
    từ các CTCK để hiển thị trên thanh chip điều hướng nhanh (MÃ TIÊU BIỂU).
    """
    benchmark_symbols = ["HPG", "SSI", "HCM", "VNM", "FPT", "MWG", "GEX", "PDR"]
    results = []
    for sym in benchmark_symbols:
        rep = _SYNCHRONIZED_PRESETS_CACHE.get(sym) or PRESET_DATASETS.get(sym)
        if rep:
            cs = rep.consensus_summary
            if cs and (cs.average_upside < 0 or (cs.mean_target_price > 0 and cs.current_market_price > cs.mean_target_price)):
                short_rating = "VƯỢT MỤC TIÊU"
                raw_rating = cs.consensus_rating
            elif cs and (cs.mean_target_price <= 0 or "THEO DÕI" in (cs.consensus_rating or "").upper()):
                short_rating = "THEO DÕI"
                raw_rating = cs.consensus_rating
            else:
                raw_rating = cs.consensus_rating.split("(")[0].strip() if cs else "MUA"
                short_rating = "MUA" if "MUA" in raw_rating else ("KHẢ QUAN" if "KHẢ QUAN" in raw_rating else ("TÍCH LŨY" if "TÍCH LŨY" in raw_rating else "NẮM GIỮ"))
            results.append({
                "ticker": sym,
                "name": rep.company_name,
                "sector": rep.sector,
                "rating": short_rating,
                "full_rating": raw_rating,
                "upside": cs.average_upside if cs else 25.0,
                "target_price": cs.mean_target_price if cs else 0,
                "current_price": cs.current_market_price if cs else rep.current_price
            })
        else:
            info = VIETNAM_STOCK_DIRECTORY.get(sym, {})
            results.append({
                "ticker": sym,
                "name": info.get("name", sym),
                "sector": info.get("sector", "Doanh nghiệp niêm yết"),
                "rating": "KHẢ QUAN",
                "full_rating": "KHẢ QUAN",
                "upside": 25.0,
                "target_price": 0,
                "current_price": 25000
            })
    return results

class DcfCustomRequest(BaseModel):
    ticker: str
    wacc: float = 11.5
    terminal_g: float = 2.5
    fcf_growth_rate: float = 15.0
    projection_years: int = 5
    current_market_price: Optional[float] = None


class MultiModelValuationRequest(BaseModel):
    ticker: str
    wacc: float = 11.5
    terminal_g: float = 2.5
    growth_rate: float = 12.0
    risk_free_rate: float = 4.8
    industry_pe: Optional[float] = None
    industry_pb: Optional[float] = None
    weights: Optional[Dict[str, float]] = None
    custom_weights: Optional[Dict[str, float]] = None
    current_market_price: Optional[float] = None



@app.get("/api/financial-overview/{ticker}")
async def get_financial_overview(ticker: str):
    """
    Truy xuất toàn bộ phân tích BCTC, Dupont 3 & 5 bước, Piotroski F-score, Altman Z-score, và định giá DCF.
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    if clean_ticker in _FIN_OVERVIEW_CACHE and (now_ts - _FIN_OVERVIEW_CACHE_TS.get(clean_ticker, 0)) < _TTL_FIN_OVERVIEW:
        return _FIN_OVERVIEW_CACHE[clean_ticker]

    stock_meta = VIETNAM_STOCK_DIRECTORY.get(clean_ticker, {})
    default_name = stock_meta.get("name")
    default_sector = stock_meta.get("sector")

    async def _safe_p():
        # 1. Kiểm tra cache giá khớp thời gian thực đã đối soát (ưu tiên tối đa tính đồng bộ)
        if clean_ticker in _RECONCILED_LIVE_PRICE_CACHE and (time.time() - _RECONCILED_LIVE_PRICE_CACHE_TS.get(clean_ticker, 0)) < 180.0:
            cached_info = _RECONCILED_LIVE_PRICE_CACHE[clean_ticker]
            if cached_info and "latest_close" in cached_info:
                return float(cached_info["latest_close"])
        try:
            live_price_info = await asyncio.wait_for(fetch_reconciled_live_price(clean_ticker), timeout=4.5)
            if live_price_info and "latest_close" in live_price_info:
                _RECONCILED_LIVE_PRICE_CACHE[clean_ticker] = live_price_info
                _RECONCILED_LIVE_PRICE_CACHE_TS[clean_ticker] = time.time()
                return float(live_price_info["latest_close"])
            return 25000.0
        except Exception:
            return 25000.0

    async def _safe_prof():
        try:
            return await asyncio.wait_for(fetch_stock_company_profile(clean_ticker), timeout=3.0)
        except Exception:
            return {}

    async def _safe_cap():
        try:
            return await asyncio.wait_for(fetch_stock_corporate_capital(clean_ticker), timeout=3.0)
        except Exception:
            return {}

    p_res, prof_res, cap_res = await asyncio.gather(_safe_p(), _safe_prof(), _safe_cap(), return_exceptions=True)
    market_p = p_res if isinstance(p_res, (int, float)) else 25000.0
    profile = prof_res if isinstance(prof_res, dict) else {}
    capital_info = cap_res if isinstance(cap_res, dict) else {}

    data = await asyncio.to_thread(
        get_financial_data_bundle,
        clean_ticker,
        current_market_price=market_p,
        company_name=profile.get("name") or default_name,
        sector=profile.get("sector") or default_sector,
        corporate_capital=capital_info
    )

    # Làm giàu dữ liệu cổ tức thực tế cho peers_data trong bundle tài chính
    if data and isinstance(data.get("peers_data"), dict):
        try:
            data["peers_data"] = await enrich_peers_with_realized_dividends(data["peers_data"])
        except Exception:
            pass

    _FIN_OVERVIEW_CACHE[clean_ticker] = data
    _FIN_OVERVIEW_CACHE_TS[clean_ticker] = now_ts

    if data:
        # Tự động đồng bộ sang toàn bộ các bộ nhớ đệm module con
        _PROFILE_CACHE[clean_ticker] = data.get("company_profile", {})
        _PROFILE_CACHE_TS[clean_ticker] = now_ts
        _STMT_CACHE[clean_ticker] = {
            "ticker": clean_ticker,
            "industry_model": data.get("industry_model", "generic"),
            "statements_annual": data.get("statements_annual", {}),
            "statements_quarterly": data.get("statements_quarterly", {})
        }
        _STMT_CACHE_TS[clean_ticker] = now_ts
        _HEALTH_CACHE[clean_ticker] = {
            "ticker": clean_ticker,
            "dupont": data.get("dupont", {}),
            "piotroski": data.get("piotroski", {}),
            "altman_z": data.get("altman_z", {})
        }
        _HEALTH_CACHE_TS[clean_ticker] = now_ts
        _VALUATION_CACHE[clean_ticker] = {
            "ticker": clean_ticker,
            "valuation": data.get("valuation", {})
        }
        _VALUATION_CACHE_TS[clean_ticker] = now_ts
        _PEERS_CACHE[clean_ticker] = data.get("peers_data", {})
        _PEERS_CACHE_TS[clean_ticker] = now_ts

    return data


@app.get("/api/company-profile/{ticker}")
async def get_company_profile_endpoint(ticker: str):
    """
    Module 1: Truy xuất siêu tốc thông tin hồ sơ doanh nghiệp & thị giá (< 30ms).
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    if clean_ticker in _PROFILE_CACHE and (now_ts - _PROFILE_CACHE_TS.get(clean_ticker, 0)) < _TTL_PROFILE:
        return _PROFILE_CACHE[clean_ticker]

    if clean_ticker in _FIN_OVERVIEW_CACHE and (now_ts - _FIN_OVERVIEW_CACHE_TS.get(clean_ticker, 0)) < _TTL_FIN_OVERVIEW:
        prof = _FIN_OVERVIEW_CACHE[clean_ticker].get("company_profile", {})
        if prof:
            _PROFILE_CACHE[clean_ticker] = prof
            _PROFILE_CACHE_TS[clean_ticker] = now_ts
            return prof

    stock_meta = VIETNAM_STOCK_DIRECTORY.get(clean_ticker, {})
    from company_database import get_company
    db = get_company(clean_ticker) or {}

    live_p = 25000.0
    try:
        live_p_info = await asyncio.wait_for(fetch_reconciled_live_price(clean_ticker), timeout=1.0)
        if live_p_info and live_p_info.get("latest_close"):
            live_p = float(live_p_info["latest_close"])
    except Exception:
        live_p = float(db.get("close_price") or db.get("price") or 25000.0)

    shares = float(stock_meta.get("shares") or db.get("shares_outstanding_mil") or 1000.0)
    mcap = round(shares * live_p / 1000.0, 1) if live_p > 0 else 25000.0

    profile = {
        "ticker": clean_ticker,
        "name": stock_meta.get("name") or db.get("name") or f"CTCP {clean_ticker}",
        "sector": stock_meta.get("sector") or db.get("fiintrade_sector") or "Doanh nghiệp niêm yết",
        "market_cap_bil": mcap,
        "current_market_price": live_p,
        "shares_outstanding_mil": shares,
        "shares_listed_mil": float(stock_meta.get("shares_listed") or shares),
        "charter_capital_bil": round(shares * 10, 1),
        "beta": float(db.get("beta") or 1.15),
        "foreign_ownership_pct": float(stock_meta.get("foreign_pct") or 15.0),
        "domestic_ownership_pct": round(100.0 - float(stock_meta.get("foreign_pct") or 15.0), 1),
        "dividend_yield_pct": float(stock_meta.get("dividend_yield") or 2.5),
        "description": db.get("description") or f"Doanh nghiệp niêm yết hàng đầu trong ngành {stock_meta.get('sector', 'Doanh nghiệp niêm yết')}."
    }

    _PROFILE_CACHE[clean_ticker] = profile
    _PROFILE_CACHE_TS[clean_ticker] = now_ts
    return profile


@app.get("/api/financial-statements/{ticker}")
async def get_financial_statements_endpoint(ticker: str):
    """
    Module 2: Truy xuất riêng BCTC Năm và Quý cho Tab BCTC & Khung 1 Note (< 100ms).
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    if clean_ticker in _STMT_CACHE and (now_ts - _STMT_CACHE_TS.get(clean_ticker, 0)) < _TTL_STMT:
        return _STMT_CACHE[clean_ticker]

    data = await get_financial_overview(clean_ticker)
    res = {
        "ticker": clean_ticker,
        "industry_model": data.get("industry_model", "generic"),
        "statements_annual": data.get("statements_annual", {}),
        "statements_quarterly": data.get("statements_quarterly", {})
    }
    _STMT_CACHE[clean_ticker] = res
    _STMT_CACHE_TS[clean_ticker] = now_ts
    return res


@app.get("/api/financial-health/{ticker}")
async def get_financial_health_endpoint(ticker: str):
    """
    Module 3: Truy xuất riêng bộ chỉ số DuPont, Piotroski, Altman Z phục vụ Tab Sức khỏe tài chính.
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    if clean_ticker in _HEALTH_CACHE and (now_ts - _HEALTH_CACHE_TS.get(clean_ticker, 0)) < _TTL_HEALTH:
        return _HEALTH_CACHE[clean_ticker]

    data = await get_financial_overview(clean_ticker)
    res = {
        "ticker": clean_ticker,
        "dupont": data.get("dupont", {}),
        "piotroski": data.get("piotroski", {}),
        "altman_z": data.get("altman_z", {})
    }
    _HEALTH_CACHE[clean_ticker] = res
    _HEALTH_CACHE_TS[clean_ticker] = now_ts
    return res


@app.get("/api/valuation-bundle/{ticker}")
async def get_valuation_bundle_endpoint(ticker: str):
    """
    Module 4: Truy xuất riêng gói định giá DCF, Graham, Bands phục vụ Tab Định giá (Lazy Loading).
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    if clean_ticker in _VALUATION_CACHE and (now_ts - _VALUATION_CACHE_TS.get(clean_ticker, 0)) < _TTL_VALUATION:
        return _VALUATION_CACHE[clean_ticker]

    data = await get_financial_overview(clean_ticker)
    res = {
        "ticker": clean_ticker,
        "valuation": data.get("valuation", {})
    }
    if res["valuation"] and isinstance(res["valuation"], dict):
        res["valuation"]["ticker"] = clean_ticker
    _VALUATION_CACHE[clean_ticker] = res
    _VALUATION_CACHE_TS[clean_ticker] = now_ts
    return res


async def enrich_peers_with_realized_dividends(peers: Dict[str, Any]) -> Dict[str, Any]:
    """
    Cập nhật cổ tức thực tế từ lịch sử sự kiện quyền (HOSE/HNX) cho danh sách đối thủ trong ngành.
    Nguyên tắc: KHÔNG suy diễn — nếu có dữ liệu xác nhận trong 12 tháng qua thì dùng thực tế (kể cả 0.0).
    """
    if not isinstance(peers, dict):
        return peers
    try:
        from corporate_actions import get_detailed_corporate_actions_dividend_summary
        from crawler import fetch_reconciled_live_price
        from financial_data import VIETNAM_STOCK_DIRECTORY

        peer_list = peers.get("peers", []) if isinstance(peers, dict) else []
        if peer_list:
            peer_tickers = [p.get("ticker", "") for p in peer_list]

            async def _safe_price(tk: str):
                if not tk:
                    return None
                try:
                    return await asyncio.wait_for(fetch_reconciled_live_price(tk), timeout=3.0)
                except Exception:
                    return None

            price_results = await asyncio.gather(*[_safe_price(tk) for tk in peer_tickers])

            target_tk_upper = peers.get("target_ticker", "").upper()
            for peer, price_info in zip(peer_list, price_results):
                peer_tk = peer.get("ticker", "")
                if not peer_tk:
                    continue
                try:
                    peer_price = float(price_info.get("latest_close", 0)) if price_info else 0
                    if price_info and "latest_close" in price_info:
                        _RECONCILED_LIVE_PRICE_CACHE[peer_tk] = price_info
                        _RECONCILED_LIVE_PRICE_CACHE_TS[peer_tk] = time.time()
                    if peer_price <= 0:
                        dir_info = VIETNAM_STOCK_DIRECTORY.get(peer_tk, {})
                        shares_m = float(peer.get("shares_outstanding_mil") or dir_info.get("shares") or 0)
                        mcap = float(peer.get("market_cap_bil", 0) or 0)
                        if shares_m > 0 and mcap > 0:
                            peer_price = (mcap * 1e9) / (shares_m * 1e6)
                        else:
                            peer_price = float(peer.get("price") or 25000.0)

                    # Trích xuất tổng hợp chi tiết cổ tức tiền mặt (VND/CP), CP thưởng & cổ tức CP (%)
                    div_summary = get_detailed_corporate_actions_dividend_summary(peer_tk, peer_price)
                    peer["dividend_cash_amount"] = div_summary["cash_amount"]
                    peer["dividend_yield_pct"] = div_summary["yield_pct"]
                    peer["dividend_par_pct"] = div_summary["par_pct"]
                    peer["dividend_cash_display"] = div_summary["cash_display"]
                    peer["stock_bonus_pct"] = div_summary["bonus_pct"]
                    peer["stock_dividend_pct"] = div_summary["stock_div_pct"]
                    peer["total_stock_pct"] = div_summary["total_stock_pct"]
                    peer["stock_bonus_display"] = div_summary["stock_display"]
                    peer["dividend_yield_source"] = div_summary["source"]
                    peer["stock_bonus_source"] = div_summary["source"]
                    # Aliases cho KPI ngành ngân hàng & chứng khoán
                    if "nim_ratio" in peer:
                        peer["nim_percent"] = peer["nim_ratio"]
                    if "casa_ratio" in peer:
                        peer["casa_percent"] = peer["casa_ratio"]
                    if "npl_ratio" in peer:
                        peer["npl_percent"] = peer["npl_ratio"]
                    if "margin_balance_bil" in peer:
                        peer["margin_loan_bil"] = peer["margin_balance_bil"]
                    if "land_bank_ha" in peer:
                        peer["backlog_bil"] = peer["land_bank_ha"]
                except Exception:
                    peer["dividend_yield_source"] = "estimate"
                    peer["stock_bonus_source"] = "estimate"

            # === Chuẩn hóa cột "Cổ tức TM" và "Thưởng / Cổ tức CP" trong sector_kpi_columns ===
            kpi_cols = peers.get("sector_kpi_columns", [])
            for c in kpi_cols:
                f_name = c.get("field")
                if f_name == "nim_ratio":
                    c["field"] = "nim_percent"
                elif f_name == "casa_ratio":
                    c["field"] = "casa_percent"
                elif f_name == "npl_ratio":
                    c["field"] = "npl_percent"
                elif f_name == "margin_balance_bil":
                    c["field"] = "margin_loan_bil"
                elif f_name == "land_bank_ha":
                    c["field"] = "backlog_bil"
            has_dividend_col = any(c.get("field") == "dividend_yield_pct" for c in kpi_cols)
            has_stock_bonus_col = any(c.get("field") == "stock_bonus_pct" for c in kpi_cols)

            if has_dividend_col and not has_stock_bonus_col:
                div_idx = next(i for i, c in enumerate(kpi_cols) if c.get("field") == "dividend_yield_pct")
                kpi_cols[div_idx]["label"] = "Cổ tức TM"
                kpi_cols[div_idx]["unit"] = "đ/CP"
                kpi_cols[div_idx]["color"] = "emerald"
                kpi_cols.insert(div_idx + 1, {
                    "field": "stock_bonus_pct",
                    "label": "Thưởng / Cổ tức CP",
                    "unit": "%",
                    "color": "amber"
                })
            elif not has_dividend_col and not has_stock_bonus_col:
                kpi_cols.append({
                    "field": "dividend_yield_pct",
                    "label": "Cổ tức TM",
                    "unit": "đ/CP",
                    "color": "emerald"
                })
                kpi_cols.append({
                    "field": "stock_bonus_pct",
                    "label": "Thưởng / Cổ tức CP",
                    "unit": "%",
                    "color": "amber"
                })
            else:
                for c in kpi_cols:
                    if c.get("field") == "dividend_yield_pct":
                        c["label"] = "Cổ tức TM"
                        c["unit"] = "đ/CP"
                        c["color"] = "emerald"
                    elif c.get("field") == "stock_bonus_pct":
                        c["label"] = "Thưởng / Cổ tức CP"
                        c["unit"] = "%"
                        c["color"] = "amber"
    except Exception:
        pass
    return peers


@app.get("/api/peers/{ticker}")
async def get_peers_comparison(ticker: str):
    """
    Truy xuất ma trận so sánh các doanh nghiệp cùng ngành (Peers Comparison Matrix).
    Đã được làm giàu với dữ liệu cổ tức tiền mặt & cổ phiếu thưởng thực tế (không suy diễn).
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    if clean_ticker in _PEERS_CACHE and (now_ts - _PEERS_CACHE_TS.get(clean_ticker, 0)) < _TTL_PEERS:
        return _PEERS_CACHE[clean_ticker]

    data = await get_financial_overview(clean_ticker)
    peers = data.get("peers_data", {})
    val_data = data.get("valuation", {})
    # Đảm bảo doanh nghiệp mục tiêu luôn đồng bộ 100% P/E, P/B và Vốn hóa với tab Tổng Quan và Định Giá
    if isinstance(peers, dict) and "peers" in peers and len(peers["peers"]) > 0:
        for p in peers["peers"]:
            if isinstance(p, dict) and p.get("ticker", "").upper() == clean_ticker:
                if val_data.get("pe_live"):
                    p["pe"] = val_data["pe_live"]
                if val_data.get("pb_live"):
                    p["pb"] = val_data["pb_live"]
                if val_data.get("market_cap_bil"):
                    p["market_cap_bil"] = val_data["market_cap_bil"]
                break
    peers = await enrich_peers_with_realized_dividends(peers)

    _PEERS_CACHE[clean_ticker] = peers
    _PEERS_CACHE_TS[clean_ticker] = now_ts
    return peers


@app.get("/api/company-news-events/{ticker}")
async def get_news_and_events(ticker: str):
    """
    Truy xuất danh sách tin tức và sự kiện doanh nghiệp cập nhật.
    """
    clean_ticker = ticker.upper().strip()
    return get_company_news_and_events(clean_ticker)


@app.get("/api/mini-chart-series/{ticker}")
async def get_overview_mini_chart_series(ticker: str):
    """
    Truy xuất chuỗi dữ liệu nến/giá/khối lượng cho biểu đồ kỹ thuật mini (1D, 5D, 1M, 6M, YTD, 1Y, 5Y, ALL)
    kèm bảng thống kê thị trường chi tiết theo giá thời gian thực.
    """
    clean_ticker = ticker.upper().strip()
    live_price = None
    live_ref = None
    live_open = None
    live_high = None
    live_low = None
    live_vol = None
    live_change = None
    live_pct = None
    live_f_buy = None
    live_bid = None
    live_ask = None
    try:
        live_info = await fetch_reconciled_live_price(clean_ticker)
        if live_info and "latest_close" in live_info:
            live_price = float(live_info["latest_close"])
            _RECONCILED_LIVE_PRICE_CACHE[clean_ticker] = live_info
            _RECONCILED_LIVE_PRICE_CACHE_TS[clean_ticker] = time.time()
            if live_info.get("sources_comparison") and len(live_info["sources_comparison"]) > 0:
                s0 = live_info["sources_comparison"][0]
                live_ref = s0.get("ref_price")
                live_open = s0.get("open")
                live_high = s0.get("high")
                live_low = s0.get("low")
                live_vol = s0.get("volume")
                live_change = s0.get("change")
                live_pct = s0.get("change_percent")
                live_f_buy = s0.get("foreign_buy")
                live_bid = s0.get("bid_vol")
                live_ask = s0.get("ask_vol")
    except Exception as e:
        print(f"Fetch live price for mini-chart-series failed ({clean_ticker}): {e}")

    capital_info = None
    if clean_ticker in _FIN_OVERVIEW_CACHE:
        prof = _FIN_OVERVIEW_CACHE[clean_ticker].get("company_profile", {})
        if prof.get("shares_outstanding_mil"):
            capital_info = {
                "shares_outstanding_mil": prof["shares_outstanding_mil"],
                "is_corporate_action_adjusted": True
            }
    if not capital_info:
        try:
            capital_info = await asyncio.wait_for(fetch_stock_corporate_capital(clean_ticker), timeout=1.5)
        except Exception:
            pass

    # Truy xuất số liệu thống kê 52 tuần thực tế từ chuỗi nến lịch sử
    h52 = None
    l52 = None
    vol52 = None
    try:
        from ssi_fastconnect import fetch_hybrid_ohlcv_data
        candles_52w = await asyncio.wait_for(fetch_hybrid_ohlcv_data(clean_ticker, resolution="D", count=250), timeout=1.5)
        if candles_52w and len(candles_52w) >= 20:
            c_highs = [float(c["high"]) for c in candles_52w if float(c.get("high", 0)) > 0]
            c_lows = [float(c["low"]) for c in candles_52w if float(c.get("low", 0)) > 0]
            c_vols = [float(c["volume"]) for c in candles_52w if float(c.get("volume", 0)) > 0]
            if c_highs: h52 = max(c_highs)
            if c_lows: l52 = min(c_lows)
            if c_vols: vol52 = int(sum(c_vols) / len(c_vols))
    except Exception:
        pass

    return get_mini_chart_series(
        clean_ticker,
        live_price=live_price,
        live_ref=live_ref,
        live_open=live_open,
        live_high=live_high,
        live_low=live_low,
        live_vol=live_vol,
        live_change=live_change,
        live_pct=live_pct,
        live_foreign_buy=live_f_buy,
        live_bid_vol=live_bid,
        live_ask_vol=live_ask,
        corporate_capital=capital_info,
        high_52w=h52,
        low_52w=l52,
        avg_vol_52w=vol52
    )


@app.get("/api/company-catalysts-insights/{ticker}")
async def get_catalysts_and_insights(ticker: str):
    """
    Truy xuất thông tin catalysts động lực tăng trưởng, dự án trọng yếu (quy mô, vốn, tiến độ/lấp đầy)
    và phân tích AI chuyên sâu.
    Mặc định tự động Quét BCTN, BCTC và Website doanh nghiệp để luôn trả về danh mục dự án đầy đủ, đúng và mới nhất.
    """
    clean_ticker = ticker.upper().strip()
    data = get_company_catalysts_and_projects(clean_ticker)

    # Mặc định tự động Quét BCTN & Website chính thức từ Project Discovery Engine
    try:
        from project_discovery_engine import discover_company_projects_master, SSC_COMPANY_PROFILES_SEARCH_URL, SSC_DISCLOSURE_PORTAL_NAME
        data["ssc_portal_url"] = SSC_COMPANY_PROFILES_SEARCH_URL
        data["ssc_portal_name"] = SSC_DISCLOSURE_PORTAL_NAME

        # Tự động quét và lấy danh mục dự án mới nhất (sử dụng cache thông minh nếu vừa quét, hoặc quét tự động)
        disc_entry = await discover_company_projects_master(clean_ticker, force_refresh=False)
        if disc_entry:
            data["official_website"] = disc_entry.get("official_website")
            data["scan_sources"] = disc_entry.get("scan_sources")
            data["scan_time_str"] = disc_entry.get("scan_time_str")
            if disc_entry.get("projects"):
                data["projects"] = disc_entry["projects"]
                data["total_projects"] = len(disc_entry["projects"])
                data["total_investment_bil"] = disc_entry.get("total_investment_bil", 0)
                data["auto_discovered"] = True
            else:
                data["projects"] = []
                data["total_projects"] = 0
                data["total_investment_bil"] = 0
                data["auto_discovered"] = False
    except Exception as e:
        print(f"[get_catalysts_and_insights] Auto discovery error for {clean_ticker}: {e}")

    # Tích hợp Adaptive Corporate Growth Engine để tùy biến tiêu đề và Thẻ Kế hoạch/Động lực theo ngành
    try:
        from adaptive_growth_engine import build_adaptive_growth_portfolio, classify_business_model
        from sector_peers_matrix import get_universal_sector_peer_config

        company_name = data.get("company_name", f"CTCP {clean_ticker}")
        sector = data.get("sector", "")
        official_web = data.get("official_website", "")
        
        m_info = classify_business_model(clean_ticker, company_name, sector)
        m_key = m_info.get("model_key", "HOLDING_CONGLOMERATE")
        m_cfg = get_universal_sector_peer_config(m_key, clean_ticker)
        std_sector = m_cfg.get("sector_name") or m_info.get("badge_text") or sector
        data["sector"] = std_sector
        data["growth_model_key"] = m_key
        data["model_badge_text"] = m_info.get("badge_text", std_sector)
        data["recommended_valuation"] = m_cfg.get("recommended_valuation")

        adaptive_info = build_adaptive_growth_portfolio(
            clean_ticker,
            sector=std_sector,
            company_name=company_name,
            existing_projects=data.get("projects", []),
            official_website=official_web
        )
        data.update(adaptive_info)

        # Kích hoạt quét AI chạy nền nếu mã này chưa có trong Gemini Growth Cache
        from gemini_growth_extractor import load_gemini_growth_cache, extract_growth_profile_with_gemini
        g_cache = load_gemini_growth_cache()
        if clean_ticker not in g_cache:
            asyncio.create_task(extract_growth_profile_with_gemini(clean_ticker))
    except Exception as e:
        print(f"[get_catalysts_and_insights] Adaptive growth engine error for {clean_ticker}: {e}")

    return data


@app.post("/api/discover-company-projects/{ticker}")
@app.get("/api/discover-company-projects/{ticker}")
async def discover_company_projects_route(ticker: str, force_refresh: bool = False):
    """
    Kích hoạt quét và bóc tách thông tin dự án mở rộng trực tiếp từ
    Website chính thức của doanh nghiệp và Báo cáo Thường niên (BCTN), Báo cáo Bán niên (BCTCSN).
    Tích hợp Adaptive Growth Engine phân loại theo mô hình kinh doanh.
    """
    clean_ticker = ticker.upper().strip()
    from project_discovery_engine import discover_company_projects_master
    res = await discover_company_projects_master(clean_ticker, force_refresh=force_refresh)
    try:
        from adaptive_growth_engine import build_adaptive_growth_portfolio
        from gemini_growth_extractor import extract_growth_profile_with_gemini, load_gemini_growth_cache
        
        # Tự động gọi Gemini Flash nếu chưa có trong Cache hoặc khi người dùng bấm Quét lại
        g_cache = load_gemini_growth_cache()
        if force_refresh or (clean_ticker not in g_cache):
            try:
                await extract_growth_profile_with_gemini(clean_ticker, force_refresh=force_refresh)
            except Exception as ge:
                print(f"[discover_company_projects_route] Gemini growth extractor: {ge}")

        company_name = res.get("company_name", f"CTCP {clean_ticker}")
        official_web = res.get("official_website", "")
        adaptive_info = build_adaptive_growth_portfolio(
            clean_ticker,
            company_name=company_name,
            existing_projects=res.get("projects", []),
            official_website=official_web
        )
        res.update(adaptive_info)
    except Exception as e:
        print(f"[discover_company_projects_route] Adaptive error for {clean_ticker}: {e}")
    return res


@app.get("/api/ssc-company-profile/{ticker}")
@app.get("/api/external-document-sources/{ticker}")
async def get_ssc_company_profile_endpoint(ticker: str):
    """
    Endpoint tra cứu liên kết hồ sơ doanh nghiệp niêm yết, website chính thức và
    kho tải tài liệu Vietstock & Cổng công bố thông tin UBCKNN (congbothongtin.ssc.gov.vn).
    """
    clean_ticker = ticker.upper().strip()
    from project_discovery_engine import get_company_external_document_sources
    return get_company_external_document_sources(clean_ticker)



@app.post("/api/valuation/dcf")
async def post_dcf_valuation(req: DcfCustomRequest):
    """
    Tính toán lại mô hình định giá DCF tương tác theo các tham số WACC, g, tốc độ tăng trưởng FCF người dùng tùy chỉnh.
    """
    clean_ticker = req.ticker.upper().strip()
    market_p = req.current_market_price
    if not market_p:
        try:
            live_price_info = await fetch_reconciled_live_price(clean_ticker)
            if live_price_info and live_price_info.get("latest_close"):
                market_p = float(live_price_info["latest_close"])
        except Exception:
            pass

    bundle = get_financial_data_bundle(clean_ticker, current_market_price=market_p)
    stm = bundle["statements_annual"]
    prof = bundle["company_profile"]
    
    base_fcf = stm["cfo"][-1] * 0.65
    net_debt = (stm["short_term_debt"][-1] + stm["long_term_debt"][-1]) - stm["cash_and_equivalents"][-1]
    
    dcf_res = calculate_dcf_model(
        base_fcf=base_fcf,
        fcf_growth_rate=req.fcf_growth_rate,
        wacc=req.wacc,
        terminal_g=req.terminal_g,
        shares_outstanding=prof["shares_outstanding_mil"],
        net_debt=max(0, net_debt),
        projection_years=req.projection_years
    )
    
    if not market_p:
        market_p = prof["market_cap_bil"] * 1000 / prof["shares_outstanding_mil"]
    mos = ((dcf_res["fair_value_per_share"] - market_p) / market_p) * 100.0 if market_p > 0 else 0.0

    return {
        "ticker": clean_ticker,
        "current_market_price": market_p,
        "dcf_fair_value": dcf_res["fair_value_per_share"],
        "margin_of_safety_percent": round(mos, 2),
        "dcf_details": dcf_res
    }


@app.post("/api/valuation/multi-model")
async def post_multi_model_valuation(req: MultiModelValuationRequest):
    """
    Tính toán lại 6 mô hình định giá lượng hóa tổng hợp (DCF, Graham 1-2-3, P/E, P/B)
    với các tham số và trọng số tùy chỉnh thời gian thực.
    """
    clean_ticker = req.ticker.upper().strip()
    live_p = req.current_market_price
    if not live_p:
        try:
            live_price_info = await fetch_reconciled_live_price(clean_ticker)
            if live_price_info and live_price_info.get("latest_close"):
                live_p = float(live_price_info["latest_close"])
        except Exception:
            pass

    bundle = get_financial_data_bundle(clean_ticker, current_market_price=live_p)
    stm = bundle["statements_annual"]
    prof = bundle["company_profile"]
    peers = bundle.get("peers_data", {})
    
    idx = -1
    base_fcf = stm["cfo"][idx] * 0.65 if "cfo" in stm and len(stm["cfo"]) > 0 else 1000.0
    net_debt = (stm["short_term_debt"][idx] + stm["long_term_debt"][idx]) - stm["cash_and_equivalents"][idx]
    
    shares = prof.get("shares_outstanding_mil") or 100.0
    val_res = bundle.get("valuation")
    if val_res and isinstance(val_res, dict) and val_res.get("eps"):
        eps = float(val_res["eps"])
        bvps = float(val_res["bvps"])
    elif val_res and hasattr(val_res, "eps"):
        eps = float(val_res.eps)
        bvps = float(val_res.bvps)
    else:
        eps = (stm["net_profit"][idx] * 1_000_000_000) / (shares * 1_000_000) if shares > 0 else 2500.0
        bvps = (stm["owner_equity"][idx] * 1_000_000_000) / (shares * 1_000_000) if shares > 0 else 18000.0
    
    ind_pe = req.industry_pe or (peers.get("industry_average", {}).get("pe") if isinstance(peers, dict) else getattr(peers, "industry_average", {}).get("pe", 13.0)) or 13.0
    ind_pb = req.industry_pb or (peers.get("industry_average", {}).get("pb") if isinstance(peers, dict) else getattr(peers, "industry_average", {}).get("pb", 1.6)) or 1.6
    
    ref_price = live_p or prof.get("current_market_price") or 25000.0

    res = calculate_multi_model_valuation(
        ticker=clean_ticker,
        current_market_price=ref_price,
        eps=eps,
        bvps=bvps,
        base_fcf=base_fcf,
        shares_outstanding_mil=shares,
        net_debt=max(0, net_debt),
        industry_pe=ind_pe,
        industry_pb=ind_pb,
        growth_rate=req.growth_rate or 12.0,
        wacc=req.wacc or 11.5,
        terminal_g=req.terminal_g or 2.5,
        risk_free_rate=req.risk_free_rate or 4.8,
        custom_weights=req.custom_weights or req.weights,
        sector=prof.get("sector", ""),
        company_name=prof.get("name", "")
    )

    if val_res:
        v_dict = val_res if isinstance(val_res, dict) else (val_res.model_dump() if hasattr(val_res, "model_dump") else {})
        res["is_adjusted_for_corporate_actions"] = v_dict.get("is_adjusted_for_corporate_actions", False)
        res["dilution_multiplier"] = v_dict.get("dilution_multiplier", 1.0)
        res["dilution_summary_note"] = v_dict.get("dilution_summary_note", "")
        res["dilution_events"] = v_dict.get("dilution_events", [])
        res["unadjusted_blended_fair_value"] = v_dict.get("unadjusted_blended_fair_value", res.get("blended_fair_value", 0.0))
        res["unadjusted_eps"] = v_dict.get("unadjusted_eps", eps)
        res["unadjusted_bvps"] = v_dict.get("unadjusted_bvps", bvps)

    return res


@app.get("/api/valuation/sector-weights/{ticker}")
async def get_valuation_sector_weights(ticker: str):
    """
    Lấy ma trận trọng số và phân loại nhóm ngành chuẩn hóa cho từng mã cổ phiếu.
    """
    clean_ticker = ticker.upper().strip()
    from financial_data import get_sector_valuation_profile, get_financial_data_bundle
    try:
        bundle = get_financial_data_bundle(clean_ticker)
        prof = bundle.get("company_profile", {})
        sector = prof.get("sector", "")
        company_name = prof.get("name", "")
    except Exception:
        sector = ""
        company_name = ""
    return get_sector_valuation_profile(clean_ticker, sector=sector, company_name=company_name)


@app.get("/api/valuation/bands/{ticker}")
async def get_valuation_bands(ticker: str, timeframe: Optional[str] = "5Y"):
    """
    Trả về bộ dữ liệu dải định giá lịch sử P/E Band và P/B Band theo các khung thời gian (3M, 6M, 1Y, 5Y, ALL).
    """
    clean_ticker = ticker.upper().strip()
    bundle = get_financial_data_bundle(clean_ticker)
    prof = bundle.get("company_profile", {})
    peers = bundle.get("peers_data", {})
    
    ind_pe = (peers.get("industry_average", {}).get("pe") if isinstance(peers, dict) else getattr(peers, "industry_average", {}).get("pe", 13.0)) or 13.0
    ind_pb = (peers.get("industry_average", {}).get("pb") if isinstance(peers, dict) else getattr(peers, "industry_average", {}).get("pb", 1.6)) or 1.6
    
    from financial_data import generate_valuation_bands_dataset
    bands_data = generate_valuation_bands_dataset(clean_ticker, ind_pe, ind_pb)
    
    tf = timeframe.upper().strip() if timeframe else "5Y"
    if tf not in bands_data:
        tf = "5Y"
        
    return {
        "ticker": clean_ticker,
        "timeframe": tf,
        "timeframes_available": ["3M", "6M", "1Y", "5Y", "ALL"],
        "selected_data": bands_data.get(tf),
        "all_timeframes": bands_data
    }


@app.get("/api/database/companies")
async def get_database_companies(
    q: Optional[str] = None,
    exchange: Optional[str] = None,
    sector: Optional[str] = None,
    limit: int = 100
):
    """
    Truy vấn danh sách doanh nghiệp từ cơ sở dữ liệu 650+ mã cổ phiếu Google Sheets / FiinTrade.
    Hỗ trợ tìm kiếm theo từ khóa mã, tên, sàn giao dịch (HOSE, HNX, UPCOM) và phân ngành.
    """
    results = search_companies(keyword=q or "", exchange=exchange, sector=sector, limit=limit)
    return {
        "total_matches": len(results),
        "total_database_records": len(COMPANY_DATABASE),
        "companies": results
    }


@app.get("/api/database/companies/{ticker}")
async def get_database_company_detail(ticker: str):
    """
    Tra cứu thông tin chi tiết một doanh nghiệp từ cơ sở dữ liệu (P/E, P/B, ROE, Vốn hóa, KQKD Q1-2026).
    """
    company = get_company(ticker)
    if not company:
        raise HTTPException(status_code=404, detail=f"Không tìm thấy mã {ticker} trong cơ sở dữ liệu doanh nghiệp")
    return company


@app.get("/api/database/sectors")
async def get_database_sectors():
    """
    Truy xuất danh sách thống kê tăng trưởng lợi nhuận và định giá toàn bộ các phân ngành kinh tế.
    """
    return {
        "total_sectors": len(SECTOR_DATABASE),
        "sectors": get_all_sectors_summary()
    }


@app.post("/api/database/sync")
async def post_sync_database():
    """
    Kích hoạt đồng bộ hóa dữ liệu trực tiếp từ liên kết Google Sheets của người dùng.
    """
    res = await sync_from_google_sheets(force=True)
    return res


class SsiConfigRequest(BaseModel):
    consumer_id: str
    consumer_secret: str


@app.get("/api/ssi/apis")
async def get_ssi_apis_catalog():
    """
    Trả về danh mục 9 mã API chính thức từ cổng SSI FastConnect Data kèm thông tin kết nối.
    """
    return {
        "status": "success",
        "total_apis": len(SSI_API_CATALOG),
        "documentation_url": "https://guide.ssi.com.vn/ssi-products/tieng-viet/fastconnect-data/danh-sach-cac-api",
        "apis": SSI_API_CATALOG,
        "is_configured": bool(SSI_CONFIG.get("consumer_id") and SSI_CONFIG.get("consumer_secret")),
        "active_mode": "SSI FastConnect Live" if SSI_CONFIG.get("access_token") else "Vietstock & Market Reconciled (Dual-Engine)"
    }


@app.post("/api/ssi/config")
async def set_ssi_config(req: SsiConfigRequest):
    """
    Lưu và xác thực thông tin ConsumerID & ConsumerSecret khách hàng để kích hoạt SSI FastConnect Data.
    """
    SSI_CONFIG["consumer_id"] = req.consumer_id.strip()
    SSI_CONFIG["consumer_secret"] = req.consumer_secret.strip()
    client = SSIFastConnectClient()
    token = await client.authenticate()
    return {
        "status": "success" if token else "saved_offline",
        "has_token": bool(token),
        "message": "Đã kết nối thành công tới cổng SSI FastConnect Data API v2!" if token else "Đã lưu cấu hình. Hệ thống sẽ tiếp tục sử dụng cơ chế dự phòng Vietstock Chart nếu cần."
    }


@app.get("/api/ssi/ohlc/{ticker}")
async def get_ssi_ohlcv(ticker: str, count: int = 60):
    """
    Truy xuất nến OHLCV kết hợp (SSI FastConnect DailyOhlc & Vietstock Technical Analysis Chart).
    """
    clean_ticker = ticker.upper().strip()
    candles = await fetch_hybrid_ohlcv_data(clean_ticker, count=count)
    return {
        "ticker": clean_ticker,
        "count": len(candles),
        "candles": candles,
        "source": "SSI FastConnect DailyOhlc / Vietstock Chart Reconciled"
    }


@app.get("/api/ssi/stock-depth/{ticker}")
async def get_ssi_stock_depth(ticker: str):
    """
    Truy xuất dữ liệu thị trường chi tiết theo chuẩn SSI DailyStockPrice API:
    Giá trần, giá sàn, giá tham chiếu, và dòng tiền khối ngoại (Foreign Net Flow).
    """
    clean_ticker = ticker.upper().strip()
    c = get_company(clean_ticker)
    live_p = float(c.get("market_price", 21700)) if c else 21700.0
    try:
        p_info = await fetch_reconciled_live_price(clean_ticker)
        if p_info:
            live_p = p_info.get("latest_close", live_p)
    except Exception:
        pass
    depth = get_stock_depth_metrics(clean_ticker, live_p)
    foreign = depth.get("foreign_trading", {})
    return {
        "status": "success",
        "ticker": clean_ticker,
        "foreign_net_value_bil": foreign.get("net_value_bil", 0.0),
        "foreign_net_volume": foreign.get("net_volume", 0),
        **depth
    }


@app.get("/api/ssi/market-overview")
async def get_ssi_market_overview():
    """
    Truy xuất độ rộng thị trường (Market Breadth) theo chuẩn SSI DailyIndex API:
    Chỉ số VN-INDEX, VN30, số mã tăng, giảm, đứng giá, trần, sàn và giá trị giao dịch.
    """
    return {
        "status": "success",
        **get_market_overview()
    }


@app.get("/api/technical/{ticker}")
async def get_technical_signals(ticker: str, resolution: str = "D", count: int = 1500):
    """
    Truy xuất dữ liệu nến kỹ thuật thực tế và tính toán đầy đủ các chỉ báo kỹ thuật:
    MA20, MA50, MA200, EMA20, RSI(14), MACD(12,26,9), Bollinger Bands, Pivot Points (S1-S3, R1-R3).
    Dữ liệu nến được đồng bộ hóa từ SSI FastConnect và Vietstock/VNDirect/DNSE Multi-timeframe Feed.
    Hỗ trợ nạp đầy đủ lịch sử từ 5 - 8 năm phục vụ phân tích đa khung thời gian (1D, 1W, 1M, 1Y, 5Y, ALL).
    """
    clean_ticker = ticker.upper().strip()
    norm_res = str(resolution).upper().strip()
    if norm_res in ["D", "W", "M"] and count < 1000:
        count = 1500
    cache_key = f"{clean_ticker}_{norm_res}_{count}"
    now_ts = time.time()
    # Trong phiên giao dịch (Thứ 2 - Thứ 6 từ 09:00 - 15:00), cache TTL ngắn (15s) để nến realtime cập nhật liên tục
    from datetime import timezone, timedelta
    vn_now = datetime.now(timezone(timedelta(hours=7)))
    is_trading_hours = (vn_now.weekday() < 5 and 9 <= vn_now.hour < 15)
    cache_ttl = (15.0 if is_trading_hours else 120.0) if norm_res in ["D", "W", "M"] else 15.0
    if cache_key in _TECH_SIGNALS_CACHE and (now_ts - _TECH_SIGNALS_CACHE_TS.get(cache_key, 0)) < cache_ttl:
        cached_item = _TECH_SIGNALS_CACHE[cache_key]
        if cached_item and cached_item.get("candles_history") and len(cached_item["candles_history"]) > 0:
            return cached_item

    c = get_company(clean_ticker)
    exchange = (c.get("exchange") if c else "HOSE").upper()
    live_p = float(c.get("market_price", 21700)) if c else 21700.0
    # Tải song song lấy chuỗi nến thực tế (DNSE / VNDirect ~200-400ms) và đối soát thị giá
    async def _resolve_live_price():
        try:
            p_info = await asyncio.wait_for(fetch_reconciled_live_price(clean_ticker), timeout=1.8)
            if p_info:
                return float(p_info.get("latest_close", live_p))
        except Exception:
            pass
        return live_p

    live_p_task = asyncio.create_task(_resolve_live_price())
    candles_task = asyncio.create_task(asyncio.wait_for(fetch_hybrid_ohlcv_data(clean_ticker, resolution=resolution, count=count), timeout=6.0))

    try:
        candles = await candles_task
    except Exception:
        candles = []

    try:
        live_p = await live_p_task
    except Exception:
        pass

    if candles and candles[-1].get("close", 0) > 0 and (live_p <= 0 or live_p == 21700.0):
        live_p = float(candles[-1]["close"])

    was_real_data = bool(candles and len(candles) >= 5)

    # Nếu cổng mạng ngoài bị chậm tạm thời, tận dụng ngay nến thực tế đã lưu trước đó trong cache
    if not candles and cache_key in _TECH_SIGNALS_CACHE:
        prev_cached = _TECH_SIGNALS_CACHE[cache_key]
        if prev_cached and prev_cached.get("candles_history"):
            candles = prev_cached["candles_history"]
            was_real_data = True
    
    # Tính toán toàn bộ chỉ báo kỹ thuật
    tech = calculate_technical_indicators(candles, live_p)
    depth = get_stock_depth_metrics(clean_ticker, live_p)
    foreign = depth.get("foreign_trading", {})

    shares_out = (c.get("shares_outstanding", 6400000000) if c else 6400000000) or 6400000000
    foreign_pct = (c.get("foreign_ownership_pct", 18.5) if c else 18.5) or 18.5

    res_dict = {
        "ticker": clean_ticker,
        "exchange": exchange,
        "last_price": tech["last_price"],
        "rsi_14": tech["rsi_14"],
        "rsi_status": tech["rsi_status"],
        "rsi_zone": tech.get("rsi_zone", "neutral"),
        "macd_status": tech["macd"]["status"],
        "macd_line": tech["macd"]["macd"],
        "macd_signal": tech["macd"]["signal"],
        "macd_hist": tech["macd"]["histogram"],
        "sma_20": tech["moving_averages"]["ma20"],
        "sma_50": tech["moving_averages"]["ma50"],
        "sma_200": tech["moving_averages"]["ma200"],
        "ema_20": tech["moving_averages"]["ema20"],
        "bb_upper": tech["bollinger_bands"]["upper"],
        "bb_middle": tech["bollinger_bands"]["middle"],
        "bb_lower": tech["bollinger_bands"]["lower"],
        "pivot_point": tech["pivot_points"]["pivot"],
        "support_1": tech["pivot_points"]["s1"],
        "support_2": tech["pivot_points"]["s2"],
        "support_3": tech["pivot_points"]["s3"],
        "resistance_1": tech["pivot_points"]["r1"],
        "resistance_2": tech["pivot_points"]["r2"],
        "resistance_3": tech["pivot_points"]["r3"],
        "overall_signal": tech["overall_signal"],
        "signal_color": tech["signal_color"],
        "recommendation_score": 8 if "MUA" in tech["overall_signal"] else (5 if "TRUNG" in tech["overall_signal"] else 3),
        "trend_summary": tech["trend_summary"],
        "candles_history": candles if candles else tech.get("candles_history", []),
        "ceiling_price": depth["ceiling_price"],
        "floor_price": depth["floor_price"],
        "reference_price": depth["ref_price"],
        "foreign_buy_volume": foreign.get("buy_volume", 0),
        "foreign_sell_volume": foreign.get("sell_volume", 0),
        "foreign_net_volume": foreign.get("net_volume", 0),
        "foreign_net_value_bil": foreign.get("net_value_bil", 0.0),
        "foreign_current_room": int((foreign_pct / 100.0) * shares_out),
        "foreign_total_room": int(0.49 * shares_out),
        "stock_depth": depth,
        "ma20": tech["moving_averages"]["ma20"],
        "ma50": tech["moving_averages"]["ma50"],
        "ma200": tech["moving_averages"]["ma200"],
        "trend": tech["trend_summary"],
        "resolution": resolution,
        "data_engine": "SSI FastConnect & Vietstock Multi-timeframe Feed"
    }
    if was_real_data and candles and len(candles) > 0:
        _TECH_SIGNALS_CACHE[cache_key] = res_dict
        _TECH_SIGNALS_CACHE_TS[cache_key] = now_ts
    return res_dict


# -------------------------------------------------------------
# BỘ LỌC QUÉT TÍN HIỆU FANSI T+ (AMIBROKER AFL) TOÀN THỊ TRƯỜNG
# Thuần Phân Tích Kỹ Thuật (MACD 12,26,9 + MA20 + Nến Tăng/Giảm)
# Khối lượng khớp trung bình 10 phiên MA(Volume, 10) >= min_vol
# -------------------------------------------------------------
_FANSI_SCREENER_CACHE: Dict[str, Any] = {}
_FANSI_SCREENER_CACHE_TS: Dict[str, float] = {}

# HIGH-PERFORMANCE UNIFIED SCREENER ENGINE:
# Bộ nhớ đệm nến thị trường (RAM + Disk) & CSDL tín hiệu toàn bộ 5 thuật toán kỹ thuật
_MARKET_CANDLES_CACHE: Dict[str, Dict[str, Any]] = {}
_MARKET_CANDLES_CACHE_TS: Dict[str, float] = {}
_ALL_TECH_SIGNALS_CACHE: Dict[str, List[Dict[str, Any]]] = {}
_ALL_TECH_SIGNALS_CACHE_TS: float = 0.0
_TECH_SCAN_LOCK = asyncio.Lock()
_CANDLES_DISK_FILE = os.path.join(ROOT_DIR, "cache", "market_candles_daily.json")

def _load_candles_disk_cache():
    global _MARKET_CANDLES_CACHE, _MARKET_CANDLES_CACHE_TS
    if os.path.exists(_CANDLES_DISK_FILE):
        try:
            with open(_CANDLES_DISK_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            now = time.time()
            if isinstance(d, dict) and len(d) > 0:
                _MARKET_CANDLES_CACHE = d
                for sym in d.keys():
                    _MARKET_CANDLES_CACHE_TS[sym] = now
                print(f"[CANDLE-CACHE] Đã nạp thành công {len(d)} mã nến lịch sử từ đĩa cache.")
        except Exception as e:
            print(f"[CANDLE-CACHE] Lỗi nạp cache nến: {e}")

_load_candles_disk_cache()

def _save_candles_disk_cache():
    try:
        os.makedirs(os.path.dirname(_CANDLES_DISK_FILE), exist_ok=True)
        with open(_CANDLES_DISK_FILE, "w", encoding="utf-8") as f:
            json.dump(_MARKET_CANDLES_CACHE, f, separators=(',', ':'))
    except Exception as e:
        pass

VN30_TICKERS = {
    "ACB", "BCM", "BID", "BVH", "CTG", "FPT", "GAS", "GVR", "HDB", "HPG",
    "MBB", "MSN", "MWG", "PLX", "POW", "SHB", "SSB", "SSI", "STB", "TCB",
    "TPB", "VCB", "VHM", "VIB", "VIC", "VJC", "VNM", "VPB", "VRE"
}

def _calculate_fansi_core(closes: List[float], opens: List[float], vols: List[float], times: List[int], min_vol: int, min_price: float = 5000.0):
    n = len(closes)
    if n < 25:
        return None
    
    # 1. MA 10 Volume
    ma10_vol = sum(vols[-10:]) / 10.0 if len(vols) >= 10 else sum(vols) / len(vols)
    if ma10_vol < min_vol:
        return None
        
    # 2. MACD (12, 26, 9)
    k12 = 2.0 / 13.0
    k26 = 2.0 / 27.0
    ema12 = [closes[0]] * n
    ema26 = [closes[0]] * n
    for i in range(1, n):
        ema12[i] = closes[i] * k12 + ema12[i - 1] * (1.0 - k12)
        ema26[i] = closes[i] * k26 + ema26[i - 1] * (1.0 - k26)
    macd = [ema12[i] - ema26[i] for i in range(n)]

    ksig = 2.0 / 10.0
    sig = [macd[0]] * n
    for i in range(1, n):
        sig[i] = macd[i] * ksig + sig[i - 1] * (1.0 - ksig)

    # 3. SMA 20
    sma20 = [0.0] * n
    for i in range(n):
        if i >= 19:
            sma20[i] = sum(closes[i - 19:i + 1]) / 20.0
        else:
            sma20[i] = sum(closes[:i + 1]) / (i + 1)

    # 4. Conditions: dk4 (Buy) and dk5 (Sell)
    buy1 = [False] * n
    sell1 = [False] * n
    for i in range(20, n):
        dk1 = macd[i] > sig[i]
        dk12 = closes[i] > sma20[i]
        dk13 = closes[i] > opens[i]
        buy1[i] = (dk1 and dk12 and dk13)

        dk2 = macd[i] < sig[i]
        dk22 = closes[i] < sma20[i]
        dk23 = closes[i] < opens[i]
        sell1[i] = (dk2 and dk22 and dk23)

    # 5. ExRem(Buy1, Sell1)
    fs_buy = [False] * n
    fs_sell = [False] * n
    st = 0
    last_sig = None
    last_sig_bar = -1
    last_sig_price = 0.0

    for i in range(n):
        if buy1[i] and st != 1:
            fs_buy[i] = True
            st = 1
            last_sig = "BUY"
            last_sig_bar = i
            last_sig_price = closes[i]
        elif sell1[i] and st != -1:
            fs_sell[i] = True
            st = -1
            last_sig = "SELL"
            last_sig_bar = i
            last_sig_price = closes[i]

    if not last_sig or last_sig_bar < 0:
        return None

    bars_since = (n - 1) - last_sig_bar
    cur_p = closes[-1]
    prev_p = closes[-2] if n > 1 else cur_p
    pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0

    # Lợi nhuận tạm tính % từ điểm mua/bán (theo công thức AmiBroker AFL gốc)
    if last_sig == "BUY" and last_sig_price > 0:
        profit_pct = ((cur_p - last_sig_price) / last_sig_price) * 100.0
    elif last_sig == "SELL" and last_sig_price > 0:
        profit_pct = ((last_sig_price - cur_p) / last_sig_price) * 100.0
    else:
        profit_pct = 0.0

    # Chuyển đổi giá về VNĐ nếu là đơn vị nghìn đồng
    price_vnd = cur_p * 1000.0 if cur_p < 1000.0 else cur_p
    sig_price_vnd = last_sig_price * 1000.0 if last_sig_price < 1000.0 else last_sig_price

    # Lọc bỏ cổ phiếu siêu nhỏ có thị giá dưới min_price (mặc định < 5.000 đ)
    if min_price > 0 and price_vnd < min_price:
        return None

    sig_date = datetime.fromtimestamp(times[last_sig_bar]).strftime("%d/%m/%Y") if times and last_sig_bar < len(times) else ""
    status_text = "Hôm nay (T+0)" if bars_since == 0 else (f"{bars_since} phiên (T+{bars_since})")

    return {
        "signal": last_sig,
        "price": round(price_vnd, 0),
        "pct_change": round(pct_chg, 2),
        "signal_price": round(sig_price_vnd, 0),
        "profit_pct": round(profit_pct, 2),
        "bars_since": bars_since,
        "status_text": status_text,
        "ma10_vol": int(ma10_vol),
        "today_vol": int(vols[-1]),
        "signal_date": sig_date,
        "is_today": (bars_since == 0)
    }


def _calculate_robot1_core(closes: List[float], vols: List[float], times: List[int], min_vol: int, min_price: float = 5000.0):
    """
    Thuật toán ROBOT 1 (THE BEAST) - Zero-Lag DEMA Crossover (AmiBroker AFL):
    M1 = EMA(((2*EMA(C,29/2))-EMA(C,29)), 2);
    M2 = EMA(((2*EMA(C,29/2))-EMA(C,29)), 5);
    Buy = Cross(M1, M2); Sell = Cross(M2, M1);
    Buy = ExRem(Buy, Sell); Sell = ExRem(Sell, Buy);
    Filter = Buy AND C > Ref(C,-1) AND C >= 5 AND MA(V,10) >= 50000;
    """
    n = len(closes)
    if n < 35:
        return None
    
    # 1. MA 10 Volume
    ma10_vol = sum(vols[-10:]) / 10.0 if len(vols) >= 10 else sum(vols) / len(vols)
    if ma10_vol < min_vol:
        return None
        
    cur_p = closes[-1]
    price_vnd = cur_p * 1000.0 if cur_p < 1000.0 else cur_p
    if min_price > 0 and price_vnd < min_price:
        return None

    k_half = 2.0 / (14.5 + 1.0)
    k_full = 2.0 / (29.0 + 1.0)

    ema_half = [closes[0]] * n
    ema_full = [closes[0]] * n
    for i in range(1, n):
        ema_half[i] = closes[i] * k_half + ema_half[i - 1] * (1.0 - k_half)
        ema_full[i] = closes[i] * k_full + ema_full[i - 1] * (1.0 - k_full)

    inner = [2.0 * ema_half[i] - ema_full[i] for i in range(n)]

    k2 = 2.0 / (2.0 + 1.0)
    k5 = 2.0 / (5.0 + 1.0)

    m1 = [inner[0]] * n
    m2 = [inner[0]] * n
    for i in range(1, n):
        m1[i] = inner[i] * k2 + m1[i - 1] * (1.0 - k2)
        m2[i] = inner[i] * k5 + m2[i - 1] * (1.0 - k5)

    raw_buy = [False] * n
    raw_sell = [False] * n
    for i in range(1, n):
        if m1[i] > m2[i] and m1[i - 1] <= m2[i - 1] and closes[i] > closes[i - 1]:
            raw_buy[i] = True
        elif m2[i] > m1[i] and m2[i - 1] <= m1[i - 1]:
            raw_sell[i] = True

    # ExRem(Buy, Sell)
    st = 0
    last_sig = None
    last_sig_bar = -1
    last_sig_price = 0.0

    for i in range(n):
        if raw_buy[i] and st != 1:
            st = 1
            last_sig = "BUY"
            last_sig_bar = i
            last_sig_price = closes[i]
        elif raw_sell[i] and st != -1:
            st = -1
            last_sig = "SELL"
            last_sig_bar = i
            last_sig_price = closes[i]

    if not last_sig or last_sig_bar < 0:
        return None

    bars_since = (n - 1) - last_sig_bar
    prev_p = closes[-2] if n > 1 else cur_p
    pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0

    if last_sig == "BUY" and last_sig_price > 0:
        profit_pct = ((cur_p - last_sig_price) / last_sig_price) * 100.0
    elif last_sig == "SELL" and last_sig_price > 0:
        profit_pct = ((last_sig_price - cur_p) / last_sig_price) * 100.0
    else:
        profit_pct = 0.0

    sig_price_vnd = last_sig_price * 1000.0 if last_sig_price < 1000.0 else last_sig_price
    sig_date = datetime.fromtimestamp(times[last_sig_bar]).strftime("%d/%m/%Y") if times and last_sig_bar < len(times) else ""
    status_text = "Hôm nay (T+0)" if bars_since == 0 else (f"{bars_since} phiên (T+{bars_since})")

    return {
        "signal": last_sig,
        "price": round(price_vnd, 0),
        "pct_change": round(pct_chg, 2),
        "signal_price": round(sig_price_vnd, 0),
        "profit_pct": round(profit_pct, 2),
        "bars_since": bars_since,
        "status_text": status_text,
        "ma10_vol": int(ma10_vol),
        "today_vol": int(vols[-1]),
        "signal_date": sig_date,
        "is_today": (bars_since == 0)
    }


def _calculate_robot2_core(closes: List[float], highs: List[float], lows: List[float], vols: List[float], times: List[int], min_vol: int, min_price: float = 5000.0):
    """
    Thuật toán ROBOT 2 (ROCKET JET) - Breakout 5 phiên đỉnh / đáy (AmiBroker AFL):
    Buyperiods = 5; Sellperiods = 5;
    Buy = C > Ref(HHV(High, Buyperiods), -1);
    Sell = C < Ref(LLV(Low, Sellperiods), -1);
    Buy = ExRem(Buy, Sell); Sell = ExRem(Sell, Buy);
    Filter = (Buy or Sell) AND C*MA(V,10) >= 20000000 AND C >= 5 AND C > Ref(C,-1);
    """
    n = len(closes)
    if n < 20:
        return None
    
    # 1. MA 10 Volume
    ma10_vol = sum(vols[-10:]) / 10.0 if len(vols) >= 10 else sum(vols) / len(vols)
    if ma10_vol < min_vol:
        return None
        
    cur_p = closes[-1]
    price_vnd = cur_p * 1000.0 if cur_p < 1000.0 else cur_p
    if min_price > 0 and price_vnd < min_price:
        return None

    h_arr = highs if (highs and len(highs) == n) else closes
    l_arr = lows if (lows and len(lows) == n) else closes

    p_buy = 5
    p_sell = 5

    raw_buy = [False] * n
    raw_sell = [False] * n

    for i in range(p_buy + 1, n):
        prev_hhv = max(h_arr[i - p_buy : i])
        prev_llv = min(l_arr[i - p_sell : i])

        if closes[i] > prev_hhv and closes[i] > closes[i - 1]:
            raw_buy[i] = True
        elif closes[i] < prev_llv:
            raw_sell[i] = True

    # ExRem(Buy, Sell)
    st = 0
    last_sig = None
    last_sig_bar = -1
    last_sig_price = 0.0

    for i in range(n):
        if raw_buy[i] and st != 1:
            st = 1
            last_sig = "BUY"
            last_sig_bar = i
            last_sig_price = closes[i]
        elif raw_sell[i] and st != -1:
            st = -1
            last_sig = "SELL"
            last_sig_bar = i
            last_sig_price = closes[i]

    if not last_sig or last_sig_bar < 0:
        return None

    bars_since = (n - 1) - last_sig_bar
    prev_p = closes[-2] if n > 1 else cur_p
    pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0

    if last_sig == "BUY" and last_sig_price > 0:
        profit_pct = ((cur_p - last_sig_price) / last_sig_price) * 100.0
    elif last_sig == "SELL" and last_sig_price > 0:
        profit_pct = ((last_sig_price - cur_p) / last_sig_price) * 100.0
    else:
        profit_pct = 0.0

    sig_price_vnd = last_sig_price * 1000.0 if last_sig_price < 1000.0 else last_sig_price
    sig_date = datetime.fromtimestamp(times[last_sig_bar]).strftime("%d/%m/%Y") if times and last_sig_bar < len(times) else ""
    status_text = "Hôm nay (T+0)" if bars_since == 0 else (f"{bars_since} phiên (T+{bars_since})")

    return {
        "signal": last_sig,
        "price": round(price_vnd, 0),
        "pct_change": round(pct_chg, 2),
        "signal_price": round(sig_price_vnd, 0),
        "profit_pct": round(profit_pct, 2),
        "bars_since": bars_since,
        "status_text": status_text,
        "ma10_vol": int(ma10_vol),
        "today_vol": int(vols[-1]),
        "signal_date": sig_date,
        "is_today": (bars_since == 0)
    }


def _calculate_rsi_series(closes: List[float], period: int = 14) -> List[float]:
    """Tính chuỗi RSI(period) chuẩn Wilder's Smoothing."""
    n = len(closes)
    rsi = [50.0] * n
    if n <= period:
        return rsi
    gains = [0.0] * n
    losses = [0.0] * n
    for i in range(1, n):
        diff = closes[i] - closes[i - 1]
        if diff > 0:
            gains[i] = diff
        else:
            losses[i] = -diff
    
    avg_gain = sum(gains[1:period + 1]) / float(period)
    avg_loss = sum(losses[1:period + 1]) / float(period)
    if avg_loss == 0:
        rsi[period] = 100.0
    else:
        rs = avg_gain / avg_loss
        rsi[period] = 100.0 - (100.0 / (1.0 + rs))
        
    for i in range(period + 1, n):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / float(period)
        avg_loss = (avg_loss * (period - 1) + losses[i]) / float(period)
        if avg_loss == 0:
            rsi[i] = 100.0
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100.0 - (100.0 / (1.0 + rs))
    return rsi


def _calculate_divergence_rsi_core(closes: List[float], lows: List[float], vols: List[float], times: List[int], min_vol: int, min_price: float = 5000.0, highs: Optional[List[float]] = None):
    """
    Thuật toán PHÂN KỲ RSI (AmiBroker AFL Mua & Bán):
    - MUA (Phân kỳ dương):
      DK1 = RSI(14) > Ref(RSI(14),-1) AND Ref(RSI(14),-1) > Ref(RSI(14),-2) AND Ref(RSI(14),-2) < Ref(RSI(14),-3) AND Ref(RSI(14),-3) < Ref(RSI(14),-4);
      DK2 = LLV(RSI(14),4) > LLV(RSI(14),50);
      DK3 = LLV(L,4) <= LLV(L,50);
    - BÁN (Phân kỳ âm cập nhật):
      RSI() < Ref(RSI(),-1) AND Ref(RSI(),-1)<Ref(RSI(),-2) AND Ref(RSI(),-2)>Ref(RSI(),-3) AND Ref(RSI(),-3)>Ref(RSI(),-4)
      AND HHV(RSI(),3)<HHV(RSI(),50) AND HHV(H,5) >= HHV(H,50) AND C<REF(C,-1);
    """
    n = len(closes)
    if n < 55:
        return None

    # 1. MA 10 Volume
    ma10_vol = sum(vols[-10:]) / 10.0 if len(vols) >= 10 else sum(vols) / len(vols)
    if ma10_vol < min_vol:
        return None

    cur_p = closes[-1]
    price_vnd = cur_p * 1000.0 if cur_p < 1000.0 else cur_p
    if min_price > 0 and price_vnd < min_price:
        return None

    l_arr = lows if (lows and len(lows) == n) else closes
    h_arr = highs if (highs and len(highs) == n) else closes
    rsi14 = _calculate_rsi_series(closes, 14)

    raw_buy = [False] * n
    raw_sell = [False] * n
    for i in range(50, n):
        # DK MUA: Đáy RSI tại bar i-2 và ngóc lên 2 phiên liên tiếp (Phân kỳ dương)
        dk1_buy = (rsi14[i] > rsi14[i - 1] and 
                   rsi14[i - 1] > rsi14[i - 2] and 
                   rsi14[i - 2] < rsi14[i - 3] and 
                   rsi14[i - 3] < rsi14[i - 4])
        # LLV(RSI, 4) > LLV(RSI, 50)
        llv_rsi_4 = min(rsi14[i - 3 : i + 1])
        llv_rsi_50 = min(rsi14[i - 49 : i + 1])
        dk2_buy = (llv_rsi_4 > llv_rsi_50)
        # LLV(L, 4) <= LLV(L, 50)
        llv_l_4 = min(l_arr[i - 3 : i + 1])
        llv_l_50 = min(l_arr[i - 49 : i + 1])
        dk3_buy = (llv_l_4 <= llv_l_50)

        if dk1_buy and dk2_buy and dk3_buy:
            raw_buy[i] = True

        # DK BÁN: Phân kỳ âm RSI (AmiBroker AFL chuẩn)
        # RSI() < Ref(RSI(),-1) AND Ref(RSI(),-1)<Ref(RSI(),-2) AND Ref(RSI(),-2)>Ref(RSI(),-3) AND Ref(RSI(),-3)>Ref(RSI(),-4)
        # AND HHV(RSI(),3)<HHV(RSI(),50) AND HHV(H,5) >= HHV(H,50) AND C<REF(C,-1)
        dk1_sell = (rsi14[i] < rsi14[i - 1] and 
                    rsi14[i - 1] < rsi14[i - 2] and 
                    rsi14[i - 2] > rsi14[i - 3] and 
                    rsi14[i - 3] > rsi14[i - 4])
        # HHV(RSI(),3) < HHV(RSI(),50)
        hhv_rsi_3 = max(rsi14[i - 2 : i + 1])
        hhv_rsi_50 = max(rsi14[i - 49 : i + 1])
        dk2_sell = (hhv_rsi_3 < hhv_rsi_50)
        # HHV(H,5) >= HHV(H,50)
        hhv_h_5 = max(h_arr[i - 4 : i + 1])
        hhv_h_50 = max(h_arr[i - 49 : i + 1])
        dk3_sell = (hhv_h_5 >= hhv_h_50)
        # C < Ref(C,-1)
        dk4_sell = (closes[i] < closes[i - 1])

        if dk1_sell and dk2_sell and dk3_sell and dk4_sell:
            raw_sell[i] = True

    # Đưa về dạng lọc thống kê độc lập (không khử bằng ExRem)
    res_signals = []

    # Kiểm tra tín hiệu MUA (Phân kỳ dương RSI)
    last_buy_bar = -1
    for i in range(n - 1, 49, -1):
        if raw_buy[i]:
            last_buy_bar = i
            break

    if last_buy_bar >= 0:
        bars_since_buy = (n - 1) - last_buy_bar
        if bars_since_buy <= 20:
            last_buy_price = closes[last_buy_bar]
            prev_p = closes[-2] if n > 1 else cur_p
            pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0
            profit_pct = ((cur_p - last_buy_price) / last_buy_price) * 100.0 if last_buy_price > 0 else 0.0
            sig_price_vnd = last_buy_price * 1000.0 if last_buy_price < 1000.0 else last_buy_price
            sig_date = datetime.fromtimestamp(times[last_buy_bar]).strftime("%d/%m/%Y") if times and last_buy_bar < len(times) else ""
            status_text = "Hôm nay (T+0)" if bars_since_buy == 0 else f"{bars_since_buy} phiên (T+{bars_since_buy})"

            res_signals.append({
                "signal": "BUY",
                "price": round(price_vnd, 0),
                "pct_change": round(pct_chg, 2),
                "signal_price": round(sig_price_vnd, 0),
                "profit_pct": round(profit_pct, 2),
                "bars_since": bars_since_buy,
                "status_text": status_text,
                "ma10_vol": int(ma10_vol),
                "today_vol": int(vols[-1]),
                "signal_date": sig_date,
                "is_today": (bars_since_buy == 0)
            })

    # Kiểm tra tín hiệu BÁN (Phân kỳ âm RSI)
    last_sell_bar = -1
    for i in range(n - 1, 49, -1):
        if raw_sell[i]:
            last_sell_bar = i
            break

    if last_sell_bar >= 0:
        bars_since_sell = (n - 1) - last_sell_bar
        if bars_since_sell <= 20:
            last_sell_price = closes[last_sell_bar]
            prev_p = closes[-2] if n > 1 else cur_p
            pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0
            profit_pct = ((last_sell_price - cur_p) / last_sell_price) * 100.0 if last_sell_price > 0 else 0.0
            sig_price_vnd = last_sell_price * 1000.0 if last_sell_price < 1000.0 else last_sell_price
            sig_date = datetime.fromtimestamp(times[last_sell_bar]).strftime("%d/%m/%Y") if times and last_sell_bar < len(times) else ""
            status_text = "Hôm nay (T+0)" if bars_since_sell == 0 else f"{bars_since_sell} phiên (T+{bars_since_sell})"

            res_signals.append({
                "signal": "SELL",
                "price": round(price_vnd, 0),
                "pct_change": round(pct_chg, 2),
                "signal_price": round(sig_price_vnd, 0),
                "profit_pct": round(profit_pct, 2),
                "bars_since": bars_since_sell,
                "status_text": status_text,
                "ma10_vol": int(ma10_vol),
                "today_vol": int(vols[-1]),
                "signal_date": sig_date,
                "is_today": (bars_since_sell == 0)
            })

    return res_signals if res_signals else None


def _calculate_divergence_macd_core(closes: List[float], lows: List[float], vols: List[float], times: List[int], min_vol: int, min_price: float = 5000.0, highs: Optional[List[float]] = None):
    """
    Thuật toán PHÂN KỲ MACD (AmiBroker AFL Mua & Bán):
    - MUA (Phân kỳ dương):
      Dk1 = MACD() > Ref(MACD(),-1) AND Ref(MACD(),-1) > Ref(MACD(),-2) AND Ref(MACD(),-2) < Ref(MACD(),-3) AND Ref(MACD(),-3) < Ref(MACD(),-4);
      Dk2 = LLV(MACD(),7) > LLV(MACD(),50);
      DK3 = LLV(L,7) <= LLV(L,50);
      Filter = DK1 AND DK2 AND DK3 AND C > 5 AND C*MA(V,10) >= 20000000 AND C >= Ref(C,-1);
    - BÁN (Phân kỳ âm cập nhật):
      MACD() < Ref(MACD(),-1) AND Ref(MACD(),-1)<Ref(MACD(),-2) AND Ref(MACD(),-2)>Ref(MACD(),-3) AND Ref(MACD(),-3)>Ref(MACD(),-4)
      AND HHV(MACD(),7)<HHV(MACD(),50) AND HHV(H,5) >= HHV(H,50) AND C<REF(C,-1);
    """
    n = len(closes)
    if n < 55:
        return None

    # 1. MA 10 Volume
    ma10_vol = sum(vols[-10:]) / 10.0 if len(vols) >= 10 else sum(vols) / len(vols)
    if ma10_vol < min_vol:
        return None

    cur_p = closes[-1]
    price_vnd = cur_p * 1000.0 if cur_p < 1000.0 else cur_p
    if min_price > 0 and price_vnd < min_price:
        return None

    l_arr = lows if (lows and len(lows) == n) else closes
    h_arr = highs if (highs and len(highs) == n) else closes

    # MACD line = EMA12 - EMA26
    k12 = 2.0 / 13.0
    k26 = 2.0 / 27.0
    ema12 = [closes[0]] * n
    ema26 = [closes[0]] * n
    for i in range(1, n):
        ema12[i] = closes[i] * k12 + ema12[i - 1] * (1.0 - k12)
        ema26[i] = closes[i] * k26 + ema26[i - 1] * (1.0 - k26)
    macd = [ema12[i] - ema26[i] for i in range(n)]

    raw_buy = [False] * n
    raw_sell = [False] * n
    for i in range(50, n):
        # Dk MUA: Đáy MACD tại bar i-2 và ngóc lên 2 phiên liên tiếp (Phân kỳ dương)
        dk1_buy = (macd[i] > macd[i - 1] and 
                   macd[i - 1] > macd[i - 2] and 
                   macd[i - 2] < macd[i - 3] and 
                   macd[i - 3] < macd[i - 4])
        # Dk2: LLV(MACD, 7) > LLV(MACD, 50)
        llv_macd_7 = min(macd[i - 6 : i + 1])
        llv_macd_50 = min(macd[i - 49 : i + 1])
        dk2_buy = (llv_macd_7 > llv_macd_50)
        # DK3: LLV(L, 7) <= LLV(L, 50)
        llv_l_7 = min(l_arr[i - 6 : i + 1])
        llv_l_50 = min(l_arr[i - 49 : i + 1])
        dk3_buy = (llv_l_7 <= llv_l_50)
        # Giá hôm nay không giảm
        dk_c = (closes[i] >= closes[i - 1])

        if dk1_buy and dk2_buy and dk3_buy and dk_c:
            raw_buy[i] = True

        # DK BÁN: Phân kỳ âm MACD (AmiBroker AFL chuẩn)
        # MACD() < Ref(MACD(),-1) AND Ref(MACD(),-1)<Ref(MACD(),-2) AND Ref(MACD(),-2)>Ref(MACD(),-3) AND Ref(MACD(),-3)>Ref(MACD(),-4)
        # AND HHV(MACD(),7)<HHV(MACD(),50) AND HHV(H,5) >= HHV(H,50) AND C<REF(C,-1)
        dk1_sell = (macd[i] < macd[i - 1] and 
                    macd[i - 1] < macd[i - 2] and 
                    macd[i - 2] > macd[i - 3] and 
                    macd[i - 3] > macd[i - 4])
        # HHV(MACD(),7) < HHV(MACD(),50)
        hhv_macd_7 = max(macd[i - 6 : i + 1])
        hhv_macd_50 = max(macd[i - 49 : i + 1])
        dk2_sell = (hhv_macd_7 < hhv_macd_50)
        # HHV(H,5) >= HHV(H,50)
        hhv_h_5 = max(h_arr[i - 4 : i + 1])
        hhv_h_50 = max(h_arr[i - 49 : i + 1])
        dk3_sell = (hhv_h_5 >= hhv_h_50)
        # C < Ref(C,-1)
        dk4_sell = (closes[i] < closes[i - 1])

        if dk1_sell and dk2_sell and dk3_sell and dk4_sell:
            raw_sell[i] = True

    # Đưa về dạng lọc thống kê độc lập (không khử bằng ExRem)
    res_signals = []

    # Kiểm tra tín hiệu MUA (Phân kỳ dương MACD)
    last_buy_bar = -1
    for i in range(n - 1, 49, -1):
        if raw_buy[i]:
            last_buy_bar = i
            break

    if last_buy_bar >= 0:
        bars_since_buy = (n - 1) - last_buy_bar
        if bars_since_buy <= 20:
            last_buy_price = closes[last_buy_bar]
            prev_p = closes[-2] if n > 1 else cur_p
            pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0
            profit_pct = ((cur_p - last_buy_price) / last_buy_price) * 100.0 if last_buy_price > 0 else 0.0
            sig_price_vnd = last_buy_price * 1000.0 if last_buy_price < 1000.0 else last_buy_price
            sig_date = datetime.fromtimestamp(times[last_buy_bar]).strftime("%d/%m/%Y") if times and last_buy_bar < len(times) else ""
            status_text = "Hôm nay (T+0)" if bars_since_buy == 0 else f"{bars_since_buy} phiên (T+{bars_since_buy})"

            res_signals.append({
                "signal": "BUY",
                "price": round(price_vnd, 0),
                "pct_change": round(pct_chg, 2),
                "signal_price": round(sig_price_vnd, 0),
                "profit_pct": round(profit_pct, 2),
                "bars_since": bars_since_buy,
                "status_text": status_text,
                "ma10_vol": int(ma10_vol),
                "today_vol": int(vols[-1]),
                "signal_date": sig_date,
                "is_today": (bars_since_buy == 0)
            })

    # Kiểm tra tín hiệu BÁN (Phân kỳ âm MACD)
    last_sell_bar = -1
    for i in range(n - 1, 49, -1):
        if raw_sell[i]:
            last_sell_bar = i
            break

    if last_sell_bar >= 0:
        bars_since_sell = (n - 1) - last_sell_bar
        if bars_since_sell <= 20:
            last_sell_price = closes[last_sell_bar]
            prev_p = closes[-2] if n > 1 else cur_p
            pct_chg = ((cur_p - prev_p) / prev_p) * 100.0 if prev_p > 0 else 0.0
            profit_pct = ((last_sell_price - cur_p) / last_sell_price) * 100.0 if last_sell_price > 0 else 0.0
            sig_price_vnd = last_sell_price * 1000.0 if last_sell_price < 1000.0 else last_sell_price
            sig_date = datetime.fromtimestamp(times[last_sell_bar]).strftime("%d/%m/%Y") if times and last_sell_bar < len(times) else ""
            status_text = "Hôm nay (T+0)" if bars_since_sell == 0 else f"{bars_since_sell} phiên (T+{bars_since_sell})"

            res_signals.append({
                "signal": "SELL",
                "price": round(price_vnd, 0),
                "pct_change": round(pct_chg, 2),
                "signal_price": round(sig_price_vnd, 0),
                "profit_pct": round(profit_pct, 2),
                "bars_since": bars_since_sell,
                "status_text": status_text,
                "ma10_vol": int(ma10_vol),
                "today_vol": int(vols[-1]),
                "signal_date": sig_date,
                "is_today": (bars_since_sell == 0)
            })

    return res_signals if res_signals else None


async def _scan_and_compute_all_technical_signals(force_refresh: bool = False) -> Dict[str, List[Dict[str, Any]]]:
    """
    ĐỘNG CƠ QUÉT SIÊU TỐC ĐỒNG THỜI TOÀN BỘ 5 CHIẾN LƯỢC KỸ THUẬT:
    1. Fansi T+
    2. Robot 1 (The Beast - Zero-lag DEMA)
    3. Robot 2 (Rocket Jet - Momentum Breakout)
    4. Phân kỳ MACD (Divergence MACD)
    5. Phân kỳ RSI (Divergence RSI)
    Kết hợp nến lịch sử từ RAM/Disk cache + nến Realtime SSI FastConnect trong phiên.
    Tất cả 5 chiến lược được tính toán song song trong bộ nhớ RAM chỉ mất ~30ms-50ms.
    """
    global _ALL_TECH_SIGNALS_CACHE, _ALL_TECH_SIGNALS_CACHE_TS, _MARKET_CANDLES_CACHE, _MARKET_CANDLES_CACHE_TS
    now_ts = time.time()

    # TTL 60s trong phiên: Nếu cache còn mới và không ép buộc làm mới -> trả kết quả tức thì (< 0.1ms)
    if not force_refresh and _ALL_TECH_SIGNALS_CACHE and (now_ts - _ALL_TECH_SIGNALS_CACHE_TS) < 60.0:
        return _ALL_TECH_SIGNALS_CACHE

    async with _TECH_SCAN_LOCK:
        now_ts = time.time()
        if not force_refresh and _ALL_TECH_SIGNALS_CACHE and (now_ts - _ALL_TECH_SIGNALS_CACHE_TS) < 60.0:
            return _ALL_TECH_SIGNALS_CACHE

        # 1. Đảm bảo bảng giá SSI Live sẵn sàng
        try:
            from crawler import _SSI_EXCHANGE_CACHE, fetch_ssi_live_stock_quote
            if not _SSI_EXCHANGE_CACHE or len(_SSI_EXCHANGE_CACHE) < 500:
                await fetch_ssi_live_stock_quote("VN30")
        except Exception:
            pass

        from company_database import COMPANY_DATABASE
        from crawler import _SSI_EXCHANGE_CACHE

        # 2. Thu thập danh sách cổ phiếu tiềm năng trên toàn thị trường có thanh khoản hợp lý
        candidates = []
        seen = set()

        pool = []
        if _SSI_EXCHANGE_CACHE:
            for s in _SSI_EXCHANGE_CACHE.values():
                sym = (s.get("stockSymbol") or "").upper().strip()
                if not sym or len(sym) != 3 or not sym.isalpha():
                    continue
                stype = str(s.get("stockType") or "s").lower()
                if stype not in ["s", "stock"]:
                    continue
                pool.append((sym, s))

        if not pool:
            for sym, comp in COMPANY_DATABASE.items():
                pool.append((sym, {"stockSymbol": sym, "exchange": comp.get("exchange", "HOSE"), "matchedPrice": comp.get("price", 0)}))

        for sym, s_info in pool:
            if sym in seen:
                continue
            seen.add(sym)

            comp = COMPANY_DATABASE.get(sym, {})
            raw_ex = (comp.get("exchange") or s_info.get("exchange") or "HOSE").upper().strip()
            c_ex = "HOSE" if "HOSE" in raw_ex else ("HNX" if "HNX" in raw_ex else ("UPCOM" if "UP" in raw_ex else raw_ex))

            m_p = float(s_info.get("matchedPrice") or 0.0)
            r_p = float(s_info.get("refPrice") or 0.0)
            c_p = m_p if m_p > 0 else (r_p if r_p > 0 else float(comp.get("price") or comp.get("market_price") or 0.0))
            if c_p > 0 and c_p < 3000:
                continue

            today_vol = float(s_info.get("nmTotalTradedQty") or 0.0)
            avg_3m = float(comp.get("avg_volume_3m_k") or 0.0) * 1000
            if today_vol < 10000 and avg_3m < 20000:
                continue

            name = comp.get("name") or s_info.get("companyNameVi") or sym
            candidates.append((sym, {"name": name, "exchange": c_ex, "price": c_p}))

        # 3. Nạp nến: Tái sử dụng tối đa RAM cache, chỉ fetch những mã chưa có hoặc quá hạn (> 300s)
        syms_to_fetch = []
        for sym, _ in candidates:
            if force_refresh or sym not in _MARKET_CANDLES_CACHE or (now_ts - _MARKET_CANDLES_CACHE_TS.get(sym, 0)) >= 300.0:
                syms_to_fetch.append(sym)

        if syms_to_fetch:
            from_ts = int(now_ts) - 86400 * 300
            to_ts = int(now_ts)
            sem = asyncio.Semaphore(35)
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

            async def _fetch_one_candle(client: httpx.AsyncClient, s_tkr: str):
                async with sem:
                    url = f"https://services.entrade.com.vn/chart-api/v2/ohlcs/stock?from={from_ts}&to={to_ts}&symbol={s_tkr}&resolution=1D"
                    try:
                        r = await client.get(url, timeout=3.5)
                        if r.status_code == 200:
                            d = r.json()
                            c_arr = d.get("c", [])
                            if c_arr:
                                mult = 1000.0 if c_arr[-1] < 1000.0 else 1.0
                                return s_tkr, {
                                    "c": [x * mult for x in c_arr],
                                    "o": [x * mult for x in d.get("o", [])],
                                    "h": [x * mult for x in d.get("h", [])],
                                    "l": [x * mult for x in d.get("l", [])],
                                    "v": d.get("v", []),
                                    "t": d.get("t", [])
                                }
                    except Exception:
                        pass
                return s_tkr, None

            async with httpx.AsyncClient(headers=headers, timeout=5.0) as client:
                tasks = [_fetch_one_candle(client, s) for s in syms_to_fetch]
                res_fetched = await asyncio.gather(*tasks)
                new_saved = False
                for s_tkr, c_data in res_fetched:
                    if c_data:
                        _MARKET_CANDLES_CACHE[s_tkr] = c_data
                        _MARKET_CANDLES_CACHE_TS[s_tkr] = now_ts
                        new_saved = True

                if new_saved:
                    asyncio.create_task(asyncio.to_thread(_save_candles_disk_cache))

        # 4. Gán RS map và chuẩn bị dữ liệu Realtime
        rs_map = get_market_rs_ratings()
        from datetime import timezone, timedelta
        vn_tz = timezone(timedelta(hours=7))
        now_vn = datetime.now(vn_tz)
        is_market_open = (now_vn.weekday() < 5 and now_vn.hour >= 9)

        all_signals: Dict[str, List[Dict[str, Any]]] = {
            "fansi": [],
            "robot1": [],
            "robot2": [],
            "div_macd": [],
            "div_rsi": []
        }

        # 5. TÍNH TOÁN SONG SONG CẢ 5 CHIẾN LƯỢC TRONG BỘ NHỚ RAM TRONG < 50ms
        for sym, c_meta in candidates:
            candles = _MARKET_CANDLES_CACHE.get(sym)
            if not candles:
                continue

            c_arr = list(candles["c"])
            o_arr = list(candles["o"])
            h_arr = list(candles["h"])
            l_arr = list(candles["l"])
            v_arr = list(candles["v"])
            t_arr = list(candles["t"])
            if len(c_arr) < 25:
                continue

            ssi_data = _SSI_EXCHANGE_CACHE.get(sym) if _SSI_EXCHANGE_CACHE else None
            live_price = c_meta["price"]
            live_pct = 0.0
            today_vol = int(v_arr[-1]) if v_arr else 0

            if ssi_data:
                m_p = float(ssi_data.get("matchedPrice") or 0.0)
                r_p = float(ssi_data.get("refPrice") or 0.0)
                o_p = float(ssi_data.get("openPrice") or 0.0)
                h_p = float(ssi_data.get("highest") or 0.0)
                l_p = float(ssi_data.get("lowest") or 0.0)
                vol = float(ssi_data.get("nmTotalTradedQty") or 0.0)
                if ssi_data.get("priceChangePercent") is not None:
                    live_pct = float(ssi_data.get("priceChangePercent"))
                if vol > 0:
                    today_vol = int(vol)

                if is_market_open and (vol > 0 or o_p > 0 or m_p > 0):
                    live_c = m_p if m_p > 0 else (o_p if o_p > 0 else r_p)
                    if live_c > 0:
                        live_price = live_c
                        live_o = o_p if o_p > 0 else live_c
                        live_h = h_p if h_p > 0 else max(live_c, live_o)
                        live_l = l_p if l_p > 0 else min(live_c, live_o)
                        today_date = now_vn.date()
                        last_bar_date = datetime.fromtimestamp(t_arr[-1], tz=vn_tz).date()
                        today_ts = int(datetime(now_vn.year, now_vn.month, now_vn.day, 9, 0, 0, tzinfo=vn_tz).timestamp())

                        if last_bar_date == today_date:
                            if len(c_arr) >= 2 and r_p > 0 and c_arr[-2] > 0 and abs(c_arr[-2] - r_p) / r_p > 0.005:
                                adj_factor = r_p / c_arr[-2]
                                for idx in range(len(c_arr) - 1):
                                    c_arr[idx] *= adj_factor
                                    o_arr[idx] *= adj_factor
                                    h_arr[idx] *= adj_factor
                                    l_arr[idx] *= adj_factor
                                c_arr[-2] = r_p
                            c_arr[-1] = live_c
                            if live_o > 0: o_arr[-1] = live_o
                            h_arr[-1] = max(h_arr[-1], live_h)
                            l_arr[-1] = min(l_arr[-1], live_l) if l_arr[-1] > 0 else live_l
                            if vol > 0: v_arr[-1] = max(v_arr[-1], vol)
                        else:
                            if len(c_arr) >= 1 and r_p > 0 and c_arr[-1] > 0 and abs(c_arr[-1] - r_p) / r_p > 0.005:
                                adj_factor = r_p / c_arr[-1]
                                for idx in range(len(c_arr)):
                                    c_arr[idx] *= adj_factor
                                    o_arr[idx] *= adj_factor
                                    h_arr[idx] *= adj_factor
                                    l_arr[idx] *= adj_factor
                                c_arr[-1] = r_p
                            c_arr.append(live_c)
                            o_arr.append(live_o)
                            h_arr.append(live_h)
                            l_arr.append(live_l)
                            v_arr.append(vol)
                            t_arr.append(today_ts)

            comp_name = c_meta["name"]
            c_ex = c_meta["exchange"]
            stock_rs = rs_map.get(sym, 50)

            def _enrich(item):
                item["symbol"] = sym
                item["name"] = comp_name
                item["exchange"] = c_ex
                item["rs_rating"] = stock_rs
                if live_price > 0: item["price"] = live_price
                if live_pct != 0.0: item["pct_change"] = live_pct; item["price_change_pct"] = live_pct
                if today_vol > 0: item["today_vol"] = today_vol
                return item

            # 1. Fansi
            rf = _calculate_fansi_core(c_arr, o_arr, v_arr, t_arr, min_vol=0, min_price=0)
            if rf: all_signals["fansi"].append(_enrich(rf))

            # 2. Robot1
            r1 = _calculate_robot1_core(c_arr, v_arr, t_arr, min_vol=0, min_price=0)
            if r1: all_signals["robot1"].append(_enrich(r1))

            # 3. Robot2
            r2 = _calculate_robot2_core(c_arr, h_arr, l_arr, v_arr, t_arr, min_vol=0, min_price=0)
            if r2: all_signals["robot2"].append(_enrich(r2))

            # 4. Div MACD
            rdm = _calculate_divergence_macd_core(c_arr, l_arr, v_arr, t_arr, min_vol=0, min_price=0, highs=h_arr)
            if rdm:
                for it in rdm: all_signals["div_macd"].append(_enrich(it))

            # 5. Div RSI
            rdr = _calculate_divergence_rsi_core(c_arr, l_arr, v_arr, t_arr, min_vol=0, min_price=0, highs=h_arr)
            if rdr:
                for it in rdr: all_signals["div_rsi"].append(_enrich(it))

        _ALL_TECH_SIGNALS_CACHE = all_signals
        _ALL_TECH_SIGNALS_CACHE_TS = now_ts
        return all_signals


@app.get("/api/screener/fansi-signals")
@app.get("/api/screener/robot-signals")
async def get_fansi_screener(
    strategy: str = "fansi",
    exchange: str = "ALL",
    min_vol: int = 100000,
    min_price: float = 5000.0,
    min_rs: int = 0,
    timing: str = "recent",
    refresh: bool = False
):
    """
    Bộ lọc quét toàn thị trường các mã cổ phiếu có tín hiệu Mua / Bán FANSI T+, ROBOT 1, ROBOT 2, PHÂN KỲ MACD, PHÂN KỲ RSI (AmiBroker AFL).
    Tốc độ phản hồi: < 1ms khi chuyển đổi giữa các chiến lược nhờ động cơ tính toán song song trong bộ nhớ RAM.
    """
    clean_strat = (strategy or "fansi").lower().strip()
    clean_ex = (exchange or "ALL").upper().strip()

    signals_dict = await _scan_and_compute_all_technical_signals(force_refresh=refresh)
    raw_signals = signals_dict.get(clean_strat, [])

    filtered = []
    for r in raw_signals:
        sym = r.get("symbol", "")
        c_ex = r.get("exchange", "HOSE")
        p = float(r.get("price") or 0.0)
        ma10_v = int(r.get("ma10_vol") or 0)
        today_v = int(r.get("today_vol") or 0)
        v_eval = ma10_v if ma10_v > 0 else today_v
        rs = int(r.get("rs_rating") or 50)
        bars = int(r.get("bars_since") if r.get("bars_since") is not None else 99)

        if clean_ex == "VN30" and sym not in VN30_TICKERS:
            continue
        elif clean_ex not in ["ALL", "VN30"] and c_ex != clean_ex:
            continue

        if min_price > 0 and p < min_price:
            continue
        if min_vol > 0 and v_eval < min_vol:
            continue
        if min_rs > 0 and rs < min_rs:
            continue

        if timing == "today" and bars != 0:
            continue
        elif timing == "recent" and bars > 3:
            continue

        filtered.append(r)

    buy_list = [r for r in filtered if r["signal"] == "BUY"]
    sell_list = [r for r in filtered if r["signal"] == "SELL"]
    buy_list.sort(key=lambda x: (x["bars_since"], -x["ma10_vol"]))
    sell_list.sort(key=lambda x: (x["bars_since"], -x["ma10_vol"]))

    ret_payload = {
        "updated_at": datetime.now().strftime("%H:%M:%S %d/%m/%Y"),
        "strategy": clean_strat,
        "exchange": clean_ex,
        "min_vol": min_vol,
        "min_price": min_price,
        "min_rs": min_rs,
        "timing": timing,
        "summary": {
            "total_candidates": len(raw_signals),
            "total_matched": len(filtered),
            "buy_count": len(buy_list),
            "sell_count": len(sell_list),
            "today_buy_count": sum(1 for b in buy_list if b["bars_since"] == 0),
            "today_sell_count": sum(1 for s in sell_list if s["bars_since"] == 0)
        },
        "buy_signals": buy_list,
        "sell_signals": sell_list
    }
    return ret_payload


# -------------------------------------------------------------
# 5 PHƯƠNG PHÁP BỘ LỌC CỔ PHIẾU CÁC QUỸ ĐẦU TƯ TỔ CHỨC
# Value, Growth, GARP (Peter Lynch), Quality & Moat, Momentum
# -------------------------------------------------------------
_FUND_SCREENER_CACHE: Dict[str, Any] = {}
_FUND_SCREENER_CACHE_TS: Dict[str, float] = {}
_RS_RATINGS_CACHE: Dict[str, int] = {}
_RS_RATINGS_CACHE_TS: float = 0.0

def get_market_rs_ratings(force_refresh: bool = False) -> Dict[str, int]:
    global _RS_RATINGS_CACHE, _RS_RATINGS_CACHE_TS
    now = time.time()
    if not force_refresh and _RS_RATINGS_CACHE and (now - _RS_RATINGS_CACHE_TS) < 300.0:
        return _RS_RATINGS_CACHE

    perf_cache_path = os.path.join(os.path.dirname(__file__), "data", "market_performance_cache.json")
    if os.path.exists(perf_cache_path):
        try:
            with open(perf_cache_path, "r", encoding="utf-8") as f:
                perf_data = json.load(f)
            rs_map = {}
            for sym, item in perf_data.items():
                if "rs_rating" in item:
                    rs_map[sym.upper()] = int(item["rs_rating"])
            if len(rs_map) >= 500:
                _RS_RATINGS_CACHE = rs_map
                _RS_RATINGS_CACHE_TS = now
                return rs_map
        except Exception as e:
            print(f"Error loading market_performance_cache: {e}")

    from company_database import COMPANY_DATABASE
    from crawler import _SSI_EXCHANGE_CACHE

    all_syms = set()
    for s in COMPANY_DATABASE.keys():
        if len(s) == 3 and s.isalpha():
            all_syms.add(s.upper())
    for s in _SSI_EXCHANGE_CACHE.keys():
        if len(s) == 3 and s.isalpha():
            all_syms.add(s.upper())

    scores = []
    for sym in all_syms:
        comp = COMPANY_DATABASE.get(sym, {})
        ssi_item = _SSI_EXCHANGE_CACHE.get(sym, {})
        today_pct = float(ssi_item.get("priceChangePercent") or 0.0) if ssi_item else 0.0

        if comp:
            c3m = float(comp.get("price_change_3m_pct") or 0.0)
            c1m = float(comp.get("price_change_1m_pct") or 0.0)
            cytd = float(comp.get("price_change_ytd_pct") or 0.0)

            # Cơ chế đồng bộ đà biến động giá Realtime SSI 2 chiều:
            base_p = float(comp.get("price") or 0.0)
            live_p = float(ssi_item.get("matchedPrice") or ssi_item.get("refPrice") or 0.0) if ssi_item else 0.0
            if base_p > 1000 and live_p > 1000:
                drift = (live_p - base_p) / base_p * 100.0
                if abs(drift) > 5.0:
                    c1m += drift * 0.8
                    c3m += drift * 0.8
                    cytd += drift * 0.8

            score = (c3m + today_pct * 0.1) * 2.0 + (c1m + today_pct * 0.3) + (cytd + today_pct * 0.1) * 0.5
        else:
            score = today_pct * 2.0

        scores.append((sym, score))

    scores.sort(key=lambda x: x[1])
    n = max(1, len(scores))
    rs_map = {}
    for rank, (sym, sc) in enumerate(scores):
        percentile = max(1, min(99, int(round((rank + 1) / n * 99))))
        rs_map[sym] = percentile
    _RS_RATINGS_CACHE = rs_map
    _RS_RATINGS_CACHE_TS = now
    return rs_map


@app.post("/api/screener/sync-rs")
async def api_sync_rs_market():
    """
    Kích hoạt đồng bộ nến lịch sử và tính lại RS toàn thị trường 1.400+ mã.
    """
    from sync_market_rs import sync_all_stocks
    asyncio.create_task(sync_all_stocks())
    return {"status": "success", "message": "Đang đồng bộ dữ liệu RS nến lịch sử cho 1.400+ mã toàn thị trường trong nền..."}


@app.get("/api/screener/rs-ranking")
async def get_rs_ranking_screener(
    min_rs: int = 0,
    exchange: str = "ALL",
    min_vol: int = 10000,
    min_price: float = 3000.0,
    refresh: bool = False
):
    """
    Bộ lọc độc lập theo chỉ số sức mạnh giá Relative Strength (RS).
    Liệt kê toàn bộ các mã cổ phiếu trên thị trường được chấm điểm RS (1-99)
    dựa trên toàn bộ ~1.400+ mã trực tiếp từ bảng giá SSI feed và CSDL doanh nghiệp.
    Hỗ trợ đồng bộ đa chiều với tiêu chí Sàn, Thanh khoản (KL TB 10N) và Thị giá.
    """
    clean_ex = (exchange or "ALL").upper().strip()
    cache_key = f"rs_rank_{clean_ex}_{min_price}_{min_vol}"
    now_ts = time.time()

    if refresh:
        global _RS_RATINGS_CACHE, _RS_RATINGS_CACHE_TS
        _RS_RATINGS_CACHE = {}
        _RS_RATINGS_CACHE_TS = 0.0

    if not refresh and cache_key in _FUND_SCREENER_CACHE and (now_ts - _FUND_SCREENER_CACHE_TS.get(cache_key, 0)) < 45.0:
        raw_items = _FUND_SCREENER_CACHE[cache_key]
    else:
        from company_database import COMPANY_DATABASE
        try:
            from crawler import fetch_ssi_live_stock_quote, _SSI_EXCHANGE_CACHE
            if not _SSI_EXCHANGE_CACHE or len(_SSI_EXCHANGE_CACHE) < 500:
                await fetch_ssi_live_stock_quote("HPG")
        except Exception:
            _SSI_EXCHANGE_CACHE = {}

        rs_map = get_market_rs_ratings(force_refresh=refresh)
        raw_items = []
        all_syms = sorted(list(rs_map.keys()))

        for sym in all_syms:
            comp = COMPANY_DATABASE.get(sym, {})
            ssi_item = _SSI_EXCHANGE_CACHE.get(sym.upper()) if _SSI_EXCHANGE_CACHE else None

            c_ex = "HOSE"
            if ssi_item and ssi_item.get("exchange"):
                c_ex = str(ssi_item.get("exchange")).upper().strip()
            elif comp and comp.get("exchange"):
                c_ex = str(comp.get("exchange")).upper().strip()

            if clean_ex == "VN30" and sym not in VN30_TICKERS:
                continue
            elif clean_ex not in ["ALL", "VN30"] and c_ex != clean_ex:
                continue

            # ƯU TIÊN SỐ 1: Bảng giá SSI Live trực tuyến (100% khớp biểu đồ nến real-time)
            price = 0.0
            live_pct = 0.0
            today_vol = 0
            if ssi_item:
                m_p = float(ssi_item.get("matchedPrice") or 0.0)
                r_p = float(ssi_item.get("refPrice") or 0.0)
                price = m_p if m_p > 0 else r_p
                if ssi_item.get("priceChangePercent") is not None:
                    live_pct = float(ssi_item.get("priceChangePercent") or 0.0)
                today_vol = int(ssi_item.get("nmTotalTradedQty") or ssi_item.get("matchedVolume") or 0)

            if price <= 0:
                if sym in _RECONCILED_LIVE_PRICE_CACHE:
                    lp = _RECONCILED_LIVE_PRICE_CACHE[sym]
                    price = float(lp.get("latest_close") or 0.0)
                    live_pct = float(lp.get("change_percent") or 0.0)
                elif comp:
                    price = float(comp.get("price") or comp.get("market_price") or 0.0)
                    live_pct = float(comp.get("price_change_1m_pct") or 0.0)

            if min_price > 0 and price < min_price:
                continue

            vol_3m = int((comp.get("avg_volume_3m_k") or 0) * 1000) if comp else 0
            vol_eval = today_vol if today_vol > 0 else vol_3m
            if min_vol > 0 and vol_eval < min_vol:
                continue

            val_3m = float(comp.get("avg_value_3m_bil") or 0.0) if comp else 0.0
            mcap = float(comp.get("market_cap_bil") or 0.0) if comp else 0.0
            p3m = float(comp.get("price_change_3m_pct") or 0.0) if comp else live_pct
            p1m = float(comp.get("price_change_1m_pct") or 0.0) if comp else live_pct
            base_p = float(comp.get("price") or 0.0) if comp else 0.0
            if base_p > 1000 and price > 1000:
                drift = (price - base_p) / base_p * 100.0
                if drift > 5.0:
                    p1m += drift * 0.8
                    p3m += drift * 0.8
                    if mcap > 0:
                        mcap = mcap * (price / base_p)
            rs = rs_map.get(sym, 50)
            comp_name = comp.get("name") if comp else (ssi_item.get("companyNameVi") if ssi_item else sym)

            raw_items.append({
                "ticker": sym,
                "name": comp_name or sym,
                "exchange": c_ex,
                "price": price,
                "price_change_pct": round(live_pct, 2),
                "pct_change": round(live_pct, 2),
                "price_change_1m_pct": round(p1m, 2),
                "price_change_3m_pct": round(p3m, 2),
                "volume": vol_eval,
                "today_vol": today_vol,
                "avg_volume_3m": vol_3m,
                "avg_value_bil": round(val_3m, 2),
                "market_cap_bil": round(mcap, 1),
                "rs_rating": rs
            })

        # Sắp xếp mặc định: RS cao nhất lên đầu, tiếp đến là hiệu suất 3T
        raw_items.sort(key=lambda x: (x["rs_rating"], x["price_change_3m_pct"]), reverse=True)
        _FUND_SCREENER_CACHE[cache_key] = raw_items
        _FUND_SCREENER_CACHE_TS[cache_key] = now_ts

    filtered = [it for it in raw_items if it["rs_rating"] >= min_rs]
    return {
        "status": "success",
        "updated_at": datetime.now().strftime("%H:%M:%S %d/%m/%Y"),
        "total_count": len(filtered),
        "total_market_stocks": len(rs_map),
        "min_rs": min_rs,
        "exchange": clean_ex,
        "items": filtered
    }


_ALL_FUND_STRATEGIES_CACHE: Dict[str, List[Dict[str, Any]]] = {}
_ALL_FUND_STRATEGIES_CACHE_TS: float = 0.0

def _compute_all_fund_strategies(force_refresh: bool = False) -> Dict[str, List[Dict[str, Any]]]:
    global _ALL_FUND_STRATEGIES_CACHE, _ALL_FUND_STRATEGIES_CACHE_TS
    now_ts = time.time()
    if not force_refresh and _ALL_FUND_STRATEGIES_CACHE and (now_ts - _ALL_FUND_STRATEGIES_CACHE_TS) < 60.0:
        return _ALL_FUND_STRATEGIES_CACHE

    from company_database import COMPANY_DATABASE
    try:
        from crawler import _SSI_EXCHANGE_CACHE
    except Exception:
        _SSI_EXCHANGE_CACHE = {}

    rs_map = get_market_rs_ratings()
    fund_results = {
        "value": [],
        "growth": [],
        "garp": [],
        "quality": [],
        "momentum": []
    }

    for sym, comp in COMPANY_DATABASE.items():
        c_ex = (comp.get("exchange") or "HOSE").upper().strip()
        ssi_item = _SSI_EXCHANGE_CACHE.get(sym.upper()) if _SSI_EXCHANGE_CACHE else None
        price = 0.0
        live_pct = 0.0
        today_vol = 0
        if ssi_item:
            m_p = float(ssi_item.get("matchedPrice") or 0.0)
            r_p = float(ssi_item.get("refPrice") or 0.0)
            price = m_p if m_p > 0 else r_p
            if ssi_item.get("priceChangePercent") is not None:
                live_pct = float(ssi_item.get("priceChangePercent") or 0.0)
            today_vol = int(ssi_item.get("nmTotalTradedQty") or ssi_item.get("matchedVolume") or 0)

        if price <= 0:
            if sym in _RECONCILED_LIVE_PRICE_CACHE:
                lp = _RECONCILED_LIVE_PRICE_CACHE[sym]
                price = float(lp.get("latest_close") or 0.0)
                live_pct = float(lp.get("change_percent") or 0.0)
            else:
                price = float(comp.get("price") or comp.get("market_price") or 0.0)
                live_pct = float(comp.get("price_change_1m_pct") or 0.0)

        vol_3m = int((comp.get("avg_volume_3m_k") or 0) * 1000)
        vol_eval = today_vol if today_vol > 0 else vol_3m

        pe = float(comp.get("pe_ttm") or 0.0)
        pb = float(comp.get("pb_ttm") or 0.0)
        roe = float(comp.get("roe_ttm_pct") or 0.0)
        np_grow = float(comp.get("net_profit_growth_yoy_pct") or 0.0)
        rev_grow = float(comp.get("revenue_growth_yoy_pct") or 0.0)
        eps_grow = float(comp.get("eps_growth_yoy_pct") or np_grow)
        val_3m = float(comp.get("avg_value_3m_bil") or 0.0)
        mcap = float(comp.get("market_cap_bil") or 0.0)
        p3m = float(comp.get("price_change_3m_pct") or 0.0)
        p1m = float(comp.get("price_change_1m_pct") or 0.0)
        rs = rs_map.get(sym, 50)

        grow_rate = eps_grow if eps_grow > 0 else np_grow
        peg_calc = round(pe / grow_rate, 2) if (grow_rate > 0 and pe > 0) else None

        base_item = {
            "ticker": sym,
            "name": comp.get("name", sym),
            "exchange": c_ex,
            "price": price,
            "price_change_pct": round(live_pct, 2),
            "pct_change": round(live_pct, 2),
            "volume": vol_eval,
            "today_vol": today_vol,
            "avg_volume_3m": vol_3m,
            "avg_value_bil": round(val_3m, 2),
            "market_cap_bil": round(mcap, 1),
            "pe": round(pe, 2) if pe > 0 else None,
            "pb": round(pb, 2) if pb > 0 else None,
            "roe": round(roe, 1),
            "eps_growth": round(eps_grow, 1),
            "net_profit_growth": round(np_grow, 1),
            "revenue_growth": round(rev_grow, 1),
            "peg": peg_calc,
            "rs_rating": rs
        }

        # 1. Value
        if 0 < pe <= 12.0 and 0 < pb <= 1.6 and roe >= 10.0 and val_3m >= 1.0:
            it = dict(base_item)
            it["highlight_label"] = f"P/E: {pe:.1f} | P/B: {pb:.2f}"
            it["highlight_val"] = f"ROE {roe:.1f}%"
            it["_sort_val"] = pe
            fund_results["value"].append(it)

        # 2. Growth
        if np_grow >= 15.0 and rev_grow >= 10.0 and roe >= 14.0 and val_3m >= 1.5:
            it = dict(base_item)
            it["highlight_label"] = f"LNST +{np_grow:.1f}%"
            it["highlight_val"] = f"DThu +{rev_grow:.1f}%"
            it["_sort_val"] = -np_grow
            fund_results["growth"].append(it)

        # 3. GARP (Peter Lynch)
        if grow_rate >= 12.0 and 0 < pe <= 22.0:
            peg = round(pe / grow_rate, 2)
            if 0.25 <= peg <= 1.30 and roe >= 12.0 and val_3m >= 1.0:
                it = dict(base_item)
                it["highlight_label"] = f"PEG: {peg:.2f}"
                it["highlight_val"] = f"EPS +{grow_rate:.1f}%"
                it["_sort_val"] = peg
                fund_results["garp"].append(it)

        # 4. Quality & Moat
        if roe >= 18.0 and mcap >= 1500.0 and 0 < pe <= 25.0 and val_3m >= 1.5:
            it = dict(base_item)
            it["highlight_label"] = f"ROE: {roe:.1f}%"
            it["highlight_val"] = f"Vốn hóa {mcap:,.0f} tỷ"
            it["_sort_val"] = -roe
            fund_results["quality"].append(it)

        # 5. Momentum
        if p3m >= 5.0 and p1m >= 0.0 and rs >= 70 and val_3m >= 3.0:
            it = dict(base_item)
            it["highlight_label"] = f"RS: {rs}"
            it["highlight_val"] = f"3T: +{p3m:.1f}%"
            it["_sort_val"] = -rs
            fund_results["momentum"].append(it)

    for strat in fund_results:
        fund_results[strat].sort(key=lambda x: x["_sort_val"])

    _ALL_FUND_STRATEGIES_CACHE = fund_results
    _ALL_FUND_STRATEGIES_CACHE_TS = now_ts
    return fund_results


@app.get("/api/screener/fund-strategies")
async def get_fund_screener_strategies(
    strategy: str = "value",
    exchange: str = "ALL",
    min_price: float = 5000.0,
    min_vol: int = 50000,
    refresh: bool = False
):
    """
    5 phương pháp tìm kiếm cổ phiếu được các quỹ đầu tư tổ chức sử dụng:
    1. value: Value Investing (Đầu tư giá trị)
    2. growth: Growth Investing (Đầu tư tăng trưởng)
    3. garp: GARP - Peter Lynch (Growth At Reasonable Price)
    4. quality: Quality & Moat (Đầu tư chất lượng & Lợi thế cạnh tranh)
    5. momentum: Momentum & Trend (Đà tăng trưởng & Sức mạnh giá RS)
    Tốc độ phản hồi: < 0.1ms trong RAM.
    """
    clean_strat = (strategy or "value").lower().strip()
    clean_ex = (exchange or "ALL").upper().strip()

    STRATEGY_META = {
        "value": {
            "key": "value",
            "name": "Giá trị (Value)",
            "title": "💎 Giá trị (Value Investing)",
            "subtitle": "Biên an toàn & Định giá hấp dẫn",
            "philosophy": "Mua doanh nghiệp tốt với giá thấp hơn giá trị nội tại, có biên an toàn (P/E & P/B thấp, ROE ổn định).",
            "timeframe": "2 - 5 năm",
            "key_metrics": "P/B, P/E, FCF yield, ROE >= 10%",
            "suitable_market": "Cuối chu kỳ giảm, thị trường sợ hãi / tích lũy"
        },
        "growth": {
            "key": "growth",
            "name": "Tăng trưởng (Growth)",
            "title": "🚀 Tăng trưởng (Growth Investing)",
            "subtitle": "Bứt phá Doanh thu & Lợi nhuận",
            "philosophy": "Tìm doanh nghiệp có tốc độ tăng trưởng doanh thu và lợi nhuận vượt trội, duy trì ROE cao.",
            "timeframe": "1 - 3 năm",
            "key_metrics": "CAGR, PEG, biên lợi nhuận, LNST > 15%",
            "suitable_market": "Kinh tế mở rộng, lãi suất thấp, thị trường uptrend"
        },
        "garp": {
            "key": "garp",
            "name": "GARP (Peter Lynch)",
            "title": "🎯 GARP (Peter Lynch)",
            "subtitle": "Tăng trưởng ở mức định giá hợp lý",
            "philosophy": "Cân bằng giữa tăng trưởng và định giá, sàng lọc cổ phiếu PEG từ 0.25 đến 1.30 theo công thức Peter Lynch.",
            "timeframe": "2 - 4 năm",
            "key_metrics": "PEG 0.25 - 1.30, ROE, EPS growth >= 12%",
            "suitable_market": "Hầu hết các giai đoạn thị trường, đặc biệt phân hóa"
        },
        "quality": {
            "key": "quality",
            "name": "Chất lượng (Quality & Moat)",
            "title": "👑 Chất lượng (Quality & Moat)",
            "subtitle": "Lợi thế cạnh tranh bền vững & Sinh lời vốn cao",
            "philosophy": "Ưu tiên doanh nghiệp đầu ngành, hiệu quả sinh lời trên vốn (ROE >= 18%) vượt trội và tài chính lành mạnh.",
            "timeframe": "5 năm trở lên",
            "key_metrics": "ROIC, CFO/NI, F-Score, ROE >= 18%",
            "suitable_market": "Mọi giai đoạn, đặc biệt bất ổn / lãi suất cao"
        },
        "momentum": {
            "key": "momentum",
            "name": "Đà tăng trưởng (Momentum)",
            "title": "⚡ Đà tăng trưởng (Momentum & Trend)",
            "subtitle": "Sức mạnh giá Relative Strength & Xu hướng dẫn dắt",
            "philosophy": "Cổ phiếu mạnh nhất thị trường có xu hướng tiếp tục bứt phá trong trung hạn theo đà dòng tiền.",
            "timeframe": "3 - 12 tháng",
            "key_metrics": "RS, MA, khối lượng, Tăng giá 3T >= 5%",
            "suitable_market": "Xu hướng tăng rõ ràng, dòng tiền sôi động"
        }
    }

    meta = STRATEGY_META.get(clean_strat, STRATEGY_META["value"])
    fund_cache = _compute_all_fund_strategies(force_refresh=refresh)
    raw_list = fund_cache.get(clean_strat, [])

    matched = []
    for it in raw_list:
        sym = it["ticker"]
        c_ex = it["exchange"]
        p = it["price"]
        v = it["volume"]

        if clean_ex == "VN30" and sym not in VN30_TICKERS:
            continue
        elif clean_ex not in ["ALL", "VN30"] and c_ex != clean_ex:
            continue

        if min_price > 0 and p < min_price:
            continue
        if min_vol > 0 and v < min_vol:
            continue

        matched.append(it)

    return {
        "updated_at": datetime.now().strftime("%H:%M:%S %d/%m/%Y"),
        "strategy": clean_strat,
        "meta": meta,
        "exchange": clean_ex,
        "min_price": min_price,
        "total_matched": len(matched),
        "items": matched
    }


# ---------------------------------------------------------------------------
# BỘ LỌC CỔ TỨC, PHÁT HÀNH THÊM & DỮ LIỆU TÀI CHÍNH TOÀN DIỆN (1.400+ MÃ CP)
# ---------------------------------------------------------------------------
_DIVIDEND_SCREENER_CACHE: Dict[str, Any] = {}
_DIVIDEND_SCREENER_CACHE_TS: Dict[str, float] = {}
_ANNUAL_STMT_SUMMARIES: Optional[Dict[str, Dict[str, Any]]] = None


def _get_annual_statements_summary() -> Dict[str, Dict[str, Any]]:
    global _ANNUAL_STMT_SUMMARIES
    if _ANNUAL_STMT_SUMMARIES is not None:
        return _ANNUAL_STMT_SUMMARIES

    res: Dict[str, Dict[str, Any]] = {}
    stmt_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache", "statements")
    if os.path.exists(stmt_dir):
        # 1. Quét dữ liệu báo cáo năm
        for fn in os.listdir(stmt_dir):
            if fn.endswith("_year.json"):
                sym = fn.replace("_year.json", "").upper()
                fp = os.path.join(stmt_dir, fn)
                try:
                    with open(fp, "r", encoding="utf-8") as f:
                        d = json.load(f)
                        dt = d.get("data", {})
                        rev = dt.get("revenue") or []
                        np = dt.get("net_profit") or []
                        ast = dt.get("total_assets") or []
                        item: Dict[str, Any] = {}
                        if rev and len(rev) > 0 and rev[-1] is not None:
                            item["revenue_year"] = round(float(rev[-1]), 1)
                        if np and len(np) > 0 and np[-1] is not None:
                            item["net_profit_year"] = round(float(np[-1]), 1)
                        if np and ast and len(np) > 0 and len(ast) > 0 and ast[-1] and float(ast[-1]) > 0 and np[-1] is not None:
                            item["roa"] = round((float(np[-1]) / float(ast[-1])) * 100.0, 2)
                        if item:
                            res[sym] = item
                except Exception:
                    continue

        # 2. Quét dữ liệu báo cáo quý để bổ sung quý gần nhất & tính TTM fallback
        for fn in os.listdir(stmt_dir):
            if fn.endswith("_quarter.json"):
                sym = fn.replace("_quarter.json", "").upper()
                fp = os.path.join(stmt_dir, fn)
                try:
                    with open(fp, "r", encoding="utf-8") as f:
                        d = json.load(f)
                        dt = d.get("data", {})
                        rev_q = [float(x) for x in (dt.get("revenue") or []) if x is not None and float(x) > 0]
                        np_q = [float(x) for x in (dt.get("net_profit") or []) if x is not None]
                        ast_q = [float(x) for x in (dt.get("total_assets") or []) if x is not None and float(x) > 0]
                        item = res.get(sym, {})
                        if rev_q:
                            item["revenue_quarter"] = round(rev_q[-1], 1)
                        if np_q:
                            item["net_profit_quarter"] = round(np_q[-1], 1)
                        if "revenue_year" not in item and len(rev_q) >= 4:
                            item["revenue_year"] = round(sum(rev_q[-4:]), 1)
                        if "net_profit_year" not in item and len(np_q) >= 4:
                            item["net_profit_year"] = round(sum(np_q[-4:]), 1)
                        if "roa" not in item and len(np_q) >= 4 and ast_q:
                            item["roa"] = round((sum(np_q[-4:]) / ast_q[-1]) * 100.0, 2)
                        if item:
                            res[sym] = item
                except Exception:
                    continue
    _ANNUAL_STMT_SUMMARIES = res
    return _ANNUAL_STMT_SUMMARIES


@app.get("/api/screener/dividend-corporate-actions")
async def get_dividend_corporate_actions_screener(
    exchange: str = "ALL",
    search: str = "",
    has_cash_div: bool = False,
    has_stock_div: bool = False,
    has_rights: bool = False,
    sort_by: str = "market_cap",
    sort_order: str = "desc",
    refresh: bool = False
):
    """
    Bộ lọc Cổ tức, Phát hành thêm & Dữ liệu tài chính 19 trường dữ liệu chuẩn xác cho toàn bộ cổ phiếu trên sàn:
    Mã CP, Sàn, Ngành, SLCP lưu hành, Vốn hóa, EPS, PE, PB, ROE, ROA,
    Doanh thu/Lợi nhuận quý gần nhất, Doanh thu/Lợi nhuận năm gần nhất,
    Giá đóng cửa, Khối lượng TB 10 phiên, Cổ tức tiền, Cổ tức CP + Thưởng, Phát hành thêm.
    """
    clean_ex = (exchange or "ALL").upper().strip()
    clean_search = (search or "").strip().lower()
    clean_sort = (sort_by or "market_cap").strip().lower()
    clean_order = (sort_order or "desc").strip().lower()
    now_ts = time.time()

    cache_key = f"{clean_ex}_{clean_search}_{has_cash_div}_{has_stock_div}_{has_rights}_{clean_sort}_{clean_order}"
    if not refresh and cache_key in _DIVIDEND_SCREENER_CACHE and (now_ts - _DIVIDEND_SCREENER_CACHE_TS.get(cache_key, 0)) < 60.0:
        return _DIVIDEND_SCREENER_CACHE[cache_key]

    from company_database import COMPANY_DATABASE
    from corporate_actions import get_detailed_corporate_actions_dividend_summary

    # Lấy dữ liệu BCTC năm đã lưu bộ nhớ đệm
    annual_map = _get_annual_statements_summary()

    # Bảng giá SSI Live nếu có
    ssi_cache = {}
    try:
        from crawler import _SSI_EXCHANGE_CACHE
        if _SSI_EXCHANGE_CACHE:
            ssi_cache = _SSI_EXCHANGE_CACHE
    except Exception:
        pass

    results = []
    total_market_stocks = len(COMPANY_DATABASE)

    for sym, comp in COMPANY_DATABASE.items():
        sym_clean = sym.upper().strip()
        name = comp.get("name") or sym_clean

        # Tìm kiếm theo mã hoặc tên
        if clean_search:
            if clean_search not in sym_clean.lower() and clean_search not in name.lower():
                continue

        # Sàn giao dịch chuẩn hóa
        raw_ex = (comp.get("exchange") or "HOSE").upper().strip()
        ex = "HOSE" if "HOSE" in raw_ex else ("HNX" if "HNX" in raw_ex else ("UPCOM" if "UP" in raw_ex else raw_ex))
        if clean_ex != "ALL" and ex != clean_ex:
            continue

        # Ngành nghề chuẩn hóa tự động qua 23 nhóm ngành IERM
        industry = comp.get("fiintrade_sector") or comp.get("icb2")
        if not industry or industry == "Doanh nghiệp niêm yết":
            try:
                from adaptive_growth_engine import classify_business_model
                b_info = classify_business_model(sym_clean, "", name)
                industry = b_info.get("badge_text") or "Doanh nghiệp niêm yết"
            except Exception:
                industry = "Doanh nghiệp niêm yết"

        # Giá thị trường
        s_info = ssi_cache.get(sym_clean) or {}
        live_p = float(s_info.get("matchedPrice") or 0.0)
        ref_p = float(s_info.get("refPrice") or 0.0)
        db_p = float(comp.get("price") or 0.0)
        p = live_p if live_p > 0 else (ref_p if ref_p > 0 else db_p)

        # Vốn hóa
        mcap_bil = float(comp.get("market_cap_bil") or 0.0)

        # Số lượng CP lưu hành
        shares_out = None
        if comp.get("shares_outstanding_mil"):
            shares_out = int(round(float(comp["shares_outstanding_mil"]) * 1_000_000))
        elif comp.get("listed_shares"):
            shares_out = int(round(float(comp["listed_shares"])))
        elif p > 0 and mcap_bil > 0:
            shares_out = int(round((mcap_bil * 1_000_000_000) / p))
        else:
            try:
                from financial_data import VIETNAM_STOCK_DIRECTORY
                d_entry = VIETNAM_STOCK_DIRECTORY.get(sym_clean)
                if d_entry and d_entry.get("shares") and float(d_entry["shares"]) > 0:
                    shares_out = int(round(float(d_entry["shares"]) * 1_000_000))
            except Exception:
                pass

        # Tự động tính vốn hóa nếu có shares_out và giá p > 0
        if mcap_bil <= 0 and shares_out and p > 0:
            mcap_bil = round((shares_out * p) / 1_000_000_000, 2)

        # Chỉ số tài chính
        eps = float(comp.get("eps") or 0.0)
        pe = float(comp.get("pe_ttm") or 0.0)
        pb = float(comp.get("pb_ttm") or 0.0)
        roe = float(comp.get("roe_ttm_pct") or 0.0)

        if pe <= 0 and eps > 0 and p > 0:
            pe = round(p / eps, 2)

        if pe <= 0 or pb <= 0:
            try:
                from financial_data import VIETNAM_STOCK_DIRECTORY
                d_entry = VIETNAM_STOCK_DIRECTORY.get(sym_clean)
                if d_entry:
                    if pe <= 0 and d_entry.get("pe"):
                        pe = float(d_entry["pe"])
                    if pb <= 0 and d_entry.get("pb"):
                        pb = float(d_entry["pb"])
            except Exception:
                pass

        # Khối lượng TB 10 phiên
        vol_live = float(s_info.get("nmTotalTradedQty") or 0.0)
        vol_3m = float(comp.get("avg_volume_3m_k") or 0.0) * 1000.0
        vol_10d = int(round(vol_3m if vol_3m > 0 else vol_live))

        # Doanh thu / Lợi nhuận năm gần nhất & ROA từ BCTC kiểm toán
        ann_item = annual_map.get(sym_clean, {})
        rev_y = ann_item.get("revenue_year")
        np_y = ann_item.get("net_profit_year")
        roa = ann_item.get("roa")

        # Doanh thu / Lợi nhuận quý gần nhất
        rev_q = float(comp.get("revenue_q1_26_bil") or 0.0)
        np_q = float(comp.get("net_profit_q1_26_bil") or 0.0)
        if rev_q <= 0 and ann_item.get("revenue_quarter"):
            rev_q = float(ann_item["revenue_quarter"])
        if np_q <= 0 and ann_item.get("net_profit_quarter"):
            np_q = float(ann_item["net_profit_quarter"])

        # Cổ tức & Sự kiện quyền từ corporate_actions
        div_data = get_detailed_corporate_actions_dividend_summary(sym_clean, current_price=p)
        cash_amt = float(div_data.get("cash_amount") or 0.0)
        stock_pct = float(div_data.get("total_stock_pct") or 0.0)
        rights_pct = float(div_data.get("rights_ratio_pct") or 0.0)
        rights_price = float(div_data.get("rights_price") or 0.0)

        # Bộ lọc điều kiện có cổ tức / quyền
        if has_cash_div and cash_amt <= 0:
            continue
        if has_stock_div and stock_pct <= 0:
            continue
        if has_rights and rights_pct <= 0:
            continue

        results.append({
            "ticker": sym_clean,
            "name": name,
            "exchange": ex,
            "industry": industry,
            "shares_outstanding": shares_out,
            "market_cap": round(mcap_bil, 1) if mcap_bil > 0 else None,
            "eps": round(eps, 1) if eps != 0 else None,
            "pe": round(pe, 2) if pe > 0 else None,
            "pb": round(pb, 2) if pb > 0 else None,
            "roe": round(roe, 1) if roe != 0 else None,
            "roa": roa,
            "revenue_quarter": round(rev_q, 1) if rev_q != 0 else None,
            "net_profit_quarter": round(np_q, 1) if np_q != 0 else None,
            "revenue_year": rev_y,
            "net_profit_year": np_y,
            "price": round(p, 0) if p > 0 else None,
            "avg_volume_10d": vol_10d if vol_10d > 0 else None,
            "cash_dividend": {
                "amount": cash_amt,
                "par_pct": float(div_data.get("par_pct") or 0.0),
                "yield_pct": float(div_data.get("yield_pct") or 0.0),
                "display": div_data.get("cash_display") or ("0 đ" if cash_amt == 0 else f"{int(cash_amt):,} đ")
            },
            "stock_dividend": {
                "total_pct": stock_pct,
                "bonus_pct": float(div_data.get("bonus_pct") or 0.0),
                "stock_div_pct": float(div_data.get("stock_div_pct") or 0.0),
                "display": div_data.get("stock_display") or "0%"
            },
            "rights_issue": {
                "ratio_pct": rights_pct,
                "price": rights_price,
                "display": div_data.get("rights_display") or "-"
            }
        })

    # Sắp xếp
    def _sort_key(item):
        val = None
        if clean_sort == "market_cap":
            val = item.get("market_cap")
        elif clean_sort == "price":
            val = item.get("price")
        elif clean_sort == "avg_volume_10d":
            val = item.get("avg_volume_10d")
        elif clean_sort == "eps":
            val = item.get("eps")
        elif clean_sort == "pe":
            val = item.get("pe")
        elif clean_sort == "pb":
            val = item.get("pb")
        elif clean_sort == "roe":
            val = item.get("roe")
        elif clean_sort == "roa":
            val = item.get("roa")
        elif clean_sort == "cash_amount":
            val = item.get("cash_dividend", {}).get("amount")
        elif clean_sort == "stock_dividend":
            val = item.get("stock_dividend", {}).get("total_pct")
        elif clean_sort == "rights_ratio":
            val = item.get("rights_issue", {}).get("ratio_pct")
        elif clean_sort == "shares_outstanding":
            val = item.get("shares_outstanding")
        elif clean_sort == "revenue_quarter":
            val = item.get("revenue_quarter")
        elif clean_sort == "net_profit_quarter":
            val = item.get("net_profit_quarter")
        elif clean_sort == "revenue_year":
            val = item.get("revenue_year")
        elif clean_sort == "net_profit_year":
            val = item.get("net_profit_year")
        elif clean_sort == "ticker":
            return item.get("ticker", "")
        
        if val is None:
            return -1e12 if clean_order == "desc" else 1e12
        return float(val)

    reverse_sort = (clean_order == "desc")
    if clean_sort == "ticker":
        results.sort(key=lambda x: x.get("ticker", ""), reverse=reverse_sort)
    else:
        results.sort(key=_sort_key, reverse=reverse_sort)

    payload = {
        "updated_at": datetime.now().strftime("%H:%M:%S %d/%m/%Y"),
        "total_market_stocks": total_market_stocks,
        "total_matched": len(results),
        "exchange": clean_ex,
        "items": results
    }

    _DIVIDEND_SCREENER_CACHE[cache_key] = payload
    _DIVIDEND_SCREENER_CACHE_TS[cache_key] = now_ts
    return payload


@app.get("/api/search")
async def search_reports(ticker: str, sector: Optional[str] = ""):
    if not ticker:
        raise HTTPException(status_code=400, detail="Mã cổ phiếu không được để trống")
    clean_tk = ticker.strip().upper()
    try:
        results = await search_institutional_reports(clean_tk, sector or "")
        # Đánh dấu cờ already_learned để chống nạp trùng lặp từ đầu
        try:
            from ai_learning_engine import is_report_already_learned
            for item in results:
                raw_url = item.get("url", "")
                raw_inst = item.get("institution", "")
                item["already_learned"] = is_report_already_learned(
                    ticker=clean_tk,
                    url=raw_url,
                    institution=raw_inst
                )
        except Exception as dedup_err:
            print(f"[Search Dedup] Lỗi kiểm tra đã học: {dedup_err}")
    except Exception as e:
        print(f"Error searching institutional reports for {ticker}: {e}")
        results = []
    return {
        "ticker": clean_tk,
        "total_found": len(results),
        "results": results
    }


@app.get("/api/ai-learning/analyst-styles")
async def get_all_analyst_styles():
    """
    Trả về danh sách phong cách phân tích và ngữ điệu mà AI đã học từ các CTCK.
    """
    from ai_learning_engine import _ANALYST_STYLE_FILE
    if os.path.exists(_ANALYST_STYLE_FILE):
        try:
            with open(_ANALYST_STYLE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


@app.post("/api/auth/admin-verify")
async def api_admin_verify(req: AdminAuthRequest):
    """
    Xác thực tài khoản và mật khẩu Quản trị viên
    để mở khóa các tính năng cập nhật thủ công (Link, PDF, Text thô).
    """
    if is_admin_authorized(req.username, req.password):
        auth_data = get_admin_auth_data()
        return {
            "status": "ok",
            "authenticated": True,
            "username": auth_data.get("username", DEFAULT_ADMIN_USER),
            "message": "Xác thực tài khoản Quản trị viên thành công!"
        }
    raise HTTPException(
        status_code=403,
        detail="Tên đăng nhập hoặc mật khẩu quản trị viên không chính xác!"
    )


@app.post("/api/auth/forgot-password/request-otp")
async def api_request_password_otp(req: ForgotPasswordRequest):
    """
    Tạo và gửi mã xác nhận OTP 6 số qua email hoabhk31@gmail.com
    khi Quản trị viên quên mật khẩu.
    """
    email_clean = (req.email or "").strip().lower()
    auth_data = get_admin_auth_data()
    expected_email = auth_data.get("recovery_email", ADMIN_RECOVERY_EMAIL).lower()

    if email_clean != expected_email:
        raise HTTPException(
            status_code=400,
            detail=f"Email không hợp lệ! Tính năng khôi phục mật khẩu chỉ chấp nhận email quản trị viên đã đăng ký: {expected_email}"
        )

    # Sinh mã OTP 6 số ngẫu nhiên
    otp = f"{secrets.randbelow(900000) + 100000}"
    expires_at = time.time() + (15 * 60)  # Có hiệu lực trong 15 phút

    auth_data["active_otp"] = otp
    auth_data["otp_expires_at"] = expires_at
    save_admin_auth_data(auth_data)

    send_res = send_recovery_otp_email(expected_email, otp)

    return {
        "status": "ok",
        "message": f"Mã xác thực OTP (6 chữ số) đã được gửi đến email {expected_email}. Vui lòng kiểm tra hộp thư (hoặc mục Spam/Quảng cáo).",
        "recipient": expected_email,
        "expires_in_minutes": 15,
        "details": send_res
    }


@app.post("/api/auth/forgot-password/verify-reset")
async def api_verify_and_reset_password(req: VerifyResetPasswordRequest):
    """
    Xác minh mã OTP và cập nhật mật khẩu mới cho Quản trị viên.
    """
    email_clean = (req.email or "").strip().lower()
    otp_clean = (req.otp or "").strip()
    new_pwd = (req.new_password or "").strip()

    if len(new_pwd) < 4:
        raise HTTPException(status_code=400, detail="Mật khẩu mới phải có ít nhất 4 ký tự!")

    auth_data = get_admin_auth_data()
    expected_email = auth_data.get("recovery_email", ADMIN_RECOVERY_EMAIL).lower()

    if email_clean != expected_email:
        raise HTTPException(status_code=400, detail="Email không khớp với email quản trị viên đã đăng ký!")

    active_otp = auth_data.get("active_otp")
    otp_expires_at = auth_data.get("otp_expires_at", 0)

    if not active_otp or time.time() > otp_expires_at:
        raise HTTPException(status_code=400, detail="Mã OTP đã hết hạn hoặc chưa được tạo. Vui lòng bấm 'Gửi mã OTP' để nhận mã mới!")

    if otp_clean != active_otp:
        raise HTTPException(status_code=400, detail="Mã OTP không chính xác! Vui lòng kiểm tra lại email.")

    # Cập nhật mật khẩu mới bền vững vào file JSON
    auth_data["password"] = new_pwd
    auth_data["active_otp"] = None
    auth_data["otp_expires_at"] = 0
    save_admin_auth_data(auth_data)

    return {
        "status": "ok",
        "message": "Đổi mật khẩu Quản trị viên thành công! Mật khẩu mới đã được cập nhật.",
        "username": auth_data.get("username", DEFAULT_ADMIN_USER)
    }


@app.post("/api/crawl-url")
async def api_crawl_url(
    req: CrawlRequest,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization,
        fallback_user=req.admin_user,
        fallback_password=req.admin_password
    )
    try:
        clean_ticker = (req.ticker or "HPG").upper().strip()
        institution = req.institution or "CTCK"

        # === CHỐNG TRÙNG LẶP HỌC AI: kiểm tra URL fingerprint đã học chưa ===
        was_learned_before = False
        try:
            from ai_learning_engine import is_report_already_learned, mark_report_as_learned, learn_analyst_writing_style
            if is_report_already_learned(ticker=clean_ticker, url=req.url, institution=institution):
                was_learned_before = True
                print(f"[Crawl URL] Đã có trong kho tri thức AI, tiến hành bóc tách chỉ số định lượng đưa vào Ma trận: {institution} - {req.url[:80]}")
        except ImportError:
            pass

        data = await crawl_url_content(req.url, ticker=clean_ticker, institution=institution)

        market_p = 25000.0
        try:
            p_info = await fetch_reconciled_live_price(clean_ticker)
            if p_info:
                market_p = p_info.get("latest_close", 25000.0)
        except Exception:
            pass

        extracted_report = extract_financial_data_from_text(
            raw_text=data["text"],
            default_institution=institution,
            ticker=clean_ticker,
            current_market_price=market_p
        )
        extracted_report.source_url = req.url

        # Tự động nạp vào ma trận cache
        try:
            from crawler import ingest_report_item_to_matrix_cache
            ingest_report_item_to_matrix_cache(clean_ticker, extracted_report, market_p=market_p)
        except Exception as ig_err:
            print(f"[Crawl URL] Lỗi nạp vào matrix cache: {ig_err}")

        # Báo cáo đã ra cách đây hơn 1 năm không đưa vào chương trình AI học
        rep_date = getattr(extracted_report, "report_date", None) or getattr(req, "report_date", None)
        is_too_old_for_ai = is_report_expired(rep_date, max_days=365) if rep_date else False

        if not is_too_old_for_ai and not was_learned_before:
            raw_text = data.get("text", "")
            try:
                save_learned_ticker_catalysts(
                    ticker=clean_ticker,
                    catalysts=extracted_report.key_catalysts,
                    risks=extracted_report.key_risks,
                    source=institution,
                    title=f"Báo cáo phân tích {clean_ticker}",
                    report_date=rep_date
                )

                # Ghi nhận sự kiện tự học vào scheduler & cộng dồn tích lũy trọn đời
                try:
                    ai_scheduler.record_learned_event(
                        ticker=clean_ticker,
                        title=f"Báo cáo {clean_ticker} từ {institution}",
                        institution=institution,
                        catalysts_count=len(extracted_report.key_catalysts or []),
                        risks_count=len(extracted_report.key_risks or []),
                        theses_count=len(getattr(extracted_report, "investment_theses", []) or []),
                        confidence=getattr(extracted_report, "confidence_score", 0.92) or 0.92,
                        source=f"Crawl URL / {institution}",
                        template_name="Bóc Tách Độc Bản Doanh Nghiệp",
                        preview_catalysts=extracted_report.key_catalysts or [],
                        report_date=rep_date
                    )
                except Exception as sch_err:
                    print(f"[Crawl URL] Lỗi ghi nhận scheduler event: {sch_err}")

                # === HỌC NGỮ ĐIỆU PHÂN TÍCH của CTCK ===
                try:
                    learn_analyst_writing_style(
                        institution=institution,
                        raw_text=raw_text,
                        extracted_catalysts=extracted_report.key_catalysts or [],
                        extracted_risks=extracted_report.key_risks or []
                    )
                except Exception as style_err:
                    print(f"[Crawl URL] Lỗi học ngữ điệu {institution}: {style_err}")

                # === ĐÁNH DẤU FINGERPRINT đã học ===
                try:
                    mark_report_as_learned(
                        ticker=clean_ticker,
                        url=req.url,
                        raw_text=raw_text,
                        institution=institution,
                        title=getattr(extracted_report, "report_title", "") or ""
                    )
                except Exception as fp_err:
                    print(f"[Crawl URL] Lỗi đánh dấu fingerprint: {fp_err}")
            except Exception as store_err:
                print(f"[Crawl URL] Lỗi lưu catalysts: {store_err}")
        else:
            if was_learned_before:
                print(f"[Crawl URL] Báo cáo đã học trước đó — bỏ qua lưu catalysts trùng lặp.")
            else:
                print(f"[Crawl URL] Báo cáo đã ra cách đây hơn 1 năm ({rep_date}) - Bỏ qua đưa vào chương trình AI học.")

        # Làm mới cache
        try:
            from crawler import _SYNCED_MATRIX_REPORTS_CACHE
            keys_to_del = [k for k in _SYNCED_MATRIX_REPORTS_CACHE.keys() if k.startswith(f"{clean_ticker}_")]
            for k in keys_to_del:
                _SYNCED_MATRIX_REPORTS_CACHE.pop(k, None)
            _SYNCHRONIZED_PRESETS_CACHE.pop(clean_ticker, None)
        except Exception:
            pass

        return {
            "source_info": data,
            "extracted_report": extracted_report,
            "already_learned": was_learned_before
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi tải hoặc bóc tách URL: {str(e)}")



@app.post("/api/upload-pdf")
async def api_upload_pdf(
    file: UploadFile = File(...),
    ticker: Optional[str] = Form("HPG"),
    institution: Optional[str] = Form("CTCK"),
    admin_user: Optional[str] = Form(None),
    admin_password: Optional[str] = Form(None),
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization,
        fallback_user=admin_user,
        fallback_password=admin_password
    )
    try:
        clean_ticker = (ticker or "HPG").upper().strip()
        content = await file.read()
        parsed = parse_pdf_bytes(content, filename=file.filename)
        
        market_p = 25000.0
        try:
            p_info = await fetch_reconciled_live_price(clean_ticker)
            if p_info:
                market_p = p_info.get("latest_close", 25000.0)
        except Exception:
            pass

        extracted_report = extract_financial_data_from_text(
            raw_text=parsed["extracted_text"],
            default_institution=institution or "CTCK",
            ticker=clean_ticker,
            current_market_price=market_p
        )
        extracted_report.source_url = f"File: {file.filename} ({parsed['total_pages']} trang)"

        # Báo cáo đã ra cách đây hơn 1 năm không đưa vào chương trình AI học
        rep_date = getattr(extracted_report, "report_date", None)
        is_too_old_for_ai = is_report_expired(rep_date, max_days=365) if rep_date else False

        if not is_too_old_for_ai:
            # Tự động lưu trữ Catalysts vào kho AI
            try:
                save_learned_ticker_catalysts(
                    ticker=clean_ticker,
                    catalysts=extracted_report.key_catalysts,
                    risks=extracted_report.key_risks,
                    source=institution or "Bóc tách PDF",
                    title=f"File: {file.filename}",
                    report_date=rep_date
                )

                # Ghi nhận sự kiện tự học vào scheduler & cộng dồn tích lũy trọn đời
                try:
                    ai_scheduler.record_learned_event(
                        ticker=clean_ticker,
                        title=f"File PDF: {file.filename} ({clean_ticker})",
                        institution=institution or "Tài liệu PDF",
                        catalysts_count=len(extracted_report.key_catalysts or []),
                        risks_count=len(extracted_report.key_risks or []),
                        theses_count=len(getattr(extracted_report, "investment_theses", []) or []),
                        confidence=getattr(extracted_report, "confidence_score", 0.92) or 0.92,
                        source="Tải file PDF",
                        template_name="Bóc Tách Độc Bản Doanh Nghiệp",
                        preview_catalysts=extracted_report.key_catalysts or [],
                        report_date=rep_date
                    )
                except Exception as sch_err:
                    print(f"[Upload PDF] Lỗi ghi nhận scheduler event: {sch_err}")

                from crawler import _SYNCED_MATRIX_REPORTS_CACHE
                keys_to_del = [k for k in _SYNCED_MATRIX_REPORTS_CACHE.keys() if k.startswith(f"{clean_ticker}_")]
                for k in keys_to_del:
                    _SYNCED_MATRIX_REPORTS_CACHE.pop(k, None)
                _SYNCHRONIZED_PRESETS_CACHE.pop(clean_ticker, None)
            except Exception as store_err:
                print(f"[Upload PDF] Lỗi lưu catalysts: {store_err}")
        else:
            print(f"[Upload PDF] Báo cáo đã ra cách đây hơn 1 năm ({rep_date}) - Bỏ qua đưa vào chương trình AI học.")

        return {
            "file_info": {
                "filename": file.filename,
                "total_pages": parsed["total_pages"],
                "token_count": parsed["token_count"]
            },
            "extracted_report": extracted_report
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi xử lý file PDF: {str(e)}")


@app.post("/api/analyze-raw")
async def api_analyze_raw(
    req: RawTextAnalysisRequest,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization,
        fallback_user=req.admin_user,
        fallback_password=req.admin_password
    )
    if not req.raw_text or len(req.raw_text.strip()) < 20:
        raise HTTPException(status_code=400, detail="Nội dung văn bản quá ngắn để phân tích")
    
    clean_ticker = (req.ticker or "HPG").upper().strip()
    market_p = 25000.0
    try:
        p_info = await fetch_reconciled_live_price(clean_ticker)
        if p_info:
            market_p = p_info.get("latest_close", 25000.0)
    except Exception:
        pass

    report = extract_financial_data_from_text(
        raw_text=req.raw_text,
        default_institution=req.institution or "CTCK",
        ticker=clean_ticker,
        current_market_price=market_p
    )

    # Báo cáo đã ra cách đây hơn 1 năm không đưa vào chương trình AI học
    rep_date = getattr(report, "report_date", None)
    is_too_old_for_ai = is_report_expired(rep_date, max_days=365) if rep_date else False

    if not is_too_old_for_ai:
        # Tự động lưu trữ Catalysts vào kho AI
        try:
            save_learned_ticker_catalysts(
                ticker=clean_ticker,
                catalysts=report.key_catalysts,
                risks=report.key_risks,
                source=req.institution or "Phân tích Text thô",
                title=f"Nhập văn bản thô {clean_ticker}",
                report_date=rep_date
            )

            # Ghi nhận sự kiện tự học vào scheduler & cộng dồn tích lũy trọn đời
            try:
                ai_scheduler.record_learned_event(
                    ticker=clean_ticker,
                    title=f"Văn bản bóc tách {clean_ticker}",
                    institution=req.institution or "Phân tích Text thô",
                    catalysts_count=len(report.key_catalysts or []),
                    risks_count=len(report.key_risks or []),
                    theses_count=len(getattr(report, "investment_theses", []) or []),
                    confidence=getattr(report, "confidence_score", 0.90) or 0.90,
                    source="Nhập văn bản thô",
                    template_name="Bóc Tách Độc Bản Doanh Nghiệp",
                    preview_catalysts=report.key_catalysts or [],
                    report_date=rep_date
                )
            except Exception as sch_err:
                print(f"[Analyze Raw] Lỗi ghi nhận scheduler event: {sch_err}")

            from crawler import _SYNCED_MATRIX_REPORTS_CACHE
            keys_to_del = [k for k in _SYNCED_MATRIX_REPORTS_CACHE.keys() if k.startswith(f"{clean_ticker}_")]
            for k in keys_to_del:
                _SYNCED_MATRIX_REPORTS_CACHE.pop(k, None)
            _SYNCHRONIZED_PRESETS_CACHE.pop(clean_ticker, None)
        except Exception as store_err:
            print(f"[Analyze Raw] Lỗi lưu catalysts: {store_err}")
    else:
        print(f"[Analyze Raw] Báo cáo đã ra cách đây hơn 1 năm ({rep_date}) - Bỏ qua đưa vào chương trình AI học.")

    return report


# -------------------------------------------------------------
# AI SELF-LEARNING & AUTONOMOUS CRAWLER ENDPOINTS
# -------------------------------------------------------------

@app.get("/api/ai-learning/config")
async def api_get_ai_learning_config():
    """Lấy cấu hình tự học: tần suất quét, watchlist, trạng thái."""
    cfg = ai_scheduler.get_config()
    try:
        from gemini_extractor import get_gemini_api_key
        key = get_gemini_api_key()
        cfg["gemini_flash_enabled"] = bool(key)
        cfg["gemini_key_masked"] = (key[:6] + "..." + key[-4:]) if (key and len(key) >= 10) else ""
    except Exception:
        cfg["gemini_flash_enabled"] = False
        cfg["gemini_key_masked"] = ""
    return cfg


@app.post("/api/ai-learning/config")
async def api_save_ai_learning_config(req: LearningConfigRequest):
    """Cập nhật cấu hình tự động quét và tần suất học online."""
    updates = {}
    if req.enabled is not None:
        updates["enabled"] = req.enabled
    if req.interval_hours is not None:
        updates["interval_hours"] = req.interval_hours
    if req.watchlist is not None:
        updates["watchlist"] = req.watchlist
    if req.auto_ingest_matrix is not None:
        updates["auto_ingest_matrix"] = req.auto_ingest_matrix
    return ai_scheduler.update_config(updates)


@app.post("/api/ai-learning/gemini-key")
async def api_save_gemini_key(
    req: GeminiKeyRequest,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Cập nhật hoặc kích hoạt Gemini Flash API Key (Yêu cầu quyền Admin)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    raw_key = (req.api_key or "").strip()
    from gemini_extractor import GEMINI_CONFIG_FILE, DATA_DIR
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(GEMINI_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"api_key": raw_key}, f, ensure_ascii=False, indent=2)
    
    # Cập nhật cả biến môi trường runtime
    os.environ["GEMINI_API_KEY"] = raw_key
    
    masked = (raw_key[:6] + "..." + raw_key[-4:]) if len(raw_key) >= 10 else ("Đã xóa" if not raw_key else "Đã lưu")
    return {
        "success": True,
        "enabled": bool(raw_key),
        "key_masked": masked,
        "message": f"Đã kích hoạt thành công Gemini 1.5 Flash (Key: {masked})" if raw_key else "Đã tắt Gemini Flash"
    }


@app.get("/api/ai-learning/templates")
async def api_list_ai_templates():
    """Liệt kê toàn bộ các Mẫu học (Few-Shot Templates) hệ thống và tùy biến của người dùng."""
    return template_store.list_all()


@app.post("/api/ai-learning/templates")
async def api_save_ai_template(
    req: TemplateCreateUpdateRequest,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Thêm mới hoặc cập nhật một Mẫu học trích xuất Catalysts/Luận điểm (yêu cầu quyền Admin)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    data = req.model_dump() if hasattr(req, "model_dump") else req.dict()
    saved = template_store.add_or_update(data)
    return {"status": "SUCCESS", "template": saved}


@app.delete("/api/ai-learning/templates/{template_id}")
async def api_delete_ai_template(
    template_id: str,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Xóa mẫu học do người dùng tự tạo (yêu cầu quyền Admin)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    success = template_store.delete(template_id)
    if not success:
        raise HTTPException(status_code=400, detail="Không thể xóa mẫu hệ thống hoặc mẫu không tồn tại")
    return {"status": "SUCCESS", "message": f"Đã xóa thành công mẫu {template_id}"}


@app.post("/api/ai-learning/templates/reset")
async def api_reset_ai_templates(
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Khôi phục danh sách mẫu học về mặc định ban đầu của hệ thống (yêu cầu quyền Admin)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    tpls = template_store.reset_to_defaults()
    return {"status": "SUCCESS", "templates_count": len(tpls)}


@app.post("/api/ai-learning/analyze-template-image")
async def api_analyze_template_image(
    file: UploadFile = File(...),
    ticker: Optional[str] = Form(None),
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """
    Tải lên hình ảnh báo cáo / bảng số liệu / biểu đồ để AI tự đọc, ghi nhớ
    và bóc tách thành Mẫu huấn luyện (tên, ngành, từ khóa, catalysts, luận điểm, rủi ro).
    Yêu cầu quyền Quản trị viên (Admin: 325396).
    """
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    try:
        content = await file.read()
        if not content:
            raise HTTPException(status_code=400, detail="Tệp tin hình ảnh rỗng")
        res = await analyze_template_image_ai(
            image_bytes=content,
            filename=file.filename or "image.png",
            ticker_hint=ticker
        )
        return res
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi AI phân tích hình ảnh: {str(e)}")


@app.post("/api/ai-learning/trigger-learn")
async def api_trigger_ai_learn(req: Optional[TriggerLearnRequest] = None):
    """Kích hoạt tiến trình quét và học online ngay lập tức."""
    target_tickers = req.tickers if req else None
    res = await ai_scheduler.run_learning_cycle(target_tickers=target_tickers)
    
    # Tự động xóa cache báo cáo cũ để các lần mở sau nạp lại dữ liệu mới nhất kèm Catalysts từ AI
    updated_tickers = res.get("updated_tickers", [])
    if updated_tickers:
        from crawler import _SYNCED_MATRIX_REPORTS_CACHE
        for sym in updated_tickers:
            try:
                keys_to_del = [k for k in _SYNCED_MATRIX_REPORTS_CACHE.keys() if k.startswith(f"{sym}_")]
                for k in keys_to_del:
                    _SYNCED_MATRIX_REPORTS_CACHE.pop(k, None)
                _SYNCHRONIZED_PRESETS_CACHE.pop(sym, None)
            except Exception:
                pass

        # Nạp lại dữ liệu ngầm trong nền (fire-and-forget) không làm treo hoặc chậm phản hồi HTTP
        async def _preload_updated_in_background(symbols: List[str]):
            for s in symbols[:5]:
                try:
                    await get_preset_by_ticker(s)
                except Exception as pre_err:
                    print(f"[AI Learn Preload] {s}: {pre_err}")

        asyncio.create_task(_preload_updated_in_background(updated_tickers))

    return res


@app.get("/api/ai-learning/history")
async def api_get_ai_learning_history(limit: int = 30):
    """Xem nhật ký các tài liệu báo cáo phân tích mà AI đã quét và tự học."""
    return ai_scheduler.get_history(limit=limit)


@app.get("/api/ai-learning/stats")
async def api_get_ai_learning_stats():
    """Thống kê tổng quan năng lực tự học: tổng mẫu, số catalysts tích lũy, độ tin cậy."""
    return ai_scheduler.get_stats()


@app.get("/api/ai-learning/knowledge/{ticker}")
async def api_get_ticker_knowledge(ticker: str):
    """
    Lấy toàn bộ kiến thức AI đã học được cho một mã cổ phiếu cụ thể.
    Trả về: catalysts, risks, theses, lịch sử nguồn học, thống kê.
    Cached _TTL_KNOWLEDGE giây để giảm I/O — get_learned_ticker_catalysts() tự handle mtime.
    """
    clean_ticker = ticker.upper().strip()
    now_ts = time.time()
    # Trả về từ cache nếu còn mới
    if clean_ticker in _KNOWLEDGE_CACHE and (now_ts - _KNOWLEDGE_CACHE_TS.get(clean_ticker, 0)) < _TTL_KNOWLEDGE:
        return _KNOWLEDGE_CACHE[clean_ticker]

    learned = get_learned_ticker_catalysts(clean_ticker)
    if not learned:
        result = {
            "ticker": clean_ticker,
            "has_knowledge": False,
            "catalysts": [],
            "risks": [],
            "theses": [],
            "history": [],
            "last_updated": None,
            "total_sources": 0
        }
    else:
        result = {
            "ticker": clean_ticker,
            "has_knowledge": True,
            "catalysts": learned.get("catalysts", []),
            "risks": learned.get("risks", []),
            "theses": learned.get("theses", []),
            "history": learned.get("history", []),
            "last_updated": learned.get("last_updated"),
            "total_sources": len(learned.get("history", []))
        }
    _KNOWLEDGE_CACHE[clean_ticker] = result
    _KNOWLEDGE_CACHE_TS[clean_ticker] = now_ts
    return result


@app.delete("/api/ai-learning/knowledge/{ticker}")
async def api_delete_ticker_knowledge(
    ticker: str,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Xóa toàn bộ kiến thức AI đã học cho một mã cổ phiếu (Yêu cầu quyền Admin để chống phá hoại)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    clean_ticker = ticker.upper().strip()
    import json as _json
    if not os.path.exists(AI_LEARNED_CATALYSTS_FILE):
        return {"ticker": clean_ticker, "deleted": False, "message": "File không tồn tại"}
    try:
        with open(AI_LEARNED_CATALYSTS_FILE, "r", encoding="utf-8") as f:
            data = _json.load(f)
        existed = clean_ticker in data
        if existed:
            del data[clean_ticker]
            with open(AI_LEARNED_CATALYSTS_FILE, "w", encoding="utf-8") as f:
                _json.dump(data, f, ensure_ascii=False, indent=2)
        # Invalidate server-side knowledge cache ngay lập tức
        _KNOWLEDGE_CACHE.pop(clean_ticker, None)
        _KNOWLEDGE_CACHE_TS.pop(clean_ticker, None)
        return {"ticker": clean_ticker, "deleted": existed, "message": "Đã xóa thành công" if existed else "Không tìm thấy dữ liệu"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi xóa knowledge: {str(e)}")


# -------------------------------------------------------------
# AI KNOWLEDGE BACKUP & RESTORE ENDPOINTS (BẢO TOÀN DỮ LIỆU ĐÃ HỌC KHI DEPLOY)
# -------------------------------------------------------------

@app.get("/api/ai-learning/backups")
async def api_list_ai_backups():
    """Liệt kê danh sách các bản sao lưu tri thức AI đã học."""
    from knowledge_backup_manager import list_all_backups
    return list_all_backups()


@app.post("/api/ai-learning/backups/create")
async def api_create_ai_backup(tag: str = "manual"):
    """Tạo bản sao lưu nén zip toàn bộ tri thức AI (Không chặn quyền Admin để người dùng luôn sao lưu dữ liệu an toàn)."""
    from knowledge_backup_manager import create_knowledge_backup
    res = create_knowledge_backup(tag=tag)
    if not res.get("success"):
        raise HTTPException(status_code=500, detail=f"Lỗi tạo backup: {res.get('error')}")
    return res


@app.get("/api/ai-learning/backups/create-and-download")
async def api_create_and_download_ai_backup(tag: str = "manual"):
    """Tạo bản sao lưu nén zip và tải trực tiếp về trình duyệt người dùng."""
    from knowledge_backup_manager import create_knowledge_backup, BACKUP_DIR
    res = create_knowledge_backup(tag=tag)
    if not res.get("success"):
        raise HTTPException(status_code=500, detail=f"Lỗi tạo backup: {res.get('error')}")
    filename = res.get("filename")
    target_path = os.path.join(BACKUP_DIR, filename)
    return FileResponse(
        target_path,
        media_type="application/zip",
        filename=filename
    )


@app.get("/api/ai-learning/backups/download/{filename}")
async def api_download_ai_backup(filename: str):
    """Tải file backup nén zip về máy tính cá nhân để lưu trữ an toàn."""
    from knowledge_backup_manager import BACKUP_DIR
    clean_name = os.path.basename(filename)
    target_path = os.path.join(BACKUP_DIR, clean_name)
    if not os.path.exists(target_path) or not clean_name.endswith(".zip"):
        raise HTTPException(status_code=404, detail="Không tìm thấy tệp sao lưu yêu cầu")
    return FileResponse(
        target_path,
        media_type="application/zip",
        filename=clean_name
    )


@app.post("/api/ai-learning/backups/restore")
async def api_restore_ai_backup(
    req: RestoreBackupRequest,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Khôi phục hoặc hợp nhất tri thức AI từ file backup có sẵn trong hệ thống (Yêu cầu quyền Admin)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    from knowledge_backup_manager import BACKUP_DIR, restore_knowledge_from_zip
    target_file = None
    if req.filename:
        clean_name = os.path.basename(req.filename)
        target_file = os.path.join(BACKUP_DIR, clean_name)
    else:
        # Mặc định lấy bản latest_backup.zip
        target_file = os.path.join(BACKUP_DIR, "latest_backup.zip")

    if not target_file or not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Không tìm thấy file backup tương ứng")

    res = restore_knowledge_from_zip(target_file, merge=req.merge)
    if not res.get("success"):
        raise HTTPException(status_code=500, detail=f"Lỗi khôi phục: {res.get('error')}")

    # Xóa sạch bộ nhớ đệm RAM để nhận ngay dữ liệu vừa khôi phục
    _KNOWLEDGE_CACHE.clear()
    _KNOWLEDGE_CACHE_TS.clear()

    return res


@app.post("/api/ai-learning/backups/upload")
async def api_upload_ai_backup(
    file: UploadFile = File(...),
    merge: bool = True,
    x_admin_user: Optional[str] = Header(None, alias="X-Admin-User"),
    x_admin_password: Optional[str] = Header(None, alias="X-Admin-Password"),
    authorization: Optional[str] = Header(None, alias="Authorization")
):
    """Tải lên tệp zip backup từ máy tính để khôi phục hoặc nạp dữ liệu tri thức cũ (Yêu cầu quyền Admin)."""
    enforce_admin_permission(
        x_admin_user=x_admin_user,
        x_admin_password=x_admin_password,
        authorization=authorization
    )
    from knowledge_backup_manager import BACKUP_DIR, restore_knowledge_from_zip
    if not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="Vui lòng tải lên đúng định dạng file .zip sao lưu")

    os.makedirs(BACKUP_DIR, exist_ok=True)
    temp_path = os.path.join(BACKUP_DIR, f"uploaded_{int(time.time())}_{os.path.basename(file.filename)}")
    try:
        content = await file.read()
        with open(temp_path, "wb") as f_out:
            f_out.write(content)

        res = restore_knowledge_from_zip(temp_path, merge=merge)
        if not res.get("success"):
            raise HTTPException(status_code=500, detail=f"Lỗi phân tích gói backup: {res.get('error')}")

        # Xóa sạch RAM cache
        _KNOWLEDGE_CACHE.clear()
        _KNOWLEDGE_CACHE_TS.clear()

        return res
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass



@app.post("/api/reconcile")
async def api_reconcile(req: ReconcileRequest):
    if not req.reports:
        raise HTTPException(status_code=400, detail="Cần ít nhất 1 báo cáo phân tích để đối chiếu")
    result = calculate_consensus(
        reports=req.reports,
        ticker=req.ticker,
        company_name=req.company_name or f"Doanh nghiệp {req.ticker.upper()}",
        sector=req.sector or "Doanh nghiệp niêm yết",
        current_market_price=req.current_market_price,
        price_source_info=req.price_source_info
    )
    # Tự động đồng bộ các luận điểm tăng trưởng (Catalysts) mà AI đã tích lũy vào ma trận đối chiếu
    try:
        result = apply_learned_catalysts_to_report(result)
    except Exception as e:
        print(f"[API Reconcile] Lỗi áp dụng catalysts AI: {e}")
    return result


@app.post("/api/export-markdown")
async def api_export_markdown(req: ExportRequest):
    """
    Kết xuất Báo cáo so sánh đối chiếu chuẩn theo đúng cấu trúc 4 phần yêu cầu của người dùng.
    """
    data = normalize_full_matrix_dict(req.report_data)
    cs = data.get("consensus_summary", {})
    reports = data.get("matrix_table", [])

    ticker = data.get("ticker", "CP")
    company_name = data.get("company_name", f"Công ty Cổ phần {ticker}")
    sector = data.get("sector", "")
    analysis_date = data.get("analysis_date", datetime.now().strftime("%d/%m/%Y"))

    def _get(obj, k, d=""):
        return obj.get(k, d) if isinstance(obj, dict) else getattr(obj, k, d)

    current_market_p = _get(cs, "current_market_price", 0) or 0
    mean_target_p = _get(cs, "mean_target_price", 0) or 0
    avg_upside = _get(cs, "average_upside", 0.0) or 0.0
    consensus_rating = _get(cs, "consensus_rating", "MUA")
    consensus_score = _get(cs, "consensus_score", 4.0)
    rec_buy_zone = _get(cs, "recommended_buy_zone", "—")
    stop_loss_val = _get(cs, "stop_loss_threshold", "—")
    key_triggers = _get(cs, "key_triggers", []) or []

    md_lines = []
    md_lines.append(f"# BÁO CÁO PHÂN TÍCH ĐỐI CHIẾU ĐA TỔ CHỨC: {ticker} ({company_name})")
    md_lines.append(f"**Ngành:** {sector} | **Thị giá tham chiếu:** {current_market_p:,.0f} VND | **Thời điểm phân tích:** {analysis_date}")
    cs_head_up = f"Đã vượt kỳ vọng (+{abs(avg_upside):.1f}%)" if avg_upside < 0 else f"+{avg_upside:.1f}%"
    md_lines.append(f"**Consensus Rating:** {consensus_rating} (Điểm: {consensus_score}/5.0) | **Vùng giá mục tiêu:** {mean_target_p:,.0f} VND ({cs_head_up})\n")
    md_lines.append("---\n")

    # 1. BẢNG MA TRẬN SO SÁNH ĐA TỔ CHỨC
    md_lines.append("## 1. BẢNG MA TRẬN SO SÁNH ĐA TỔ CHỨC (BẮT BUỘC)")
    headers = ["Tiêu chí đối chiếu"] + [_get(r, "institution", "CTCK") for r in reports] + ["Độ lệch / Đồng thuận chung"]
    md_lines.append("| " + " | ".join(headers) + " |")
    md_lines.append("| " + " | ".join([":---"] * len(headers)) + " |")

    # 1. Ngày phát hành
    dates = [_get(r, "report_date", "") for r in reports]
    md_lines.append(f"| **1. Ngày phát hành** | " + " | ".join(dates) + f" | {analysis_date} |")

    # 2. Khuyến nghị
    recs = [_get(r, "recommendation", "") for r in reports]
    md_lines.append(f"| **2. Khuyến nghị** | " + " | ".join(recs) + f" | **{consensus_rating}** |")

    # 3. Giá mục tiêu
    def _fmt_md_tp(r):
        if _get(r, "is_expired", False):
            tp = _get(r, "target_price", 0)
            return f"{tp:,.0f} VND (Quá 1 năm)" if tp > 0 else "— (Quá 1 năm)"
        if _get(r, "is_technical", False) or "PTKT" in (_get(r, "recommendation", "") or "").upper():
            return "— (PTKT)"
        tp = _get(r, "target_price", 0)
        if not tp or tp <= 0 or _get(r, "is_estimated_price", False):
            return "— (KQKD)"
        return f"{tp:,.0f} VND"
    tps = [_fmt_md_tp(r) for r in reports]
    cs_tp_str = f"**{mean_target_p:,.0f} VND**" if mean_target_p > 0 else "**— (Cần theo dõi thêm)**"
    md_lines.append(f"| **3. Giá mục tiêu** | " + " | ".join(tps) + f" | {cs_tp_str} |")

    # 4. Tiềm năng tăng giá
    def _fmt_up(r):
        if _get(r, "is_expired", False):
            return "— (Quá 1 năm)"
        up_val = safe_float(_get(r, "upside_percent"))
        if up_val is None:
            raw_up = _get(r, "upside_percent")
            return str(raw_up) if raw_up else "—"
        if up_val < 0:
            return f"Vượt +{abs(up_val):.1f}%"
        return f"+{up_val:.1f}%"
    ups = [_fmt_up(r) for r in reports]
    avg_up_val = safe_float(avg_upside)
    if mean_target_p <= 0 or avg_up_val is None:
        cs_up_str = "— (Cần theo dõi thêm)"
    elif avg_up_val < 0:
        cs_up_str = f"Đã vượt kỳ vọng (+{abs(avg_up_val):.1f}%)"
    else:
        cs_up_str = f"+{avg_up_val:.1f}%"
    md_lines.append(f"| **4. Tiềm năng tăng giá** | " + " | ".join(ups) + f" | **{cs_up_str}** |")

    # 5. P/E forward
    pes = [f"{_get(r, 'pe_forward'):.1f}x" if _get(r, 'pe_forward') else "—" for r in reports]
    valid_pes = [_get(r, "pe_forward") for r in reports if _get(r, "pe_forward") and _get(r, "pe_forward") > 0]
    avg_pe = sum(valid_pes) / len(valid_pes) if valid_pes else 0
    md_lines.append(f"| **5. P/E forward** | " + " | ".join(pes) + f" | {avg_pe:.1f}x |")

    # 6. P/B forward
    pbs = [f"{_get(r, 'pb_forward'):.2f}x" if _get(r, 'pb_forward') else "—" for r in reports]
    valid_pbs = [_get(r, "pb_forward") for r in reports if _get(r, "pb_forward") and _get(r, "pb_forward") > 0]
    avg_pb = sum(valid_pbs) / len(valid_pbs) if valid_pbs else 0
    md_lines.append(f"| **6. P/B forward** | " + " | ".join(pbs) + f" | {avg_pb:.2f}x |")

    # 7. Dự phóng Doanh thu
    revs = [_get(r, "revenue_forecast", "") for r in reports]
    md_lines.append(f"| **7. Dự phóng Doanh thu** | " + " | ".join(revs) + " | Đồng thuận tăng trưởng |")

    # 8. Dự phóng LNST
    npats = [_get(r, "npat_forecast", "") for r in reports]
    md_lines.append(f"| **8. Dự phóng LNST** | " + " | ".join(npats) + " | Kỳ vọng lợi nhuận bứt phá |")

    # 9. Luận điểm then chốt
    catalysts_cols = []
    for r in reports:
        cats = _get(r, "key_catalysts", []) or []
        cat_str = "<br>".join([f"{i+1}. {c}" for i, c in enumerate(cats)])
        catalysts_cols.append(cat_str)
    md_lines.append(f"| **9. Luận điểm then chốt** | " + " | ".join(catalysts_cols) + f" | Trọng tâm: Mở rộng quy mô kinh doanh |")

    # 10. Phương pháp định giá
    methods = [_get(r, "valuation_method", "") or "—" for r in reports]
    md_lines.append(f"| **10. Phương pháp định giá** | " + " | ".join(methods) + " | Kết hợp P/E & DCF |")

    md_lines.append("\n---\n")

    # 2. PHÂN TÍCH NHÂN QUẢ & ĐỘNG LỰC TĂNG TRƯỞNG CỐT LÕI
    md_lines.append("## 2. PHÂN TÍCH CHUYÊN SÂU: NGUYÊN NHÂN - KẾT QUẢ - BẰNG CHỨNG (CAUSALITY ANALYSIS)\n")
    causality_items = data.get("causality_analysis", []) or []
    for c in causality_items:
        md_lines.append(f"### {_get(c, 'category', 'Phân tích')}")
        md_lines.append(f"- **Hiện tượng tài chính:** {_get(c, 'phenomenon', '')}")
        md_lines.append(f"- **Nguyên nhân cốt lõi:** {_get(c, 'root_causes', '')}")
        md_lines.append(f"- **Bằng chứng số liệu:** {_get(c, 'data_evidence', '')}\n")

    md_lines.append("---\n")

    # 3. BẢNG PHÂN HÓA QUAN ĐIỂM GIỮA CÁC TỔ CHỨC
    md_lines.append("## 3. BẢNG PHÂN HÓA QUAN ĐIỂM (DISENSUS & CONSENSUS ANALYSIS)\n")
    md_lines.append("| Tiêu chí phân hóa | Phe Lạc quan (Bulls) | Phe Thận trọng (Bears) | Bằng chứng & Luận điểm |")
    md_lines.append("| :--- | :--- | :--- | :--- |")
    disensus_items = data.get("disensus_table", []) or []
    for d in disensus_items:
        md_lines.append(f"| **{_get(d, 'variable', '')}** | {_get(d, 'bulls_view', '')} | {_get(d, 'bears_view', '')} | {_get(d, 'evidence', '')} |")
    md_lines.append("\n---\n")

    # 4. KẾT LUẬN & HÀNH ĐỘNG DÀNH CHO NHÀ ĐẦU TƯ
    md_lines.append("## 4. KẾT LUẬN & HÀNH ĐỘNG DÀNH CHO NHÀ ĐẦU TƯ\n")
    md_lines.append(f"- **Consensus Rating:** **{consensus_rating}** (Điểm trung bình: {consensus_score}/5.0).")
    md_lines.append(f"- **Vùng giá mục tiêu bình quân:**")
    if avg_upside < 0:
        mean_upside_str = f"Thị giá vượt định giá: **+{abs(avg_upside):.1f}%** (Đã vượt kỳ vọng)"
    else:
        mean_upside_str = f"Upside tiềm năng: **+{avg_upside:.1f}%**"
    md_lines.append(f"  - Giá bình quân (Mean): **{mean_target_p:,.0f} VND** ({mean_upside_str}).")
    median_tp = _get(cs, "median_target_price", 0) or mean_target_p
    min_tp = _get(cs, "min_target_price", 0) or mean_target_p
    max_tp = _get(cs, "max_target_price", 0) or mean_target_p
    spread = _get(cs, "target_price_spread_percent", 0) or 0.0
    md_lines.append(f"  - Giá trung vị (Median): **{median_tp:,.0f} VND**.")
    md_lines.append(f"  - Khung giá mục tiêu [Min - Max]: **{min_tp:,.0f} - {max_tp:,.0f} VND** (Biên độ chênh lệch: {spread:.1f}%).")
    md_lines.append(f"- **Vùng giá giải ngân khuyến nghị:** `{rec_buy_zone}`.")
    md_lines.append(f"- **Ngưỡng quản trị rủi ro (Stop-loss):** `{stop_loss_val}`.")
    md_lines.append(f"- **Trigger then chốt cần theo dõi định kỳ:**")
    for t in key_triggers:
        md_lines.append(f"  * {t}")

    markdown_content = "\n".join(md_lines)
    return {"markdown": markdown_content}


PDF_CACHE_DIR = os.path.join(os.path.dirname(__file__), "cache", "edocs_pdfs")
os.makedirs(PDF_CACHE_DIR, exist_ok=True)


def match_ctck_institution(target_inst: str, candidate_name: str) -> bool:
    """
    So khớp tên Công ty Chứng khoán thông minh dựa trên tên viết tắt, mã thương hiệu và biệt danh phổ biến.
    Đảm bảo tính toàn vẹn thương hiệu (Brand Integrity) tuyệt đối, không nhầm lẫn giữa các CTCK khác nhau.
    """
    if not target_inst or not candidate_name:
        return False
    t_clean = re.sub(r'[^a-z0-9]', '', target_inst.lower())
    c_clean = re.sub(r'[^a-z0-9]', '', candidate_name.lower())
    if not t_clean or not c_clean:
        return False
    if t_clean == c_clean:
        return True

    aliases = {
        'kis': ['kis', 'kisvn', 'kisresearch', 'korea'],
        'bsc': ['bsc', 'bidv', 'bscresearch'],
        'vcbs': ['vcbs', 'vietcombank'],
        'evs': ['evs', 'everest'],
        'vpx': ['vpx', 'vpbs', 'vps', 'vpbank', 'vpbanksecurities'],
        'mbs': ['mbs', 'mbke', 'mbresearch', 'mbsecurities'],
        'fpts': ['fpts', 'fpt'],
        'ssi': ['ssi', 'ssiresearch'],
        'hsc': ['hsc', 'hcm'],
        'vndirect': ['vnd', 'vndirect', 'dstock'],
        'vietcap': ['vcsc', 'vietcap', 'banviet', 'vcap'],
        'kbsv': ['kbsv', 'kb', 'kbsec'],
        'dsc': ['dsc'],
        'mas': ['mas', 'mirae', 'miraeasset'],
        'bvs': ['bvs', 'bvsc', 'baoviet'],
        'tcbs': ['tcbs', 'techcom'],
        'tps': ['tps', 'tienphong'],
        'vds': ['vds', 'vdsc', 'rongviet'],
        'kafi': ['kafi'],
        'ssv': ['ssv', 'shinhan'],
        'vietinbank': ['cts', 'vietin', 'vietinbank', 'vbse'],
        'nhsv': ['nhsv', 'namhae'],
        'ysvn': ['ysvn', 'yuanta'],
        'vfs': ['vfs', 'nhatviet'],
        'beta': ['beta'],
        'bmsc': ['bmsc', 'baominh'],
        'csi': ['csi', 'kienthiet'],
        'acbs': ['acbs', 'acb'],
        'tvsi': ['tvsi', 'tanviet'],
        'shs': ['shs', 'saigonhanoi'],
        'phsv': ['phsv', 'phuhung'],
        'abs': ['abs', 'anbinh'],
        'pinetree': ['pinetree', 'pine'],
        'vics': ['vics', 'thuongmai'],
        'aps': ['aps', 'chauthaibinhduong'],
        'agriseco': ['agr', 'agriseco', 'agribank']
    }

    # 1. Kiểm tra theo alias groups
    for key, group in aliases.items():
        t_has = any(w == t_clean or (len(w) >= 3 and (t_clean.startswith(w) or w in t_clean)) for w in group)
        c_has = any(w == c_clean or (len(w) >= 3 and (c_clean.startswith(w) or w in c_clean)) for w in group)
        if t_has and c_has:
            return True

    # 2. Kiểm tra nếu cùng chứa một từ khóa mã CTCK trong aliases
    for key, group in aliases.items():
        for w in group:
            if len(w) >= 3:
                if (w in t_clean and w in c_clean):
                    return True

    # 3. Nếu cả 2 đều đủ dài và chứa nhau hoặc bắt đầu bằng nhau
    if len(t_clean) >= 3 and len(c_clean) >= 3:
        if t_clean in c_clean or c_clean in t_clean or t_clean.startswith(c_clean) or c_clean.startswith(t_clean):
            return True

    return False


async def fetch_real_institution_pdf(clean_ticker: str, clean_inst: str, preferred_url: Optional[str] = None) -> Optional[tuple]:
    """
    Tải file PDF báo cáo phân tích thực tế trực tiếp từ Vietstock eDocs hoặc nguồn CTCK chính thức.
    TUÂN THỦ NGUYÊN TẮC BẢO TOÀN THƯƠNG HIỆU (Brand Purity):
      - Chỉ tải và trả về file PDF nếu ĐÚNG LÀ của CTCK được yêu cầu.
      - Tuyệt đối KHÔNG gán file PDF của CTCK này cho CTCK khác.
    Trả về (bytes, filename, actual_url) hoặc None.
    """
    def is_valid_ticker_pdf_candidate(url_str: str, candidate_title: str = "") -> bool:
        if not url_str or not url_str.startswith("http") or ".pdf" not in url_str.lower():
            return False
        u_low = url_str.lower()
        t_low = candidate_title.lower()

        # Kiểm tra tiêu đề nếu bắt đầu bằng mã khác (ví dụ "GMD: ...")
        leading_m = re.match(r'^\s*\[?([A-Z0-9]{3,4})\]?\s*[:\-]', candidate_title, re.IGNORECASE)
        if leading_m and leading_m.group(1).upper() != clean_ticker:
            return False

        # Kiểm tra nếu url chứa rõ ràng slug của mã khác
        url_ticker_m = re.search(r'/([a-z0-9]{3,4})[_\-]', u_low)
        if url_ticker_m:
            detected_sym = url_ticker_m.group(1).upper()
            if detected_sym != clean_ticker and detected_sym in VIETNAM_STOCK_DIRECTORY:
                return False

        # Kiểm tra xung đột ngành rõ rệt: Tuyệt đối không gán báo cáo ngành khác cho mã không thuộc ngành đó
        mismatched_keywords = [
            ("nganhthep", ["HPG", "HSG", "NKG", "VGS", "TLH", "POM"]),
            ("nganh_thep", ["HPG", "HSG", "NKG", "VGS", "TLH", "POM"]),
            ("bcsxphanbon", ["DPM", "DCM", "BFC", "LAS"]),
            ("phan_bon", ["DPM", "DCM", "BFC", "LAS"]),
            ("nganhdetmay", ["TNG", "MSH", "VGT", "STK", "GIL"]),
            ("det_may", ["TNG", "MSH", "VGT", "STK", "GIL"]),
            ("nganh_chung_khoan", ["SSI", "HCM", "VND", "VCI", "SHS", "MBS", "FTS", "BSI", "CTS", "VIX"]),
            ("chungkhoantruocthem", ["SSI", "HCM", "VND", "VCI", "SHS", "MBS", "FTS", "BSI", "CTS", "VIX"])
        ]
        for kw, valid_tickers in mismatched_keywords:
            if kw in u_low or kw in t_low:
                if clean_ticker not in valid_tickers:
                    return False
        return True

    candidates = []

    # 1. URL được cung cấp từ matched_item (đã được khớp CTCK từ trước):
    if preferred_url and is_valid_ticker_pdf_candidate(preferred_url):
        candidates.append((preferred_url, clean_inst))

    # 2. Quét eDocs từ Vietstock eDocs Portal nếu cần tìm thêm hoặc preferred_url rỗng
    try:
        edocs_items = await fetch_edocs_reports(clean_ticker, limit=20)
    except Exception as e:
        print(f"[PDF Resolver] Lỗi khi quét Vietstock eDocs cho {clean_ticker}: {e}")
        edocs_items = []

    matched_edocs = []
    for it in edocs_items:
        src = it.get("SourceName", "")
        title = it.get("Title", "")
        url = it.get("Url", "")
        if not is_valid_ticker_pdf_candidate(url, title):
            continue
        if match_ctck_institution(clean_inst, src) or match_ctck_institution(clean_inst, title) or match_ctck_institution(clean_inst, url):
            matched_edocs.append((url, src or clean_inst))

    # Danh sách chỉ bao gồm những file PDF chính xác của CTCK đó (KHÔNG CÓ other_edocs)
    all_candidates = candidates + matched_edocs

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept": "application/pdf,*/*"
    }

    for url, inst_name in all_candidates:
        url_hash = hashlib.md5(url.encode()).hexdigest()[:10]
        safe_name = to_ascii_slug(inst_name) or "CTCK"
        cached_file_path = os.path.join(PDF_CACHE_DIR, f"{clean_ticker}_{safe_name}_{url_hash}.pdf")

        # Kiểm tra file trong cache đĩa (nếu kích thước > 5KB)
        if os.path.exists(cached_file_path) and os.path.getsize(cached_file_path) > 5000:
            try:
                with open(cached_file_path, "rb") as f:
                    content = f.read()
                if b"%PDF" in content[:1024] or len(content) > 5000:
                    filename = f"{clean_ticker}_{safe_name}_Bao_Cao_Phan_Tich.pdf"
                    return content, filename, url
            except Exception as read_err:
                print(f"[PDF Cache] Lỗi đọc file cache {cached_file_path}: {read_err}")

        # Chưa có trong cache -> tải trực tiếp từ nguồn eDocs
        try:
            async with httpx.AsyncClient(headers=headers, timeout=12.0, follow_redirects=True) as client:
                resp = await client.get(url)
                if resp.status_code == 200 and (b"%PDF" in resp.content[:1024] or len(resp.content) > 5000):
                    try:
                        with open(cached_file_path, "wb") as f:
                            f.write(resp.content)
                    except Exception as write_err:
                        print(f"[PDF Cache] Lỗi ghi file cache {cached_file_path}: {write_err}")

                    filename = f"{clean_ticker}_{safe_name}_Bao_Cao_Phan_Tich.pdf"
                    return resp.content, filename, url
        except Exception as dl_err:
            print(f"[PDF Resolver] Tải file PDF thất bại từ {url}: {dl_err}")
            continue

    return None


@app.get("/api/reports/pdf/{ticker}/{institution}")
async def get_report_pdf(
    ticker: str,
    institution: str,
    request: Request,
    source_url: Optional[str] = None,
    date: Optional[str] = None,
    download: Optional[int] = 0
):
    """
    Trả về file PDF Báo cáo Phân tích & Định giá thực tế của Công ty Chứng khoán tương ứng
    (Tải trực tiếp từ nguồn Vietstock eDocs / CTCK Research Hub, có bộ nhớ đệm cache).
    Cho phép xem trực tiếp trên trình duyệt (inline) hoặc tải về (download).
    """
    clean_ticker = ticker.upper().strip()
    clean_inst = urllib.parse.unquote(institution).removesuffix(".pdf").strip()

    is_download = bool(download) or (request.query_params.get("download") in ("1", "true", "yes"))
    disposition_type = "attachment" if is_download else "inline"

    # Tìm kiếm báo cáo trong _SYNCHRONIZED_PRESETS_CACHE, PRESET_DATASETS hoặc gọi get_preset_by_ticker
    full_report = _SYNCHRONIZED_PRESETS_CACHE.get(clean_ticker) or PRESET_DATASETS.get(clean_ticker)
    if not full_report:
        full_report = await get_preset_by_ticker(clean_ticker, sync_live_price=False)

    matched_item = None
    if full_report and full_report.matrix_table:
        for item in full_report.matrix_table:
            if match_ctck_institution(clean_inst, item.institution) or clean_inst.lower() in item.institution.lower() or item.institution.lower() in clean_inst.lower():
                matched_item = item
                break

    preferred_url = source_url if (source_url and source_url.startswith(("http://", "https://"))) else (matched_item.source_url if (matched_item and matched_item.source_url) else None)

    # Tải file PDF báo cáo phân tích thực tế từ Vietstock eDocs / CTCK
    real_pdf_result = await fetch_real_institution_pdf(clean_ticker, clean_inst, preferred_url)

    if real_pdf_result:
        pdf_bytes, filename, actual_url = real_pdf_result
        # Cập nhật lại source_url trong bộ nhớ nếu trước đó chỉ là link HTML tổng quát
        if matched_item and (not matched_item.source_url or not matched_item.source_url.endswith(".pdf")):
            matched_item.source_url = actual_url

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": make_content_disposition(disposition_type, filename),
                "Cache-Control": "public, max-age=86400"
            }
        )

    # Fallback tự động sinh PDF chuyên nghiệp chuẩn CTCK khi không có kết nối online
    cs = full_report.consensus_summary if full_report else None
    cur_p = cs.current_market_price if cs else (getattr(full_report, "current_price", 0) if full_report else 0)
    report_dict = {
        "institution": matched_item.institution if matched_item else clean_inst,
        "target_price": (matched_item.adjusted_target_price or matched_item.target_price) if matched_item else (cs.mean_target_price if cs else 0),
        "current_price": cur_p,
        "upside_pct": matched_item.upside_percent if matched_item else (cs.average_upside if cs else 0.0),
        "recommendation": matched_item.recommendation if matched_item else (cs.consensus_rating if cs else "MUA"),
        "date": (matched_item.report_date if matched_item else date) or time.strftime("%d/%m/%Y"),
        "catalysts": " • " + "\n • ".join(matched_item.key_catalysts) if (matched_item and matched_item.key_catalysts) else "Triển vọng kinh doanh khả quan nhờ mở rộng công suất và nhu cầu thị trường hồi phục mạnh mẽ.",
        "risks": " • " + "\n • ".join(matched_item.key_risks) if (matched_item and matched_item.key_risks) else "Biến động chi phí nguyên vật liệu đầu vào và rủi ro tỷ giá.",
    }

    consensus_dict = {
        "avg_target": cs.mean_target_price if cs else 0,
        "avg_upside_pct": cs.average_upside if cs else 0.0,
        "highest_target": cs.max_target_price if cs else 0,
        "lowest_target": cs.min_target_price if cs else 0,
        "total_reports": len(full_report.matrix_table) if (full_report and full_report.matrix_table) else 1,
    }

    comp_info = VIETNAM_STOCK_DIRECTORY.get(clean_ticker, {})
    company_name = (full_report.company_name if full_report else None) or comp_info.get("name") or f"CTCP {clean_ticker}"
    sector = (full_report.sector if full_report else None) or comp_info.get("sector") or "Doanh nghiệp niêm yết"

    pdf_bytes = generate_ctck_report_pdf(
        ticker=clean_ticker,
        company_name=company_name,
        sector=sector,
        report=report_dict,
        consensus=consensus_dict,
    )

    safe_inst_name = to_ascii_slug(report_dict["institution"]) or "CTCK"
    filename = f"{clean_ticker}_{safe_inst_name}_Bao_Cao_Phan_Tich.pdf"

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": make_content_disposition(disposition_type, filename),
            "Cache-Control": "public, max-age=3600"
        }
    )


@app.post("/api/export-csv")
async def api_export_csv(req: ExportRequest):
    data = normalize_full_matrix_dict(req.report_data)
    reports = data.get("matrix_table", [])
    output = io.StringIO()
    writer = csv.writer(output)

    def _get(obj, k, d=""):
        return obj.get(k, d) if isinstance(obj, dict) else getattr(obj, k, d)

    # Header
    headers = ["Tieu_chi"] + [_get(r, "institution", "CTCK") for r in reports]
    writer.writerow(headers)

    # Rows
    writer.writerow(["Ngay_phat_hanh"] + [_get(r, "report_date", "") for r in reports])
    writer.writerow(["Khuyen_nghi"] + [_get(r, "recommendation", "") for r in reports])
    writer.writerow(["Gia_muc_tieu"] + [f"{_get(r, 'target_price', 0):.0f}" for r in reports])
    writer.writerow(["Upside_percent"] + [f"{_get(r, 'upside_percent', 0):.1f}%" if _get(r, 'upside_percent') is not None else "" for r in reports])
    writer.writerow(["PE_forward"] + [str(_get(r, "pe_forward", "") or "") for r in reports])
    writer.writerow(["PB_forward"] + [str(_get(r, "pb_forward", "") or "") for r in reports])
    writer.writerow(["Du_phong_Doanh_thu"] + [_get(r, "revenue_forecast", "") for r in reports])
    writer.writerow(["Du_phong_LNST"] + [_get(r, "npat_forecast", "") for r in reports])
    writer.writerow(["Phuong_phap_dinh_gia"] + [_get(r, "valuation_method", "") or "" for r in reports])

    csv_content = output.getvalue()
    ticker = data.get("ticker", "CP")
    filename = f"IERM_{ticker}_Matrix.csv"
    return Response(
        content=csv_content,
        media_type="text/csv",
        headers={"Content-Disposition": make_content_disposition("attachment", filename)}
    )


@app.post("/api/export-matrix-pdf")
async def api_export_matrix_pdf(req: ExportRequest):
    """
    Xuất toàn bộ Bảng đối chiếu trực diện đa tổ chức ra file PDF A4 Landscape định dạng chuyên nghiệp.
    """
    try:
        report_dict = normalize_full_matrix_dict(req.report_data)
        pdf_bytes = generate_matrix_table_pdf(report_dict)
        ticker = report_dict.get("ticker", "CP")
        filename = f"IERM_{ticker}_Matrix_Table.pdf"
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": make_content_disposition("attachment", filename),
                "Cache-Control": "no-cache"
            }
        )
    except Exception as exc:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Lỗi tạo PDF ma trận: {str(exc)}")


class SummaryExportPdfRequest(BaseModel):
    report_data: dict
    financial_bundle: Optional[dict] = None


@app.post("/api/export-summary-pdf")
async def api_export_summary_pdf(req: SummaryExportPdfRequest):
    """
    Xuất Báo cáo tổng hợp đa tổ chức & phân tích nguyên nhân (Synthesized Research Note) ra file PDF A4 Portrait chuẩn IERM.
    """
    try:
        report_dict = normalize_full_matrix_dict(req.report_data)
        fin_dict = req.financial_bundle or {}
        # Nếu fin_dict rỗng hoặc thiếu BCTC, tự động nạp từ backend
        if not fin_dict or not fin_dict.get("statements_quarterly"):
            ticker = report_dict.get("ticker", "")
            if ticker:
                try:
                    from financial_data import get_financial_data_bundle
                    fin_dict = get_financial_data_bundle(ticker) or {}
                except Exception:
                    pass

        pdf_bytes = generate_summary_note_pdf(report_dict, fin_dict)
        ticker = report_dict.get("ticker", "CP")
        filename = f"IERM_{ticker}_Bao_Cao_Tong_Hop.pdf"
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": make_content_disposition("attachment", filename),
                "Cache-Control": "no-cache"
            }
        )
    except Exception as exc:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Lỗi tạo PDF báo cáo tổng hợp: {str(exc)}")



class PeerExportPdfRequest(BaseModel):
    peers_data: dict
    radar_image_base64: Optional[str] = None


@app.post("/api/peers/export-pdf")
async def api_export_peers_pdf(req: PeerExportPdfRequest):
    """
    Xuất Báo cáo đối thủ cùng ngành & Radar sức mạnh tài chính ra file PDF A4 Landscape định dạng chuẩn tổ chức.
    """
    import traceback
    target = (req.peers_data.get("target_ticker") or "DN").upper()
    raw_sector = req.peers_data.get("sector_name") or "Nganh"
    clean_sector = "".join(c for c in raw_sector if c.isalnum() or c in (" ", "_", "-")).strip().replace(" ", "_")
    try:
        pdf_bytes = generate_peer_comparison_pdf(req.peers_data, req.radar_image_base64)
    except Exception as exc:
        err_detail = traceback.format_exc()
        print(f"[PDF-ERROR] {exc}\n{err_detail}", flush=True)
        raise HTTPException(status_code=500, detail=f"PDF generation error: {str(exc)}\n{err_detail}")
    filename = f"Bao_Cao_Nganh_{target}_{clean_sector}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": make_content_disposition("attachment", filename),
            "Cache-Control": "no-cache"
        }
    )


@app.get("/api/pdf-proxy")
async def pdf_proxy(
    url: str,
    request: Request,
    ticker: Optional[str] = None,
    source: Optional[str] = None,
    download: Optional[int] = 0
):
    """
    Proxy tải an toàn và stream file PDF từ bên ngoài (Vietstock eDocs, CTCK) về cho iframe,
    loại bỏ lỗi Mixed Content (HTTP vs HTTPS), CSP frame-ancestors và X-Frame-Options SAMEORIGIN.
    """
    if not url or not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="URL không hợp lệ")

    is_download = bool(download) or (request.query_params.get("download") in ("1", "true", "yes"))
    disposition_type = "attachment" if is_download else "inline"
    clean_ticker = (ticker or "IERM").upper().strip()
    safe_source = to_ascii_slug(source or "Bao_Cao")
    filename = f"{clean_ticker}_{safe_source}.pdf"

    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://finance.vietstock.vn/"
        }
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=True, headers=headers) as client:
            res = await client.get(url)
            if res.status_code == 200:
                if res.content.startswith(b"%PDF") or "pdf" in res.headers.get("content-type", "").lower():
                    return Response(
                        content=res.content,
                        media_type="application/pdf",
                        headers={
                            "Content-Disposition": make_content_disposition(disposition_type, filename),
                            "Cache-Control": "public, max-age=3600"
                        }
                    )
    except Exception as exc:
        print(f"[PDF-PROXY-WARN] Failed to fetch {url}: {exc}")

    # Fallback nếu tải không được: nếu có ticker, phục vụ báo cáo PDF tương ứng của mã đó
    if ticker:
        return await get_report_pdf(
            ticker=ticker,
            institution=f"{source or 'CTCK'}.pdf",
            request=request,
            source_url=url,
            download=download
        )

    raise HTTPException(status_code=404, detail="Không thể tải file PDF từ nguồn chỉ định")


@app.post("/api/export-matrix-excel")
async def api_export_matrix_excel(req: ExportRequest):
    """
    Xuất Bảng đối chiếu đa tổ chức ra file Excel XML/HTML Spreadsheet (.xls)
    hỗ trợ 100% tiếng Việt UTF-8, định dạng màu sắc cột, tiêu đề, căn chỉnh số liệu chuẩn xác.
    """
    data = normalize_full_matrix_dict(req.report_data)
    reports = data.get("matrix_table", [])
    if reports:
        from engine import get_report_date_sort_key
        reports = sorted(reports, key=get_report_date_sort_key, reverse=True)
    cs = data.get("consensus_summary", {})

    ticker = data.get("ticker", "CP")
    company_name = data.get("company_name", f"Công ty Cổ phần {ticker}")
    sector = data.get("sector", "")
    if not sector or sector in ["Doanh nghiệp niêm yết", "Doanh nghiệp Niêm yết"]:
        try:
            from adaptive_growth_engine import classify_business_model
            from sector_peers_matrix import get_universal_sector_peer_config
            model_info = classify_business_model(ticker, company_name, sector)
            cfg = get_universal_sector_peer_config(model_info.get("model_key", ""), ticker)
            sector = cfg.get("sector_name") or model_info.get("badge_text") or sector or "Doanh nghiệp niêm yết"
        except Exception:
            pass

    def _get(obj, k, d=""):
        return obj.get(k, d) if isinstance(obj, dict) else getattr(obj, k, d)

    current_market_p = _get(cs, "current_market_price", 0) or 0
    mean_target_p = _get(cs, "mean_target_price", 0) or 0
    avg_upside = _get(cs, "average_upside", 0.0) or 0.0
    consensus_rating = _get(cs, "consensus_rating", "MUA")
    rec_buy_zone = _get(cs, "recommended_buy_zone", "—")
    stop_loss_val = _get(cs, "stop_loss_threshold", "—")

    html_lines = [
        '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">',
        '<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">',
        '<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>',
        f'<x:Name>IERM_{ticker}_Matrix</x:Name>',
        '<x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->',
        '<style>',
        'body { font-family: "Segoe UI", Arial, sans-serif; }',
        'table { border-collapse: collapse; width: 100%; }',
        'th { background-color: #0f172a; color: #38bdf8; border: 1px solid #334155; padding: 8px; font-weight: bold; text-align: center; }',
        'td { border: 1px solid #cbd5e1; padding: 6px; vertical-align: top; }',
        '.header-row { background-color: #0284c7; color: #ffffff; font-weight: bold; }',
        '.criteria-col { background-color: #f8fafc; font-weight: bold; color: #1e293b; min-width: 220px; }',
        '.consensus-col { background-color: #f0fdf4; font-weight: bold; color: #059669; text-align: center; }',
        '</style></head><body>',
        f'<div style="background-color: #0f172a; padding: 12px 16px; border-radius: 4px; margin-bottom: 12px;">',
        f'  <div style="font-size: 11px; font-weight: normal; color: #94a3b8; letter-spacing: 0.5px; text-transform: uppercase;">IERM TERMINAL // BẢNG ĐỐI CHIẾU TRỰC DIỆN ĐA TỔ CHỨC</div>',
        f'  <div style="font-size: 17px; font-weight: bold; color: #facc15; margin-top: 4px; text-shadow: 0 1px 2px rgba(0,0,0,0.5);"><span style="color:#38bdf8;">Mã CK:</span> {ticker} - <span style="color:#ffffff;">{company_name}</span> | <span style="color:#94a3b8; font-size: 14px; font-weight: normal;">Ngành: {sector}</span></div>',
        f'  <div style="font-size: 12px; color: #cbd5e1; margin-top: 4px;"><b>Thị giá tham chiếu:</b> <span style="color:#38bdf8; font-weight:bold;">{current_market_p:,.0f} VND</span> | <b>Định giá TB (Mean):</b> <span style="color:#4ade80; font-weight:bold;">{mean_target_p:,.0f} VND</span> | <b>{"Kỳ vọng thị giá vs Định giá" if avg_upside < 0 else "Upside kỳ vọng"}:</b> <span style="color:{"#f43f5e" if avg_upside < 0 else "#22c55e"}; font-weight:bold;">{"Đã vượt kỳ vọng (+" + f"{abs(avg_upside):.1f}" + "%)" if avg_upside < 0 else f"+{avg_upside:.1f}%"}</span></div>',
        f'</div>',
        '<table border="1">'
    ]

    # Header
    html_lines.append('<tr>')
    html_lines.append('<th class="header-row" style="text-align:left;">TIÊU CHÍ ĐỐI CHIẾU</th>')
    for r in reports:
        html_lines.append(f'<th class="header-row">{_get(r, "institution", "CTCK")}<br><span style="font-size:10px;font-weight:normal;">({_get(r, "report_date", "")})</span></th>')
    html_lines.append('<th class="header-row" style="background-color:#059669;color:#ffffff;">CONSENSUS & ĐỒNG THUẬN</th>')
    html_lines.append('</tr>')

    def add_row(criteria, get_val_fn, consensus_str, is_bold=False):
        html_lines.append('<tr>')
        html_lines.append(f'<td class="criteria-col">{criteria}</td>')
        for r in reports:
            val = get_val_fn(r)
            b_tag = "<b>" if is_bold else ""
            b_end = "</b>" if is_bold else ""
            html_lines.append(f'<td style="text-align:center;">{b_tag}{val}{b_end}</td>')
        html_lines.append(f'<td class="consensus-col">{consensus_str}</td>')
        html_lines.append('</tr>')

    # 1. Khuyến nghị
    add_row("1. Khuyến nghị đầu tư", lambda r: _get(r, "recommendation", "N/A"), consensus_rating, is_bold=True)
    # 2. Giá mục tiêu
    def _fmt_excel_tp(r):
        if _get(r, "is_expired", False):
            tp = _get(r, "target_price", 0)
            return f"{tp:,.0f} đ (Quá 1 năm)" if tp > 0 else "— (Quá 1 năm)"
        if _get(r, "is_technical", False):
            return "— (PTKT)"
        tp = _get(r, "target_price", 0)
        if not tp or tp <= 0:
            return "— (KQKD)"
        return f"{tp:,.0f} đ"
    excel_cs_tp = f"Mean: {mean_target_p:,.0f} đ" if mean_target_p > 0 else "Mean: — (Cần theo dõi thêm)"
    add_row("2. Giá mục tiêu (VND)", _fmt_excel_tp, excel_cs_tp, is_bold=True)

    # 3. Tiềm năng tăng giá
    def _fmt_excel_upside(r):
        if _get(r, "is_expired", False):
            return "— (Quá 1 năm)"
        up_val = safe_float(_get(r, "upside_percent"))
        if up_val is None:
            raw_up = _get(r, "upside_percent")
            return str(raw_up) if raw_up else "—"
        if up_val < 0:
            return f"Vượt +{abs(up_val):.1f}%"
        return f"+{up_val:.1f}%"
    avg_up_val = safe_float(avg_upside)
    if mean_target_p <= 0 or avg_up_val is None:
        excel_cs_up = "— (Cần theo dõi thêm)"
    elif avg_up_val < 0:
        excel_cs_up = f"Đã vượt kỳ vọng (+{abs(avg_up_val):.1f}%)"
    else:
        excel_cs_up = f"+{avg_up_val:.1f}%"
    add_row("3. Tiềm năng tăng giá (Upside)", _fmt_excel_upside, excel_cs_up, is_bold=True)
    # 4. P/E forward
    valid_pes = [_get(r, "pe_forward") for r in reports if _get(r, "pe_forward") and _get(r, "pe_forward") > 0]
    avg_pe = sum(valid_pes) / len(valid_pes) if valid_pes else 0
    add_row("4. Hệ số P/E Forward", lambda r: f"{_get(r, 'pe_forward'):.1f}x" if _get(r, 'pe_forward') else "—", f"TB: {avg_pe:.1f}x" if avg_pe > 0 else "—")
    # 5. P/B forward
    valid_pbs = [_get(r, "pb_forward") for r in reports if _get(r, "pb_forward") and _get(r, "pb_forward") > 0]
    avg_pb = sum(valid_pbs) / len(valid_pbs) if valid_pbs else 0
    add_row("5. Hệ số P/B Forward", lambda r: f"{_get(r, 'pb_forward'):.2f}x" if _get(r, 'pb_forward') else "—", f"TB: {avg_pb:.2f}x" if avg_pb > 0 else "—")
    # 6. Dự phóng Doanh thu
    add_row("6. Dự phóng Doanh thu", lambda r: _get(r, "revenue_forecast", "") or "N/A", "Đồng thuận tích cực")
    # 7. Dự phóng LNST
    add_row("7. Dự phóng LNST", lambda r: _get(r, "npat_forecast", "") or "N/A", "Tăng trưởng cao", is_bold=True)
    # 8. Luận điểm tăng trưởng
    add_row("8. Luận điểm tăng trưởng (Catalysts)", lambda r: "<br>• ".join([""] + (_get(r, "key_catalysts", []) or [])), "• Dự án mở rộng công suất<br>• Tăng trưởng thị phần")
    # 9. Rủi ro trọng yếu
    add_row("9. Rủi ro trọng yếu (Key Risks)", lambda r: "<br>• ".join([""] + (_get(r, "key_risks", []) or [])), "• Biến động giá hàng hóa<br>• Rủi ro tài chính")

    html_lines.append('</table><br>')
    html_lines.append(f'<p><b>Chiến lược giải ngân:</b> {rec_buy_zone} | <b>Ngưỡng quản trị dừng lỗ:</b> {stop_loss_val}</p>')
    html_lines.append('</body></html>')

    excel_content = "\n".join(html_lines)
    filename = f"IERM_{ticker}_Matrix_Table.xls"
    return Response(
        content=excel_content,
        media_type="application/vnd.ms-excel",
        headers={"Content-Disposition": make_content_disposition("attachment", filename)}
    )


# =============================================================
# VISITOR TRAFFIC TRACKER (ONLINE / TODAY / TOTAL ALL-TIME)
# =============================================================
VISITOR_STATS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "visitor_stats.json")
_VISITOR_LOCK = asyncio.Lock()
_ACTIVE_SESSIONS: Dict[str, float] = {}  # session_id -> last_active_ts
_TODAY_SESSIONS: set = set()
_CURRENT_DATE_STR: str = datetime.now().strftime("%Y-%m-%d")

def _load_visitor_stats() -> dict:
    today_str = datetime.now().strftime("%Y-%m-%d")
    default_stats = {
        "total_visits": 1,
        "today_date": today_str,
        "today_visits": 1
    }
    if os.path.exists(VISITOR_STATS_FILE):
        try:
            with open(VISITOR_STATS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data.get("today_date") != today_str:
                    data["today_date"] = today_str
                    data["today_visits"] = 0
                return data
        except Exception:
            pass
    return default_stats

def _save_visitor_stats(data: dict):
    try:
        with open(VISITOR_STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

_CACHED_VISITOR_DATA = _load_visitor_stats()

@app.get("/api/visitor-stats")
async def get_visitor_stats(request: Request, sid: Optional[str] = None):
    global _CACHED_VISITOR_DATA, _ACTIVE_SESSIONS, _TODAY_SESSIONS, _CURRENT_DATE_STR

    now = time.time()
    today_str = datetime.now().strftime("%Y-%m-%d")

    async with _VISITOR_LOCK:
        # Nếu sang ngày mới, reset bộ đếm ngày hôm nay
        if today_str != _CURRENT_DATE_STR or _CACHED_VISITOR_DATA.get("today_date") != today_str:
            _CURRENT_DATE_STR = today_str
            _CACHED_VISITOR_DATA["today_date"] = today_str
            _CACHED_VISITOR_DATA["today_visits"] = 0
            _TODAY_SESSIONS.clear()
            _save_visitor_stats(_CACHED_VISITOR_DATA)

        # Định danh session thực tế theo IP & sid từ client
        client_ip = request.client.host if request.client else "unknown"
        session_id = sid or f"ip_{client_ip}"

        # Dọn dẹp session offline quá 120s (2 phút không gửi heartbeat coi như đã rời trang)
        _ACTIVE_SESSIONS = {s: t for s, t in _ACTIVE_SESSIONS.items() if now - t < 120}

        # Nếu là session mới trong ngày -> tăng lượt xem thực tế
        if session_id not in _TODAY_SESSIONS:
            _TODAY_SESSIONS.add(session_id)
            _CACHED_VISITOR_DATA["today_visits"] = _CACHED_VISITOR_DATA.get("today_visits", 0) + 1
            _CACHED_VISITOR_DATA["total_visits"] = _CACHED_VISITOR_DATA.get("total_visits", 0) + 1
            _save_visitor_stats(_CACHED_VISITOR_DATA)

        # Cập nhật thời gian hoạt động của session này
        _ACTIVE_SESSIONS[session_id] = now

        # Số người online thực tế 100% (chính xác số session đang mở tab kết nối)
        real_online = len(_ACTIVE_SESSIONS)

        return {
            "online": max(1, real_online),
            "today": _CACHED_VISITOR_DATA.get("today_visits", 1),
            "total": _CACHED_VISITOR_DATA.get("total_visits", 1)
        }



